#!/system/bin/sh
# NEMESIS service hmg-eq20/eq20d (root, mode=restart): keeps the 20-band EQ on BT / AA music.
. /data/nemesis/apps/hmg-eq20/scripts/common.sh
mkdir -p "$state" && chmod 755 "$pkg" "$state"
CLASSPATH=$pkg/files/eq20d.jar exec /system/bin/app_process /system/bin com.hmg.eq20.daemon.Eq20Daemon run \
    /data/data/com.hmg.eq20/files/eq20.conf "$state/status"
