#!/system/bin/sh
# Shared helpers for the hmg-eq20 NEMESIS package hooks (toolbox + mksh only).
export PATH=/data/nemesis/bin:/sbin:/vendor/bin:/system/sbin:/system/bin:/system/xbin
export ANDROID_ROOT=/system ANDROID_DATA=/data
export LD_LIBRARY_PATH=/vendor/lib:/system/lib
[ -n "$BOOTCLASSPATH" ] || export BOOTCLASSPATH=/system/framework/core.jar:/system/framework/conscrypt.jar:/system/framework/okhttp.jar:/system/framework/core-junit.jar:/system/framework/bouncycastle.jar:/system/framework/ext.jar:/system/framework/framework.jar:/system/framework/framework2.jar:/system/framework/telephony-common.jar:/system/framework/voip-common.jar:/system/framework/mms-common.jar:/system/framework/android.policy.jar:/system/framework/services.jar:/system/framework/apache-xml.jar:/system/framework/webviewchromium.jar:/system/framework/automotive.jar

pkg=/data/nemesis/apps/hmg-eq20
state=$pkg/state
backup=/data/nemesis/backup/hmg-eq20
nemesis_log=/data/nemesis/nemesis.log
product=CN7NPE.KOR.0000.V039.001.260902
conf=/system/etc/audio_effects.conf
vendor_conf=/vendor/etc/audio_effects.conf
lib=/system/lib/soundfx/libeq20.so
stock_conf_md5=4d98c1b38bd1d9eaf929d9b616c0d118

msg() {
    echo "$1"
    mkdir -p "$state" 2>/dev/null
    echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$state/install.log" 2>/dev/null
    if [ -d "${nemesis_log%/*}" ]; then
        echo "$(date '+%Y-%m-%d %H:%M:%S') hmg-eq20: $1" >> "$nemesis_log" 2>/dev/null
    fi
}

file_md5() {
    set -- $(md5 "$1" 2>/dev/null)
    echo "$1"
}

# md5 recorded for a packaged file in files/MD5SUMS
expected_md5() {
    while read sum name; do
        if [ "$name" = "$1" ]; then
            echo "$sum"
            return 0
        fi
    done < "$pkg/files/MD5SUMS"
    return 1
}

# pid of the running mediaserver, empty if none
mediaserver_pid() {
    ps | while read user pid rest; do
        case "$rest" in
            *' /system/bin/mediaserver') echo "$pid"; break ;;
        esac
    done
}

# Restart the init service and wait until a NEW mediaserver answers (max 40 s). If `stop media` leaves the
# old process running, it is killed (init restarts the service). The old/new pids go to install.log.
restart_media() {
    old=$(mediaserver_pid)
    stop media
    n=0
    while [ -n "$(mediaserver_pid)" ] && [ "$n" -lt 10 ]; do
        sleep 1
        n=$((n + 1))
    done
    cur=$(mediaserver_pid)
    if [ -n "$cur" ] && [ "$cur" = "$old" ]; then
        echo "mediaserver $old survived 'stop media', killing it" >> "$state/install.log"
        kill -9 "$old" 2>/dev/null
        sleep 1
    fi
    start media
    n=0
    while [ "$n" -lt 40 ]; do
        sleep 1
        n=$((n + 1))
        cur=$(mediaserver_pid)
        if [ -n "$cur" ] && [ "$cur" != "$old" ] &&
            dumpsys media.audio_flinger 2>/dev/null | grep -q 'Output thread'; then
            echo "mediaserver restarted: pid $old -> $cur after ${n}s" >> "$state/install.log"
            return 0
        fi
    done
    echo "mediaserver restart failed: pid before $old, now $(mediaserver_pid)" >> "$state/install.log"
    return 1
}

# exit 0 once mediaserver lists the eq20 effect; retried because the new mediaserver may still be starting
eq20_registered() {
    n=0
    while [ "$n" -lt 15 ]; do
        if CLASSPATH=$pkg/files/eq20d.jar /system/bin/app_process /system/bin com.hmg.eq20.daemon.Eq20Daemon query \
            >> "$state/install.log" 2>&1; then
            return 0
        fi
        sleep 1
        n=$((n + 1))
    done
    return 1
}

# Evidence for a failed install: install.log, file state and mediaserver/effect log lines. Saved in the package
# state dir and, when the install USB stick is still mounted, as hmg-eq20-diag.txt on the stick.
save_diag() {
    f=$state/install-diag.txt
    {
        echo "== hmg-eq20 install diagnostics $(date '+%Y-%m-%d %H:%M:%S'): $1"
        echo "== mediaserver pid: $(mediaserver_pid)"
        echo "== files"
        ls -l "$lib" "$conf" 2>&1
        echo "lib md5 $(file_md5 "$lib") conf md5 $(file_md5 "$conf")"
        echo "== install.log"
        cat "$state/install.log" 2>&1
        echo "== logcat (effects, linker, crashes, mediaserver)"
        logcat -d -v time 2>&1 | grep -i -E 'effect|eq20|soundfx|linker|dlopen|DEBUG|mediaserver|AudioFlinger|AudioPolicy|Fatal|SIGSEGV'
        echo "== tombstones"
        ls -l /data/tombstones 2>&1
    } > "$f" 2>&1
    chmod 644 "$f"
    for usb in /storage/usb0 /storage/usb1 /mnt/usb0; do
        if [ -e "$usb/NEMESIS.data" ]; then
            cp "$f" "$usb/hmg-eq20-diag.txt" 2>/dev/null && msg "진단 파일: USB의 hmg-eq20-diag.txt"
            break
        fi
    done
}

remount_rw() {
    nemesis remount rw >> "$state/install.log" 2>&1
}

remount_ro() {
    nemesis remount ro >> "$state/install.log" 2>&1 || msg 'warning: /system stays read-write until restart'
}

# copy to a temp name beside the target, then rename, so a reader never sees half a file
put_file() {
    cp "$1" "$2.hmg-eq20.tmp" && chmod 644 "$2.hmg-eq20.tmp" && mv "$2.hmg-eq20.tmp" "$2"
}
