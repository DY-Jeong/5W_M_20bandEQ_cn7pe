#!/system/bin/sh
# postinstall: install libeq20.so and the eq20 entry in audio_effects.conf, then restart mediaserver
# and verify the effect is registered. Any failure after the first /system write rolls back to stock.
. /data/nemesis/apps/hmg-eq20/scripts/common.sh

rollback() {
    msg "rollback: $1"
    save_diag "$1"
    remount_rw
    if [ "$(file_md5 "$backup/audio_effects.conf.stock")" = "$stock_conf_md5" ]; then
        put_file "$backup/audio_effects.conf.stock" "$conf"
    fi
    rm "$lib" 2>/dev/null
    remount_ro
    restart_media || msg 'warning: mediaserver did not answer after rollback'
    if [ "$(file_md5 "$conf")" = "$stock_conf_md5" ] && [ ! -e "$lib" ]; then
        msg '설치 취소: 순정 상태로 되돌렸습니다'
    else
        msg '설치 취소 실패: 순정 파일 복원을 확인하세요 (backup 유지)'
    fi
    exit 1
}

main() {
    mkdir -p "$state" && chmod 755 "$pkg" "$state"
    msg '설치 시작'
    actual=$(getprop ro.build.product)
    [ "$actual" = "$product" ] || { msg "거부: 차량 펌웨어 $actual 는 지원하지 않습니다"; exit 1; }
    [ ! -e "$vendor_conf" ] || { msg "거부: $vendor_conf 가 있어 설정을 적용할 수 없습니다"; exit 1; }
    for name in libeq20.so audio_effects.conf eq20d.jar; do
        want=$(expected_md5 "$name") || { msg "거부: MD5SUMS에 $name 없음"; exit 1; }
        [ "$(file_md5 "$pkg/files/$name")" = "$want" ] || { msg "거부: $name 손상"; exit 1; }
    done
    ours_conf=$(expected_md5 audio_effects.conf)
    ours_lib=$(expected_md5 libeq20.so)
    live_conf=$(file_md5 "$conf")
    if [ "$live_conf" = "$stock_conf_md5" ]; then
        if [ -e "$lib" ] && [ "$(file_md5 "$lib")" != "$ours_lib" ]; then
            msg "거부: $lib 가 이미 있습니다"
            exit 1
        fi
        mkdir -p "$backup" && chmod 700 "$backup"
        cp "$conf" "$backup/audio_effects.conf.stock"
        [ "$(file_md5 "$backup/audio_effects.conf.stock")" = "$stock_conf_md5" ] || { msg '거부: 순정 설정 백업 실패'; exit 1; }
    elif [ "$live_conf" = "$ours_conf" ]; then
        [ "$(file_md5 "$backup/audio_effects.conf.stock")" = "$stock_conf_md5" ] ||
            { msg '거부: 이전 설치의 순정 백업이 없습니다'; exit 1; }
    else
        msg '거부: audio_effects.conf 가 순정과 다릅니다 (다른 수정이 있음)'
        exit 1
    fi

    remount_rw || { msg '거부: /system 쓰기 전환 실패'; exit 1; }
    put_file "$pkg/files/libeq20.so" "$lib" || rollback 'library copy failed'
    put_file "$pkg/files/audio_effects.conf" "$conf" || rollback 'conf copy failed'
    remount_ro
    if [ "$(file_md5 "$lib")" != "$ours_lib" ] || [ "$(file_md5 "$conf")" != "$ours_conf" ]; then
        rollback 'verify failed'
    fi

    msg '오디오 서비스 재시작 (몇 초 무음)'
    restart_media || rollback 'mediaserver did not come back'
    eq20_registered || rollback 'eq20 effect not registered by mediaserver'
    msg '설치 완료: 앱 목록의 EQ 를 실행하세요'
}

main
