#!/system/bin/sh
# preuninstall: restore the stock audio_effects.conf and remove libeq20.so, but only while they are
# still exactly what this package wrote. Anything else is a conflict: keep the backup and fail, so
# NEMESIS keeps the package and nothing unknown is overwritten.
. /data/nemesis/apps/hmg-eq20/scripts/common.sh

main() {
    msg '제거 시작'
    ours_conf=$(expected_md5 audio_effects.conf)
    ours_lib=$(expected_md5 libeq20.so)
    live_conf=$(file_md5 "$conf")
    need_conf=0
    need_lib=0
    if [ "$live_conf" = "$ours_conf" ]; then
        if [ "$(file_md5 "$backup/audio_effects.conf.stock")" != "$stock_conf_md5" ]; then
            msg '제거 중단: 순정 백업이 없거나 손상되었습니다'
            exit 1
        fi
        need_conf=1
    elif [ "$live_conf" != "$stock_conf_md5" ]; then
        msg '제거 중단: audio_effects.conf 가 설치 후 다른 내용으로 바뀌었습니다 (백업 유지)'
        exit 1
    fi
    if [ -e "$lib" ]; then
        if [ "$(file_md5 "$lib")" != "$ours_lib" ]; then
            msg "제거 중단: $lib 가 다른 파일로 바뀌었습니다"
            exit 1
        fi
        need_lib=1
    fi

    if [ "$need_conf" = 1 ] || [ "$need_lib" = 1 ]; then
        remount_rw || { msg '제거 중단: /system 쓰기 전환 실패'; exit 1; }
        if [ "$need_conf" = 1 ] && ! put_file "$backup/audio_effects.conf.stock" "$conf"; then
            remount_ro
            msg '제거 중단: 순정 설정 복원 실패'
            exit 1
        fi
        if [ "$need_lib" = 1 ] && ! rm "$lib"; then
            remount_ro
            msg '제거 중단: 라이브러리 삭제 실패'
            exit 1
        fi
        remount_ro
        if [ "$(file_md5 "$conf")" != "$stock_conf_md5" ] || [ -e "$lib" ]; then
            msg '제거 중단: 복원 확인 실패'
            exit 1
        fi
        msg '오디오 서비스 재시작 (몇 초 무음)'
        restart_media || msg 'warning: mediaserver did not answer; restart the car if audio stays silent'
    fi
    rm -r "$backup" 2>/dev/null
    msg '제거 완료: 순정 상태로 되돌렸습니다'
}

main
