/* eq20 DSP core: 20 half-octave peaking bands, auto preamp, linked peak limiter. Freestanding. */
#ifndef EQ20_DSP_H
#define EQ20_DSP_H

#include <stdint.h>

#define EQ20_BANDS 20
#define EQ20_STEP_MB 50     /* 0.5 dB */
#define EQ20_MIN_MB (-1200) /* AMP vehicle limits */
#define EQ20_MAX_MB 600
#define EQ20_LOW_MAX_MB 300 /* bands at or below EQ20_LOW_HZ */
#define EQ20_LOW_HZ 63
#define EQ20_Q 2.871        /* half-octave bandwidth */

extern const int32_t eq20_center_hz[EQ20_BANDS];

typedef struct {
    float b0, b1, b2, a1, a2;
} eq20_coef_t;

typedef struct {
    uint32_t rate;
    int16_t level_mb[EQ20_BANDS];   /* requested, clamped */
    eq20_coef_t target[EQ20_BANDS];
    eq20_coef_t cur[EQ20_BANDS];
    float z1[EQ20_BANDS][2], z2[EQ20_BANDS][2];
    uint8_t active[EQ20_BANDS];     /* band used by target or still ramping */
    float preamp_target, preamp_cur;
    float lim_gain, lim_release;
    uint32_t limiter_hits;
    int ramping;
} eq20_dsp_t;

/* Freestanding math, exposed for host tests. */
double eq20_sin(double x);
double eq20_cos(double x);
double eq20_exp(double x);

int16_t eq20_clamp_level(int band, int32_t mb);
void eq20_dsp_init(eq20_dsp_t *d, uint32_t rate);
void eq20_dsp_reset_state(eq20_dsp_t *d);
void eq20_dsp_set_levels(eq20_dsp_t *d, const int16_t *mb, int immediate);
int16_t eq20_dsp_preamp_mb(const eq20_dsp_t *d);
/* Processes interleaved stereo int16. accumulate != 0 adds to out with saturation. */
void eq20_dsp_process(eq20_dsp_t *d, const int16_t *in, int16_t *out, uint32_t frames, int accumulate);
void eq20_peaking(double fs, double f0, double gain_db, double q, eq20_coef_t *c);

#endif
