/* Freestanding runtime for the ARM build: mem* and the ARM EABI helpers the compiler may emit. */
#include <stddef.h>
#include <stdint.h>

#include "eq20.h"

#define HIDDEN __attribute__((visibility("hidden")))

HIDDEN void *memcpy(void *d, const void *s, size_t n) {
    uint8_t *dp = (uint8_t *)d;
    const uint8_t *sp = (const uint8_t *)s;
    while (n--) *dp++ = *sp++;
    return d;
}

HIDDEN void *memmove(void *d, const void *s, size_t n) {
    uint8_t *dp = (uint8_t *)d;
    const uint8_t *sp = (const uint8_t *)s;
    if (dp < sp) {
        while (n--) *dp++ = *sp++;
    } else {
        dp += n;
        sp += n;
        while (n--) *--dp = *--sp;
    }
    return d;
}

HIDDEN void *memset(void *d, int c, size_t n) {
    uint8_t *dp = (uint8_t *)d;
    while (n--) *dp++ = (uint8_t)c;
    return d;
}

HIDDEN void __aeabi_memcpy(void *d, const void *s, size_t n) { memcpy(d, s, n); }
HIDDEN void __aeabi_memcpy4(void *d, const void *s, size_t n) { memcpy(d, s, n); }
HIDDEN void __aeabi_memcpy8(void *d, const void *s, size_t n) { memcpy(d, s, n); }
HIDDEN void __aeabi_memmove(void *d, const void *s, size_t n) { memmove(d, s, n); }
HIDDEN void __aeabi_memmove4(void *d, const void *s, size_t n) { memmove(d, s, n); }
HIDDEN void __aeabi_memmove8(void *d, const void *s, size_t n) { memmove(d, s, n); }
/* EABI memset helpers take (dest, n, c). */
HIDDEN void __aeabi_memset(void *d, size_t n, int c) { memset(d, c, n); }
HIDDEN void __aeabi_memset4(void *d, size_t n, int c) { memset(d, c, n); }
HIDDEN void __aeabi_memset8(void *d, size_t n, int c) { memset(d, c, n); }
HIDDEN void __aeabi_memclr(void *d, size_t n) { memset(d, 0, n); }
HIDDEN void __aeabi_memclr4(void *d, size_t n) { memset(d, 0, n); }
HIDDEN void __aeabi_memclr8(void *d, size_t n) { memset(d, 0, n); }

/* Writes the effect's debug words to EQ20_DEBUG_FILE (created 0666 by the daemon), using raw ARM EABI
 * syscalls because the library links no libc. Failures are ignored: the file is diagnostics only. */
static long eq20_sys3(long nr, long a, long b, long c) {
    register long r0 __asm__("r0") = a;
    register long r1 __asm__("r1") = b;
    register long r2 __asm__("r2") = c;
    register long r7 __asm__("r7") = nr;
    __asm__ volatile("svc #0" : "+r"(r0) : "r"(r1), "r"(r2), "r"(r7) : "memory");
    return r0;
}

HIDDEN void eq20_debug_dump(const void *words, uint32_t bytes) {
    long fd = eq20_sys3(5 /* open */, (long)EQ20_DEBUG_FILE, 01 | 01000 /* O_WRONLY|O_TRUNC */, 0);
    if (fd < 0) return;
    eq20_sys3(4 /* write */, fd, (long)words, (long)bytes);
    eq20_sys3(6 /* close */, fd, 0, 0);
}