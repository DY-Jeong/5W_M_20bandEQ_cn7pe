/* eq20 Android 4.4 audio effect library (insert effect, 16-bit stereo, 22.05-96 kHz). */
#include "audio_effect_min.h"
#include "eq20.h"
#include "eq20_dsp.h"

#define EXPORT __attribute__((visibility("default")))
#define MAX_INSTANCES 8

enum { STATE_UNINIT = 0, STATE_INIT, STATE_ACTIVE };

typedef struct {
    const struct effect_interface_s *itf;
    int used;
    int state;
    effect_config_t config;
    eq20_dsp_t dsp;
} eq20_ctx_t;

static const effect_descriptor_t eq20_descriptor = {
    EQ20_TYPE_UUID_INIT,
    EQ20_IMPL_UUID_INIT,
    EFFECT_CONTROL_API_VERSION,
    EFFECT_FLAG_TYPE_INSERT | EFFECT_FLAG_INSERT_LAST,
    200, /* 20 MIPS in 0.1 MIPS units, upper estimate */
    16,  /* KB */
    "HMG 20-band EQ",
    "HMG-Seogaemo"};

static eq20_ctx_t pool[MAX_INSTANCES];

/* See EQ20_CMD_DEBUG. Shared by all instances; written only by the command handler. */
static uint32_t debug_words[EQ20_DEBUG_WORDS];

#ifdef __arm__
void eq20_debug_dump(const void *words, uint32_t bytes); /* eq20_rt.c: writes the state/fxdebug.bin file */
#else
static void eq20_debug_dump(const void *words, uint32_t bytes) {
    (void)words;
    (void)bytes;
}
#endif

static void copy_bytes(void *dst, const void *src, uint32_t n) {
    uint8_t *d = (uint8_t *)dst;
    const uint8_t *s = (const uint8_t *)src;
    while (n--) *d++ = *s++;
}

static int uuid_eq(const effect_uuid_t *a, const effect_uuid_t *b) {
    const uint8_t *x = (const uint8_t *)a, *y = (const uint8_t *)b;
    uint32_t i;
    for (i = 0; i < sizeof(effect_uuid_t); i++)
        if (x[i] != y[i]) return 0;
    return 1;
}

static int rate_ok(uint32_t r) { return r >= 22050 && r <= 96000; }

static int32_t set_config(eq20_ctx_t *c, const effect_config_t *cfg) {
    const buffer_config_t *in = &cfg->inputCfg, *out = &cfg->outputCfg;
    if (in->samplingRate != out->samplingRate || !rate_ok(in->samplingRate)) return -EQ20_EINVAL;
    if (in->channels != AUDIO_CHANNEL_OUT_STEREO || out->channels != AUDIO_CHANNEL_OUT_STEREO) return -EQ20_EINVAL;
    if (in->format != AUDIO_FORMAT_PCM_16_BIT || out->format != AUDIO_FORMAT_PCM_16_BIT) return -EQ20_EINVAL;
    if (out->accessMode != EFFECT_BUFFER_ACCESS_WRITE && out->accessMode != EFFECT_BUFFER_ACCESS_ACCUMULATE)
        return -EQ20_EINVAL;
    if (c->state == STATE_UNINIT || c->dsp.rate != in->samplingRate) {
        int16_t levels[EQ20_BANDS];
        copy_bytes(levels, c->dsp.level_mb, sizeof(levels));
        eq20_dsp_init(&c->dsp, in->samplingRate);
        eq20_dsp_set_levels(&c->dsp, levels, 1); /* keep user levels across rate changes */
    }
    copy_bytes(&c->config, cfg, sizeof(*cfg));
    return 0;
}

static void default_config(effect_config_t *cfg) {
    uint8_t *p = (uint8_t *)cfg;
    uint32_t i;
    for (i = 0; i < sizeof(*cfg); i++) p[i] = 0;
    cfg->inputCfg.samplingRate = cfg->outputCfg.samplingRate = 44100;
    cfg->inputCfg.channels = cfg->outputCfg.channels = AUDIO_CHANNEL_OUT_STEREO;
    cfg->inputCfg.format = cfg->outputCfg.format = AUDIO_FORMAT_PCM_16_BIT;
    cfg->inputCfg.accessMode = EFFECT_BUFFER_ACCESS_READ;
    cfg->outputCfg.accessMode = EFFECT_BUFFER_ACCESS_ACCUMULATE;
    cfg->inputCfg.mask = cfg->outputCfg.mask = EFFECT_CONFIG_ALL;
}

/* Returns value size, or -1 if the parameter is unknown or the buffer too small. */
static int32_t get_param(eq20_ctx_t *c, int32_t id, void *v, uint32_t cap) {
    switch (id) {
    case EQ20_PARAM_NUM_BANDS:
        if (cap < 4) return -1;
        *(int32_t *)v = EQ20_BANDS;
        return 4;
    case EQ20_PARAM_CENTER_FREQS:
        if (cap < 4 * EQ20_BANDS) return -1;
        copy_bytes(v, eq20_center_hz, 4 * EQ20_BANDS);
        return 4 * EQ20_BANDS;
    case EQ20_PARAM_BAND_LEVELS:
        if (cap < 2 * EQ20_BANDS) return -1;
        copy_bytes(v, c->dsp.level_mb, 2 * EQ20_BANDS);
        return 2 * EQ20_BANDS;
    case EQ20_PARAM_LEVEL_LIMITS: {
        int16_t lim[4] = {EQ20_MIN_MB, EQ20_MAX_MB, EQ20_LOW_MAX_MB, EQ20_LOW_HZ};
        if (cap < sizeof(lim)) return -1;
        copy_bytes(v, lim, sizeof(lim));
        return sizeof(lim);
    }
    case EQ20_PARAM_PREAMP:
        if (cap < 2) return -1;
        *(int16_t *)v = eq20_dsp_preamp_mb(&c->dsp);
        return 2;
    case EQ20_PARAM_LIMITER_HITS:
        if (cap < 4) return -1;
        *(uint32_t *)v = c->dsp.limiter_hits;
        return 4;
    default:
        return -2;
    }
}

static int32_t eq20_process(effect_handle_t self, audio_buffer_t *in, audio_buffer_t *out) {
    eq20_ctx_t *c = (eq20_ctx_t *)self;
    if (!c || !in || !out || !in->raw || !out->raw || in->frameCount != out->frameCount) return -EQ20_EINVAL;
    if (c->state != STATE_ACTIVE) return -EQ20_ENODATA;
    eq20_dsp_process(&c->dsp, in->s16, out->s16, (uint32_t)in->frameCount,
                     c->config.outputCfg.accessMode == EFFECT_BUFFER_ACCESS_ACCUMULATE);
    return 0;
}

static int32_t reply_status(uint32_t *replySize, void *reply, int32_t status) {
    if (!replySize || *replySize < sizeof(int32_t) || !reply) return -EQ20_EINVAL;
    *(int32_t *)reply = status;
    *replySize = sizeof(int32_t);
    return 0;
}

static int32_t eq20_command_impl(effect_handle_t self, uint32_t cmd, uint32_t cmdSize, void *cmdData,
                                 uint32_t *replySize, void *reply) {
    eq20_ctx_t *c = (eq20_ctx_t *)self;
    if (!c) return -EQ20_EINVAL;
    debug_words[0] = EQ20_DEBUG_MAGIC;
    debug_words[1]++;
    if (cmd < 16) debug_words[2 + cmd]++;
    else if (cmd != EQ20_CMD_DEBUG) debug_words[18]++;
    switch (cmd) {
    case EQ20_CMD_DEBUG:
        if (!replySize || *replySize < sizeof(debug_words) || !reply) return -EQ20_EINVAL;
        copy_bytes(reply, debug_words, sizeof(debug_words));
        *replySize = sizeof(debug_words);
        return 0;
    case EFFECT_CMD_INIT: {
        effect_config_t cfg;
        int16_t flat[EQ20_BANDS];
        int i;
        for (i = 0; i < EQ20_BANDS; i++) flat[i] = 0;
        default_config(&cfg);
        c->state = STATE_UNINIT;
        eq20_dsp_init(&c->dsp, 44100);
        eq20_dsp_set_levels(&c->dsp, flat, 1);
        set_config(c, &cfg);
        c->state = STATE_INIT;
        return reply_status(replySize, reply, 0);
    }
    case EFFECT_CMD_SET_CONFIG: {
        const effect_config_t *cfg = (const effect_config_t *)cmdData;
        int32_t st;
        debug_words[24] = cmdSize;
        if (cfg && cmdSize >= sizeof(effect_config_t)) {
            debug_words[25] = cfg->inputCfg.samplingRate;
            debug_words[26] = cfg->inputCfg.channels;
            debug_words[27] = cfg->outputCfg.channels;
            debug_words[28] = (uint32_t)cfg->inputCfg.format | (uint32_t)cfg->outputCfg.format << 8 |
                              (uint32_t)cfg->inputCfg.accessMode << 16 | (uint32_t)cfg->outputCfg.accessMode << 24;
        }
        debug_words[29] = EQ20_EINVAL;
        if (cmdSize != sizeof(effect_config_t) || !cmdData) return -EQ20_EINVAL;
        st = set_config(c, cfg);
        debug_words[29] = (uint32_t)-st;
        return reply_status(replySize, reply, st);
    }
    case EFFECT_CMD_GET_CONFIG:
        if (!replySize || *replySize < sizeof(effect_config_t) || !reply) return -EQ20_EINVAL;
        copy_bytes(reply, &c->config, sizeof(effect_config_t));
        *replySize = sizeof(effect_config_t);
        return 0;
    case EFFECT_CMD_RESET:
        eq20_dsp_reset_state(&c->dsp);
        return 0;
    case EFFECT_CMD_ENABLE:
        if (c->state != STATE_INIT) return reply_status(replySize, reply, -EQ20_ENODATA);
        eq20_dsp_reset_state(&c->dsp);
        c->state = STATE_ACTIVE;
        return reply_status(replySize, reply, 0);
    case EFFECT_CMD_DISABLE:
        if (c->state != STATE_ACTIVE) return reply_status(replySize, reply, -EQ20_ENODATA);
        c->state = STATE_INIT;
        return reply_status(replySize, reply, 0);
    case EFFECT_CMD_SET_PARAM: {
        const effect_param_t *p = (const effect_param_t *)cmdData;
        int32_t id;
        uint32_t voff;
        if (!p || cmdSize < sizeof(effect_param_t) + 4 || p->psize != 4) return -EQ20_EINVAL;
        if (cmdSize < sizeof(effect_param_t) + 4 + p->vsize) return -EQ20_EINVAL;
        copy_bytes(&id, p->data, 4);
        voff = 4;
        if (id == EQ20_PARAM_BAND_LEVELS && p->vsize == 2 * EQ20_BANDS) {
            int16_t lv[EQ20_BANDS];
            copy_bytes(lv, p->data + voff, sizeof(lv));
            eq20_dsp_set_levels(&c->dsp, lv, c->state != STATE_ACTIVE);
            return reply_status(replySize, reply, 0);
        }
        if (id == EQ20_PARAM_BAND_LEVEL && p->vsize == 4) {
            int16_t bv[2];
            int16_t lv[EQ20_BANDS];
            copy_bytes(bv, p->data + voff, 4);
            if (bv[0] < 0 || bv[0] >= EQ20_BANDS) return reply_status(replySize, reply, -EQ20_EINVAL);
            copy_bytes(lv, c->dsp.level_mb, sizeof(lv));
            lv[bv[0]] = bv[1];
            eq20_dsp_set_levels(&c->dsp, lv, c->state != STATE_ACTIVE);
            return reply_status(replySize, reply, 0);
        }
        return reply_status(replySize, reply, -EQ20_EINVAL);
    }
    case EFFECT_CMD_GET_PARAM: {
        const effect_param_t *p = (const effect_param_t *)cmdData;
        effect_param_t *r = (effect_param_t *)reply;
        int32_t id, n;
        debug_words[19] = cmdSize;
        debug_words[20] = p && cmdSize >= sizeof(effect_param_t) ? p->psize : 0xFFFFFFFFu;
        debug_words[21] = p && cmdSize >= sizeof(effect_param_t) ? p->vsize : 0xFFFFFFFFu;
        debug_words[22] = replySize ? *replySize : 0xFFFFFFFFu;
        debug_words[23] = 1;
        if (!p || cmdSize < sizeof(effect_param_t) + 4 || p->psize != 4 || !replySize || !r ||
            *replySize < sizeof(effect_param_t) + 4)
            return -EQ20_EINVAL;
        copy_bytes(&id, p->data, 4);
        copy_bytes(r, p, sizeof(effect_param_t) + 4);
        n = get_param(c, id, r->data + 4, *replySize - (uint32_t)(sizeof(effect_param_t) + 4));
        if (n < 0) {
            debug_words[23] = n == -2 ? 3 : 2;
            r->status = -EQ20_EINVAL;
            r->vsize = 0;
        } else {
            debug_words[23] = 0;
            r->status = 0;
            r->vsize = (uint32_t)n;
        }
        *replySize = sizeof(effect_param_t) + 4 + r->vsize;
        return 0;
    }
    case EFFECT_CMD_SET_DEVICE:
    case EFFECT_CMD_SET_VOLUME:
    case EFFECT_CMD_SET_AUDIO_MODE:
    case EFFECT_CMD_SET_INPUT_DEVICE:
        return 0;
    default:
        return -EQ20_EINVAL;
    }
}

/* Records the last command and its return value, then mirrors the debug words to the file the daemon reads
 * (mediaserver stops forwarding commands after a failed SET_CONFIG, so the proprietary command cannot). */
static int32_t eq20_command(effect_handle_t self, uint32_t cmd, uint32_t cmdSize, void *cmdData, uint32_t *replySize,
                            void *reply) {
    int32_t ret = eq20_command_impl(self, cmd, cmdSize, cmdData, replySize, reply);
    debug_words[30] = cmd;
    debug_words[31] = (uint32_t)ret;
    eq20_debug_dump(debug_words, sizeof(debug_words));
    return ret;
}

static int32_t eq20_get_descriptor_itf(effect_handle_t self, effect_descriptor_t *d) {
    if (!self || !d) return -EQ20_EINVAL;
    copy_bytes(d, &eq20_descriptor, sizeof(*d));
    return 0;
}

static const struct effect_interface_s eq20_itf = {eq20_process, eq20_command, eq20_get_descriptor_itf, 0};

static int32_t lib_create(const effect_uuid_t *uuid, int32_t session, int32_t io, effect_handle_t *handle) {
    int i;
    (void)session;
    (void)io;
    if (!uuid || !handle || !uuid_eq(uuid, &eq20_descriptor.uuid)) return -EQ20_EINVAL;
    for (i = 0; i < MAX_INSTANCES; i++) {
        if (!pool[i].used) {
            uint8_t *p = (uint8_t *)&pool[i];
            uint32_t k;
            for (k = 0; k < sizeof(pool[i]); k++) p[k] = 0;
            pool[i].used = 1;
            pool[i].itf = &eq20_itf;
            pool[i].state = STATE_UNINIT;
            *handle = (effect_handle_t)&pool[i];
            return 0;
        }
    }
    return -EQ20_EINVAL;
}

static int32_t lib_release(effect_handle_t handle) {
    eq20_ctx_t *c = (eq20_ctx_t *)handle;
    if (!c || c < pool || c >= pool + MAX_INSTANCES || !c->used) return -EQ20_EINVAL;
    c->used = 0;
    c->state = STATE_UNINIT;
    return 0;
}

static int32_t lib_get_descriptor(const effect_uuid_t *uuid, effect_descriptor_t *d) {
    if (!uuid || !d || !uuid_eq(uuid, &eq20_descriptor.uuid)) return -EQ20_EINVAL;
    copy_bytes(d, &eq20_descriptor, sizeof(*d));
    return 0;
}

EXPORT const audio_effect_library_t AELI = {
    AUDIO_EFFECT_LIBRARY_TAG,
    EFFECT_LIBRARY_API_VERSION,
    "HMG 20-band EQ Library",
    "HMG-Seogaemo",
    lib_create,
    lib_release,
    lib_get_descriptor};
