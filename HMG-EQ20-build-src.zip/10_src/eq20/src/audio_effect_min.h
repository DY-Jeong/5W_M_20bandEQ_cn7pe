/*
 * Minimal subset of the audio effect ABI (hardware/audio_effect.h) needed by eq20, in the layout the head unit
 * uses: its Android 4.4 build carries the 5.0 library interface (EFFECT_LIBRARY_API_VERSION 3.0, no
 * query_num_effects/query_effect; every stock /system/lib/soundfx library has a 28-byte AELI with version
 * 0x00030000, and EffectsFactory rejects 2.0 with "bad lib version 00020000"). EFFECT_CONTROL_API_VERSION is
 * still 2.0 (stock descriptors). Layouts must match the 32-bit ARM ABI used by mediaserver on the head unit.
 */
#ifndef EQ20_AUDIO_EFFECT_MIN_H
#define EQ20_AUDIO_EFFECT_MIN_H

#include <stddef.h>
#include <stdint.h>

#define EQ20_ENODATA 61
#define EQ20_EINVAL 22

typedef struct effect_uuid_s {
    uint32_t timeLow;
    uint16_t timeMid;
    uint16_t timeHiAndVersion;
    uint16_t clockSeq;
    uint8_t node[6];
} effect_uuid_t;

#define EFFECT_STRING_LEN_MAX 64

typedef struct effect_descriptor_s {
    effect_uuid_t type;
    effect_uuid_t uuid;
    uint32_t apiVersion;
    uint32_t flags;
    uint16_t cpuLoad;
    uint16_t memoryUsage;
    char name[EFFECT_STRING_LEN_MAX];
    char implementor[EFFECT_STRING_LEN_MAX];
} effect_descriptor_t;

typedef struct audio_buffer_s {
    size_t frameCount;
    union {
        void *raw;
        int32_t *s32;
        int16_t *s16;
        uint8_t *u8;
    };
} audio_buffer_t;

typedef int32_t (*buffer_function_t)(void *cookie, audio_buffer_t *buffer);

typedef struct buffer_provider_s {
    buffer_function_t getBuffer;
    buffer_function_t releaseBuffer;
    void *cookie;
} buffer_provider_t;

typedef struct buffer_config_s {
    audio_buffer_t buffer;
    uint32_t samplingRate;
    uint32_t channels;
    buffer_provider_t bufferProvider;
    uint8_t format;
    uint8_t accessMode;
    uint16_t mask;
} buffer_config_t;

typedef struct effect_config_s {
    buffer_config_t inputCfg;
    buffer_config_t outputCfg;
} effect_config_t;

typedef struct effect_param_s {
    int32_t status;
    uint32_t psize;
    uint32_t vsize;
    char data[];
} effect_param_t;

struct effect_interface_s;
typedef struct effect_interface_s **effect_handle_t;

struct effect_interface_s {
    int32_t (*process)(effect_handle_t self, audio_buffer_t *inBuffer, audio_buffer_t *outBuffer);
    int32_t (*command)(effect_handle_t self, uint32_t cmdCode, uint32_t cmdSize, void *pCmdData,
                       uint32_t *replySize, void *pReplyData);
    int32_t (*get_descriptor)(effect_handle_t self, effect_descriptor_t *pDescriptor);
    int32_t (*process_reverse)(effect_handle_t self, audio_buffer_t *inBuffer, audio_buffer_t *outBuffer);
};

typedef struct audio_effect_library_s {
    uint32_t tag;
    uint32_t version;
    const char *name;
    const char *implementor;
    int32_t (*create_effect)(const effect_uuid_t *uuid, int32_t sessionId, int32_t ioId, effect_handle_t *pHandle);
    int32_t (*release_effect)(effect_handle_t handle);
    int32_t (*get_descriptor)(const effect_uuid_t *uuid, effect_descriptor_t *pDescriptor);
} audio_effect_library_t;

#define EFFECT_MAKE_API_VERSION(M, m) (((M) << 16) | ((m) & 0xFFFF))
#define EFFECT_CONTROL_API_VERSION EFFECT_MAKE_API_VERSION(2, 0)
#define EFFECT_LIBRARY_API_VERSION EFFECT_MAKE_API_VERSION(3, 0)
#define AUDIO_EFFECT_LIBRARY_TAG ((('A') << 24) | (('E') << 16) | (('L') << 8) | ('T'))

#define EFFECT_FLAG_TYPE_INSERT 0x00000000u
#define EFFECT_FLAG_INSERT_LAST 0x00000008u

enum effect_command_e {
    EFFECT_CMD_INIT = 0,
    EFFECT_CMD_SET_CONFIG = 1,
    EFFECT_CMD_RESET = 2,
    EFFECT_CMD_ENABLE = 3,
    EFFECT_CMD_DISABLE = 4,
    EFFECT_CMD_SET_PARAM = 5,
    EFFECT_CMD_SET_PARAM_DEFERRED = 6,
    EFFECT_CMD_SET_PARAM_COMMIT = 7,
    EFFECT_CMD_GET_PARAM = 8,
    EFFECT_CMD_SET_DEVICE = 9,
    EFFECT_CMD_SET_VOLUME = 10,
    EFFECT_CMD_SET_AUDIO_MODE = 11,
    EFFECT_CMD_SET_CONFIG_REVERSE = 12,
    EFFECT_CMD_SET_INPUT_DEVICE = 13,
    EFFECT_CMD_GET_CONFIG = 14,
    EFFECT_CMD_GET_CONFIG_REVERSE = 15
};

/* enum effect_buffer_access_e order in AOSP: WRITE, READ, ACCUMULATE (the car's mediaserver sends input 1 = READ,
 * output 2 = ACCUMULATE for a session insert effect). */
#define EFFECT_BUFFER_ACCESS_WRITE 0
#define EFFECT_BUFFER_ACCESS_READ 1
#define EFFECT_BUFFER_ACCESS_ACCUMULATE 2

#define EFFECT_CONFIG_BUFFER 0x0001
#define EFFECT_CONFIG_SMP_RATE 0x0002
#define EFFECT_CONFIG_CHANNELS 0x0004
#define EFFECT_CONFIG_FORMAT 0x0008
#define EFFECT_CONFIG_ACC_MODE 0x0010
#define EFFECT_CONFIG_PROVIDER 0x0020
#define EFFECT_CONFIG_ALL 0x003f

#define AUDIO_CHANNEL_OUT_STEREO 0x3u
#define AUDIO_FORMAT_PCM_16_BIT 0x1u

#if defined(__arm__)
_Static_assert(sizeof(effect_config_t) == 64, "effect_config_t must match Android 4.4 ARM");
_Static_assert(sizeof(effect_descriptor_t) == 172, "effect_descriptor_t must match Android 4.4 ARM");
_Static_assert(sizeof(effect_param_t) == 12, "effect_param_t header");
#endif

#endif
