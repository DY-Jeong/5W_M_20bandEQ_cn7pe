/* Public interface of the eq20 effect: UUIDs and parameter IDs used by the Seogaemo app. */
#ifndef EQ20_H
#define EQ20_H

/* type  e09686bc-ec86-47da-9b86-4b1ee499e6f3 (own type, so stock EQ clients never pick it)
 * uuid  f3bc120f-2838-4417-bec2-8b98750945bf (implementation, referenced by audio_effects.conf) */
#define EQ20_TYPE_UUID_INIT {0xe09686bc, 0xec86, 0x47da, 0x9b86, {0x4b, 0x1e, 0xe4, 0x99, 0xe6, 0xf3}}
#define EQ20_IMPL_UUID_INIT {0xf3bc120f, 0x2838, 0x4417, 0xbec2, {0x8b, 0x98, 0x75, 0x09, 0x45, 0xbf}}

/* All parameter IDs are int32 (psize 4). Values are little-endian. */
#define EQ20_PARAM_NUM_BANDS 0    /* get int32: 20 */
#define EQ20_PARAM_CENTER_FREQS 1 /* get int32[20] Hz */
#define EQ20_PARAM_BAND_LEVELS 2  /* get/set int16[20] millibels, clamped to the limits, 50 mB grid */
#define EQ20_PARAM_LEVEL_LIMITS 3 /* get int16[4]: min mB, max mB, low-band max mB, low-band edge Hz */
#define EQ20_PARAM_PREAMP 4       /* get int16 mB: automatic -(highest band boost) */
#define EQ20_PARAM_LIMITER_HITS 5 /* get uint32: clip-prevention events since create */
#define EQ20_PARAM_BAND_LEVEL 6   /* set int16[2]: band index, millibels */

/* Diagnostics (proprietary command, reply uint32[EQ20_DEBUG_WORDS]): magic EQ20_DEBUG_MAGIC, total commands,
 * count per command code 0..15, commands >= 16, then for the last EFFECT_CMD_GET_PARAM: cmdSize, psize, vsize,
 * replySize (as received), result (0 ok, 1 header/size check, 2 value buffer too small, 3 unknown parameter);
 * then for the last EFFECT_CMD_SET_CONFIG: cmdSize, input rate, input channels, output channels,
 * formats/access modes packed as in.format | out.format << 8 | in.access << 16 | out.access << 24, result (0 or errno);
 * then the last command code and its return value. The ARM build also writes the words to EQ20_DEBUG_FILE after every
 * command. */
#define EQ20_DEBUG_FILE "/data/nemesis/apps/hmg-eq20/state/fxdebug.bin"
#define EQ20_CMD_DEBUG 0x10E20
#define EQ20_DEBUG_MAGIC 0xE20D
#define EQ20_DEBUG_WORDS 32

#endif
