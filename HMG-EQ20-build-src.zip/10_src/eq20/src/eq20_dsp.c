#include "eq20_dsp.h"

const int32_t eq20_center_hz[EQ20_BANDS] = {
    22, 31, 44, 63, 88, 125, 177, 250, 355, 500,
    710, 1000, 1400, 2000, 2800, 4000, 5600, 8000, 11000, 16000};

#define EQ20_PI 3.14159265358979323846
#define LIMIT_THRESHOLD 32768.0f /* only prevents clipping; flat settings stay bit-exact */
#define RAMP_BLOCK 32
#define RAMP_SNAP 1e-6f

/* Series sin/cos after reduction to [-pi, pi]; enough terms for full double precision there. */
static double reduce(double x) {
    while (x > EQ20_PI) x -= 2.0 * EQ20_PI;
    while (x < -EQ20_PI) x += 2.0 * EQ20_PI;
    return x;
}

double eq20_sin(double x) {
    double term, sum;
    int n;
    x = reduce(x);
    term = x;
    sum = x;
    for (n = 1; n < 14; n++) {
        term *= -x * x / ((2.0 * n) * (2.0 * n + 1.0));
        sum += term;
    }
    return sum;
}

double eq20_cos(double x) {
    double term = 1.0, sum = 1.0;
    int n;
    x = reduce(x);
    for (n = 1; n < 14; n++) {
        term *= -x * x / ((2.0 * n - 1.0) * (2.0 * n));
        sum += term;
    }
    return sum;
}

/* exp by scaling and squaring: e^x = (e^(x/2^k))^(2^k) with |x/2^k| <= 0.5. */
double eq20_exp(double x) {
    int k = 0, n;
    double term = 1.0, sum = 1.0;
    while (x > 0.5 || x < -0.5) {
        x *= 0.5;
        k++;
    }
    for (n = 1; n < 18; n++) {
        term *= x / n;
        sum += term;
    }
    while (k-- > 0) sum *= sum;
    return sum;
}

int16_t eq20_clamp_level(int band, int32_t mb) {
    int32_t max = eq20_center_hz[band] <= EQ20_LOW_HZ ? EQ20_LOW_MAX_MB : EQ20_MAX_MB;
    int32_t q;
    if (mb < EQ20_MIN_MB) mb = EQ20_MIN_MB;
    if (mb > max) mb = max;
    /* round to the 0.5 dB grid, half away from zero */
    q = mb >= 0 ? (mb + EQ20_STEP_MB / 2) / EQ20_STEP_MB : -((-mb + EQ20_STEP_MB / 2) / EQ20_STEP_MB);
    return (int16_t)(q * EQ20_STEP_MB);
}

/* RBJ Audio EQ Cookbook peaking filter, a0 normalized. */
void eq20_peaking(double fs, double f0, double gain_db, double q, eq20_coef_t *c) {
    double a = eq20_exp(gain_db / 40.0 * 2.302585092994046);
    double w0 = 2.0 * EQ20_PI * f0 / fs;
    double cw = eq20_cos(w0), alpha = eq20_sin(w0) / (2.0 * q);
    double a0 = 1.0 + alpha / a;
    c->b0 = (float)((1.0 + alpha * a) / a0);
    c->b1 = (float)((-2.0 * cw) / a0);
    c->b2 = (float)((1.0 - alpha * a) / a0);
    c->a1 = (float)((-2.0 * cw) / a0);
    c->a2 = (float)((1.0 - alpha / a) / a0);
}

static void zero_bytes(void *p, uint32_t n) {
    uint8_t *b = (uint8_t *)p;
    while (n--) *b++ = 0;
}

void eq20_dsp_reset_state(eq20_dsp_t *d) {
    zero_bytes(d->z1, sizeof(d->z1));
    zero_bytes(d->z2, sizeof(d->z2));
    d->lim_gain = 1.0f;
}

void eq20_dsp_init(eq20_dsp_t *d, uint32_t rate) {
    int16_t flat[EQ20_BANDS];
    int i;
    zero_bytes(d, sizeof(*d));
    d->rate = rate;
    /* 50 ms release time constant */
    d->lim_release = (float)(1.0 - eq20_exp(-1.0 / (0.05 * (double)rate)));
    for (i = 0; i < EQ20_BANDS; i++) flat[i] = 0;
    eq20_dsp_reset_state(d);
    eq20_dsp_set_levels(d, flat, 1);
}

int16_t eq20_dsp_preamp_mb(const eq20_dsp_t *d) {
    int i, max = 0;
    for (i = 0; i < EQ20_BANDS; i++)
        if (d->level_mb[i] > max) max = d->level_mb[i];
    return (int16_t)-max;
}

void eq20_dsp_set_levels(eq20_dsp_t *d, const int16_t *mb, int immediate) {
    int i;
    for (i = 0; i < EQ20_BANDS; i++) {
        d->level_mb[i] = eq20_clamp_level(i, mb[i]);
        eq20_peaking((double)d->rate, (double)eq20_center_hz[i], d->level_mb[i] / 100.0, EQ20_Q, &d->target[i]);
        if (d->level_mb[i] != 0) d->active[i] = 1;
        if (immediate) {
            d->cur[i] = d->target[i];
            d->active[i] = d->level_mb[i] != 0;
            if (!d->active[i]) d->z1[i][0] = d->z1[i][1] = d->z2[i][0] = d->z2[i][1] = 0.0f;
        }
    }
    d->preamp_target = (float)eq20_exp(eq20_dsp_preamp_mb(d) / 2000.0 * 2.302585092994046);
    if (immediate) d->preamp_cur = d->preamp_target;
    d->ramping = !immediate;
}

static float approach(float cur, float target, int *moving) {
    float next = cur + (target - cur) * 0.25f;
    float diff = target - next;
    if (diff < RAMP_SNAP && diff > -RAMP_SNAP) return target;
    *moving = 1;
    return next;
}

static void ramp_step(eq20_dsp_t *d) {
    int i, moving = 0;
    for (i = 0; i < EQ20_BANDS; i++) {
        eq20_coef_t *c = &d->cur[i];
        const eq20_coef_t *t = &d->target[i];
        int band_moving = 0;
        if (!d->active[i]) continue;
        c->b0 = approach(c->b0, t->b0, &band_moving);
        c->b1 = approach(c->b1, t->b1, &band_moving);
        c->b2 = approach(c->b2, t->b2, &band_moving);
        c->a1 = approach(c->a1, t->a1, &band_moving);
        c->a2 = approach(c->a2, t->a2, &band_moving);
        if (!band_moving && d->level_mb[i] == 0) {
            d->active[i] = 0; /* reached flat: identity filter, drop it */
            d->z1[i][0] = d->z1[i][1] = d->z2[i][0] = d->z2[i][1] = 0.0f;
        }
        moving |= band_moving;
    }
    d->preamp_cur = approach(d->preamp_cur, d->preamp_target, &moving);
    d->ramping = moving;
}

static int16_t sat16(float v) {
    if (v > 32767.0f) return 32767;
    if (v < -32768.0f) return -32768;
    return (int16_t)(v >= 0.0f ? v + 0.5f : v - 0.5f);
}

void eq20_dsp_process(eq20_dsp_t *d, const int16_t *in, int16_t *out, uint32_t frames, int accumulate) {
    uint32_t f = 0;
    while (f < frames) {
        uint32_t end = frames - f > RAMP_BLOCK ? f + RAMP_BLOCK : frames;
        if (d->ramping) ramp_step(d);
        for (; f < end; f++) {
            float s[2];
            int ch, i;
            float peak;
            s[0] = (float)in[2 * f];
            s[1] = (float)in[2 * f + 1];
            for (i = 0; i < EQ20_BANDS; i++) {
                const eq20_coef_t *c = &d->cur[i];
                if (!d->active[i]) continue;
                for (ch = 0; ch < 2; ch++) {
                    float x = s[ch];
                    float y = c->b0 * x + d->z1[i][ch];
                    d->z1[i][ch] = c->b1 * x - c->a1 * y + d->z2[i][ch];
                    d->z2[i][ch] = c->b2 * x - c->a2 * y;
                    s[ch] = y;
                }
            }
            s[0] *= d->preamp_cur;
            s[1] *= d->preamp_cur;
            peak = s[0] < 0 ? -s[0] : s[0];
            if ((s[1] < 0 ? -s[1] : s[1]) > peak) peak = s[1] < 0 ? -s[1] : s[1];
            if (peak * d->lim_gain > LIMIT_THRESHOLD) {
                d->lim_gain = LIMIT_THRESHOLD / peak; /* instant attack, linked channels */
                d->limiter_hits++;
            } else if (d->lim_gain < 1.0f) {
                d->lim_gain += (1.0f - d->lim_gain) * d->lim_release;
            }
            for (ch = 0; ch < 2; ch++) {
                float v = s[ch] * d->lim_gain;
                if (accumulate) v += (float)out[2 * f + ch];
                out[2 * f + ch] = sat16(v);
            }
        }
    }
}
