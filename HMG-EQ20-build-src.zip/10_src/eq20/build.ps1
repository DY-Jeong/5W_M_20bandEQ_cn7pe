# Builds and tests the eq20 effect library.
#  1. host test (Windows x86_64) against real libm
#  2. libeq20.so for the head unit (ARMv7, no libc dependency, Android 4.4 linker compatible)
#  3. ELF loadability checks
# Zig 0.13 is used as the C toolchain; it is fetched once into ..\eq_probe\.build-tools.
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$tools = Join-Path (Split-Path $root) 'eq_probe\.build-tools'
$zigDir = Join-Path $tools 'zig-windows-x86_64-0.13.0'
$zig = Join-Path $zigDir 'zig.exe'
$out = Join-Path $root 'out'

if (-not (Test-Path $zig)) {
    New-Item -ItemType Directory -Force $tools | Out-Null
    [Net.ServicePointManager]::SecurityProtocol = 'Tls12'
    $zip = Join-Path $tools 'zig.zip'
    Invoke-WebRequest 'https://ziglang.org/download/0.13.0/zig-windows-x86_64-0.13.0.zip' -OutFile $zip -UseBasicParsing
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [IO.Compression.ZipFile]::ExtractToDirectory($zip, $tools)
    Remove-Item $zip
}

function Invoke-Native([string]$exe, [string[]]$argv) {
    $saved = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try {
        & $exe @argv 2>&1 | ForEach-Object { "$_" }
    } finally {
        $ErrorActionPreference = $saved
    }
    if ($LASTEXITCODE -ne 0) { throw "$exe $($argv[0]) failed with exit code $LASTEXITCODE" }
}

New-Item -ItemType Directory -Force $out | Out-Null
$src = Join-Path $root 'src'
$warn = @('-std=c11', '-Wall', '-Wextra', '-Werror', '-Wno-unused-parameter')

$testExe = Join-Path $out 'eq20_test.exe'
Invoke-Native $zig (@('cc', '-O2') + $warn + @('-Wno-gnu-variable-sized-type-not-at-end', '-D_USE_MATH_DEFINES', '-o', $testExe,
        (Join-Path $root 'test\eq20_test.c'), "$src\eq20_effect.c", "$src\eq20_dsp.c"))
Invoke-Native $testExe @()

$so = Join-Path $out 'libeq20.so'
# Compile to objects and link with lld directly: zig cc -shared would add compiler-rt (with a bundled
# libm) as ~370 weak exports. --no-undefined proves the code needs no runtime helper at all.
$objs = @()
foreach ($c in 'eq20_effect', 'eq20_dsp', 'eq20_rt') {
    $o = Join-Path $out "$c.arm.o"
    Invoke-Native $zig (@('cc', '-c', '-target', 'arm-linux-musleabihf', '-mcpu=cortex_a7', '-O2', '-fPIC',
            '-ffreestanding', '-fvisibility=hidden', '-fno-unwind-tables', '-fno-asynchronous-unwind-tables',
            '-fno-exceptions') + $warn + @('-o', $o, "$src\$c.c"))
    $objs += $o
}
Invoke-Native $zig (@('ld.lld', '-shared', '--hash-style=sysv', '-soname', 'libeq20.so', '--no-undefined',
        '-Bsymbolic', '-z', 'max-page-size=4096', '-z', 'noexecstack', '-s', '-o', $so) + $objs)
Invoke-Native python @((Join-Path $root 'test\check_elf.py'), $so)

"libeq20.so md5=$((Get-FileHash $so -Algorithm MD5).Hash.ToLowerInvariant()) bytes=$((Get-Item $so).Length)"
