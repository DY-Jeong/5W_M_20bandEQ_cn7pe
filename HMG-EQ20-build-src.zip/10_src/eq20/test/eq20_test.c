/* Host tests for eq20 (DSP math, frequency response, limiter, effect command interface). */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "../src/audio_effect_min.h"
#include "../src/eq20.h"
#include "../src/eq20_dsp.h"

extern const audio_effect_library_t AELI;

static int failures;
#define CHECK(cond, ...)                         \
    do {                                         \
        if (!(cond)) {                           \
            failures++;                          \
            printf("FAIL %s:%d ", __FILE__, __LINE__); \
            printf(__VA_ARGS__);                 \
            printf("\n");                        \
        }                                        \
    } while (0)

static const effect_uuid_t impl_uuid = EQ20_IMPL_UUID_INIT;

static void test_math(void) {
    double x, e_sin = 0, e_cos = 0, e_exp = 0;
    for (x = -12.0; x <= 12.0; x += 0.001) {
        double d = fabs(eq20_sin(x) - sin(x));
        if (d > e_sin) e_sin = d;
        d = fabs(eq20_cos(x) - cos(x));
        if (d > e_cos) e_cos = d;
    }
    for (x = -10.0; x <= 10.0; x += 0.001) {
        double d = fabs(eq20_exp(x) - exp(x)) / exp(x);
        if (d > e_exp) e_exp = d;
    }
    CHECK(e_sin < 1e-12 && e_cos < 1e-12 && e_exp < 1e-12, "math err sin %g cos %g exp %g", e_sin, e_cos, e_exp);
    printf("PASS math: max error sin %.1e cos %.1e exp(rel) %.1e\n", e_sin, e_cos, e_exp);
}

static void test_clamp(void) {
    CHECK(eq20_clamp_level(0, 1200) == 300, "22 Hz max");
    CHECK(eq20_clamp_level(3, 1200) == 300, "63 Hz max");
    CHECK(eq20_clamp_level(4, 1200) == 600, "88 Hz max");
    CHECK(eq20_clamp_level(10, -5000) == -1200, "min");
    CHECK(eq20_clamp_level(10, 74) == 50 && eq20_clamp_level(10, 75) == 100, "round up");
    CHECK(eq20_clamp_level(10, -74) == -50 && eq20_clamp_level(10, -75) == -100, "round down");
    printf("PASS level clamp: AMP limits -12..+6 dB, <=63 Hz +3 dB, 0.5 dB grid\n");
}

/* Gain in dB at f after settling, measured on the left channel with an amplitude-a sine. */
static double measure(eq20_dsp_t *d, double f, double amp, int16_t *peak_out) {
    enum { N = 48000 };
    static int16_t in[2 * N], out[2 * N];
    double sin_in = 0, sin_out = 0;
    int i, start = N / 2, pk = 0;
    for (i = 0; i < N; i++) {
        int16_t v = (int16_t)lrint(amp * sin(2.0 * M_PI * f * i / d->rate));
        in[2 * i] = in[2 * i + 1] = v;
    }
    eq20_dsp_reset_state(d);
    eq20_dsp_process(d, in, out, N, 0);
    for (i = start; i < N; i++) {
        sin_in += (double)in[2 * i] * in[2 * i];
        sin_out += (double)out[2 * i] * out[2 * i];
        if (abs(out[2 * i]) > pk) pk = abs(out[2 * i]);
    }
    if (peak_out) *peak_out = (int16_t)(pk > 32767 ? 32767 : pk);
    return 10.0 * log10(sin_out / sin_in);
}

static void test_response(uint32_t rate) {
    static eq20_dsp_t d;
    int16_t lv[EQ20_BANDS];
    int b, i;
    double worst = 0;
    eq20_dsp_init(&d, rate);
    for (b = 0; b < EQ20_BANDS; b++) {
        int16_t boost = eq20_center_hz[b] <= EQ20_LOW_HZ ? EQ20_LOW_MAX_MB : EQ20_MAX_MB;
        double g;
        for (i = 0; i < EQ20_BANDS; i++) lv[i] = 0;
        lv[b] = -1200;
        eq20_dsp_set_levels(&d, lv, 1);
        g = measure(&d, eq20_center_hz[b], 8000.0, NULL);
        if (fabs(g + 12.0) > worst) worst = fabs(g + 12.0);
        CHECK(fabs(g + 12.0) < 0.1, "rate %u band %d Hz cut -12 measured %.3f", rate, eq20_center_hz[b], g);
        lv[b] = boost;
        eq20_dsp_set_levels(&d, lv, 1);
        /* preamp = -boost, so a boosted center is unity overall and a far band shows the preamp */
        g = measure(&d, eq20_center_hz[b], 8000.0, NULL);
        if (fabs(g) > worst) worst = fabs(g);
        CHECK(fabs(g) < 0.1, "rate %u band %d Hz boost+preamp measured %.3f", rate, eq20_center_hz[b], g);
    }
    for (i = 0; i < EQ20_BANDS; i++) lv[i] = 0;
    lv[10] = 600; /* 710 Hz */
    eq20_dsp_set_levels(&d, lv, 1);
    {
        double far = measure(&d, 5600.0, 8000.0, NULL);
        CHECK(fabs(far + 6.0) < 0.15, "rate %u far band shows preamp, measured %.3f", rate, far);
    }
    printf("PASS response @%u Hz: 20 bands, cut -12 dB and boost+preamp within %.3f dB\n", rate, worst);
}

static void test_flat_bitexact(void) {
    static eq20_dsp_t d;
    enum { N = 8192 };
    static int16_t in[2 * N], out[2 * N];
    int i, diff = 0;
    eq20_dsp_init(&d, 44100);
    srand(1);
    for (i = 0; i < 2 * N; i++) in[i] = (int16_t)((rand() & 0xffff) - 32768);
    in[0] = -32768;
    in[1] = 32767;
    eq20_dsp_process(&d, in, out, N, 0);
    for (i = 0; i < 2 * N; i++) diff += in[i] != out[i];
    CHECK(diff == 0 && d.limiter_hits == 0, "flat differs in %d samples, limiter %u", diff, d.limiter_hits);
    printf("PASS flat settings are bit-exact on full-scale noise\n");
}

static void test_headroom(void) {
    static eq20_dsp_t d;
    int16_t lv[EQ20_BANDS], pk;
    int i;
    eq20_dsp_init(&d, 44100);
    for (i = 0; i < EQ20_BANDS; i++) lv[i] = 0;
    lv[11] = 600; /* single +6 dB band at 1 kHz on a full-scale 1 kHz sine */
    eq20_dsp_set_levels(&d, lv, 1);
    measure(&d, 1000.0, 32767.0, &pk);
    CHECK(d.limiter_hits == 0, "single boost should fit via preamp, limiter %u", d.limiter_hits);
    for (i = 0; i < EQ20_BANDS; i++) lv[i] = 600; /* everything at max, overlapping bands sum above +6 */
    eq20_dsp_set_levels(&d, lv, 1);
    {
        enum { N = 44100 };
        static int16_t in[2 * N], out[2 * N];
        int clipped = 0;
        srand(2);
        for (i = 0; i < 2 * N; i++) in[i] = (int16_t)((rand() & 0xffff) - 32768);
        eq20_dsp_process(&d, in, out, N, 0);
        for (i = 0; i < 2 * N; i++) clipped += out[i] == 32767 || out[i] == -32768;
        CHECK(clipped < 2 * N / 1000, "too many samples at the rails: %d", clipped);
        printf("PASS headroom: single +6 dB band needs no limiting; all-max noise limited (%u events, %d rail samples)\n",
               d.limiter_hits, clipped);
    }
}

static void test_ramp(void) {
    static eq20_dsp_t d;
    enum { N = 4096 };
    static int16_t in[2 * N], out[2 * N];
    int16_t lv[EQ20_BANDS];
    int i, ok = 1;
    eq20_dsp_init(&d, 44100);
    for (i = 0; i < N; i++) in[2 * i] = in[2 * i + 1] = (int16_t)lrint(10000.0 * sin(2.0 * M_PI * 1000.0 * i / 44100));
    eq20_dsp_process(&d, in, out, N, 0);
    for (i = 0; i < EQ20_BANDS; i++) lv[i] = (int16_t)(i % 2 ? -1200 : 600);
    eq20_dsp_set_levels(&d, lv, 0);
    CHECK(d.ramping, "change while active ramps");
    eq20_dsp_process(&d, in, out, N, 0);
    CHECK(!d.ramping, "ramp finished within %d frames", N);
    for (i = 0; i < EQ20_BANDS; i++) ok &= memcmp(&d.cur[i], &d.target[i], sizeof(eq20_coef_t)) == 0;
    CHECK(ok, "coefficients reached target");
    for (i = 0; i < EQ20_BANDS; i++) lv[i] = 0;
    eq20_dsp_set_levels(&d, lv, 0);
    eq20_dsp_process(&d, in, out, N, 0);
    for (i = 0; i < EQ20_BANDS; i++) ok &= !d.active[i];
    CHECK(ok && !d.ramping, "back to flat drops all bands");
    printf("PASS ramp: level changes glide in under %d frames and flat bands drop out\n", N);
}

static int32_t cmd(effect_handle_t h, uint32_t code, uint32_t size, void *data, uint32_t *rs, void *reply) {
    return (*h)->command(h, code, size, data, rs, reply);
}

static int32_t set_levels(effect_handle_t h, const int16_t *lv) {
    struct {
        effect_param_t p;
        int32_t id;
        int16_t v[EQ20_BANDS];
    } m;
    int32_t st = 99;
    uint32_t rs = 4;
    m.p.status = 0;
    m.p.psize = 4;
    m.p.vsize = sizeof(m.v);
    m.id = EQ20_PARAM_BAND_LEVELS;
    memcpy(m.v, lv, sizeof(m.v));
    if (cmd(h, EFFECT_CMD_SET_PARAM, sizeof(m), &m, &rs, &st) != 0) return -1000;
    return st;
}

static int32_t get_param(effect_handle_t h, int32_t id, void *val, uint32_t cap) {
    struct {
        effect_param_t p;
        int32_t id;
    } q = {{0, 4, 0}, id};
    struct {
        effect_param_t p;
        int32_t id;
        uint8_t v[256];
    } r;
    uint32_t rs = sizeof(effect_param_t) + 4 + cap;
    if (cmd(h, EFFECT_CMD_GET_PARAM, sizeof(q), &q, &rs, &r) != 0) return -1000;
    if (r.p.status != 0) return r.p.status;
    memcpy(val, r.v, r.p.vsize);
    return (int32_t)r.p.vsize;
}

static void make_cfg(effect_config_t *c, uint32_t rate, uint32_t ch, uint8_t fmt, uint8_t acc) {
    memset(c, 0, sizeof(*c));
    c->inputCfg.samplingRate = c->outputCfg.samplingRate = rate;
    c->inputCfg.channels = c->outputCfg.channels = ch;
    c->inputCfg.format = c->outputCfg.format = fmt;
    c->inputCfg.accessMode = EFFECT_BUFFER_ACCESS_READ;
    c->outputCfg.accessMode = acc;
    c->inputCfg.mask = c->outputCfg.mask = EFFECT_CONFIG_ALL;
}

static void test_interface(void) {
    effect_handle_t h, extra[8];
    effect_uuid_t bad = impl_uuid;
    effect_descriptor_t desc;
    effect_config_t cfg, got;
    uint32_t rs;
    int32_t st, v32, freqs[EQ20_BANDS];
    int16_t lv[EQ20_BANDS], back[EQ20_BANDS], lim[4], pre;
    int16_t in[2 * 64], out[2 * 64];
    audio_buffer_t bi, bo;
    int i, made;

    CHECK(AELI.tag == AUDIO_EFFECT_LIBRARY_TAG && AELI.version == 0x00030000, "AELI tag/version 3.0 (head unit layout)");
    CHECK(sizeof(AELI) == 2 * sizeof(uint32_t) + 5 * sizeof(void *), "AELI has the 3.0 layout without query functions");
    CHECK(AELI.get_descriptor(&impl_uuid, &desc) == 0 && desc.apiVersion == 0x00020000 &&
              strcmp(desc.name, "HMG 20-band EQ") == 0 && desc.flags == 0x8,
          "descriptor");
    bad.node[5] ^= 1;
    CHECK(AELI.create_effect(&bad, 13, 101, &h) != 0, "wrong uuid refused");
    CHECK(AELI.create_effect(&impl_uuid, 13, 101, &h) == 0, "create");

    rs = 4;
    CHECK(cmd(h, EFFECT_CMD_INIT, 0, NULL, &rs, &st) == 0 && st == 0, "init");
    /* exactly what the car's mediaserver sent (fxdebug.bin 2026-11-18 20:03): 44100 Hz, stereo 0x3, format 1,
     * input access 1 (READ), output access 2 (ACCUMULATE) */
    memset(&cfg, 0, sizeof(cfg));
    cfg.inputCfg.samplingRate = cfg.outputCfg.samplingRate = 44100;
    cfg.inputCfg.channels = cfg.outputCfg.channels = 0x3;
    cfg.inputCfg.format = cfg.outputCfg.format = 1;
    cfg.inputCfg.accessMode = 1;
    cfg.outputCfg.accessMode = 2;
    cfg.inputCfg.mask = cfg.outputCfg.mask = 0x3f;
    rs = 4;
    CHECK(cmd(h, EFFECT_CMD_SET_CONFIG, sizeof(cfg), &cfg, &rs, &st) == 0 && st == 0,
          "head unit SET_CONFIG (READ=1 in, ACCUMULATE=2 out) accepted");
    CHECK(EFFECT_BUFFER_ACCESS_WRITE == 0 && EFFECT_BUFFER_ACCESS_READ == 1 && EFFECT_BUFFER_ACCESS_ACCUMULATE == 2,
          "buffer access constants follow AOSP effect_buffer_access_e");
    make_cfg(&cfg, 44100, AUDIO_CHANNEL_OUT_STEREO, AUDIO_FORMAT_PCM_16_BIT, EFFECT_BUFFER_ACCESS_ACCUMULATE);
    rs = 4;
    CHECK(cmd(h, EFFECT_CMD_SET_CONFIG, sizeof(cfg), &cfg, &rs, &st) == 0 && st == 0, "set config 44.1k accumulate");
    rs = sizeof(got);
    CHECK(cmd(h, EFFECT_CMD_GET_CONFIG, 0, NULL, &rs, &got) == 0 && memcmp(&got, &cfg, sizeof(cfg)) == 0, "get config");
    make_cfg(&cfg, 44100, 0x1, AUDIO_FORMAT_PCM_16_BIT, EFFECT_BUFFER_ACCESS_WRITE);
    rs = 4;
    CHECK(cmd(h, EFFECT_CMD_SET_CONFIG, sizeof(cfg), &cfg, &rs, &st) == 0 && st != 0, "mono refused");
    make_cfg(&cfg, 44100, AUDIO_CHANNEL_OUT_STEREO, 3, EFFECT_BUFFER_ACCESS_WRITE);
    rs = 4;
    CHECK(cmd(h, EFFECT_CMD_SET_CONFIG, sizeof(cfg), &cfg, &rs, &st) == 0 && st != 0, "non-16-bit refused");
    make_cfg(&cfg, 8000, AUDIO_CHANNEL_OUT_STEREO, AUDIO_FORMAT_PCM_16_BIT, EFFECT_BUFFER_ACCESS_WRITE);
    rs = 4;
    CHECK(cmd(h, EFFECT_CMD_SET_CONFIG, sizeof(cfg), &cfg, &rs, &st) == 0 && st != 0, "8 kHz refused");

    CHECK(get_param(h, EQ20_PARAM_NUM_BANDS, &v32, 4) == 4 && v32 == 20, "num bands");
    CHECK(get_param(h, EQ20_PARAM_CENTER_FREQS, freqs, sizeof(freqs)) == sizeof(freqs) && freqs[0] == 22 &&
              freqs[19] == 16000,
          "center freqs");
    CHECK(get_param(h, EQ20_PARAM_LEVEL_LIMITS, lim, sizeof(lim)) == sizeof(lim) && lim[0] == -1200 &&
              lim[1] == 600 && lim[2] == 300 && lim[3] == 63,
          "limits");
    CHECK(get_param(h, 77, &v32, 4) < 0, "unknown param refused");
    {
        uint32_t dbg[EQ20_DEBUG_WORDS];
        uint32_t ds = sizeof(dbg);
        CHECK(get_param(h, EQ20_PARAM_NUM_BANDS, &v32, 4) == 4, "num bands before debug read");
        CHECK(cmd(h, EQ20_CMD_DEBUG, 0, NULL, &ds, dbg) == 0 && ds == sizeof(dbg) && dbg[0] == EQ20_DEBUG_MAGIC &&
                  dbg[2 + EFFECT_CMD_GET_PARAM] >= 2 && dbg[19] == sizeof(effect_param_t) + 4 && dbg[20] == 4 &&
                  dbg[22] == sizeof(effect_param_t) + 8 && dbg[23] == 0 && dbg[24] == sizeof(effect_config_t) &&
                  dbg[25] == 8000 && dbg[26] == AUDIO_CHANNEL_OUT_STEREO && dbg[29] == 22,
              "debug command reports the last GET_PARAM and the last (refused 8 kHz) SET_CONFIG");
        get_param(h, 77, &v32, 4);
        ds = sizeof(dbg);
        CHECK(cmd(h, EQ20_CMD_DEBUG, 0, NULL, &ds, dbg) == 0 && dbg[23] == 3, "debug result 3 for unknown parameter");
        get_param(h, EQ20_PARAM_CENTER_FREQS, freqs, 4);
        ds = sizeof(dbg);
        CHECK(cmd(h, EQ20_CMD_DEBUG, 0, NULL, &ds, dbg) == 0 && dbg[23] == 2, "debug result 2 for a short value buffer");
    }

    for (i = 0; i < EQ20_BANDS; i++) lv[i] = 1200;
    lv[10] = -3000;
    lv[11] = 123;
    CHECK(set_levels(h, lv) == 0, "set levels");
    CHECK(get_param(h, EQ20_PARAM_BAND_LEVELS, back, sizeof(back)) == sizeof(back), "get levels");
    CHECK(back[0] == 300 && back[3] == 300 && back[4] == 600 && back[10] == -1200 && back[11] == 100, "levels clamped");
    CHECK(get_param(h, EQ20_PARAM_PREAMP, &pre, 2) == 2 && pre == -600, "preamp follows highest boost");
    {
        struct {
            effect_param_t p;
            int32_t id;
            int16_t v[2];
        } m = {{0, 4, 4}, EQ20_PARAM_BAND_LEVEL, {5, -450}};
        rs = 4;
        CHECK(cmd(h, EFFECT_CMD_SET_PARAM, sizeof(m), &m, &rs, &st) == 0 && st == 0, "single band set");
        CHECK(get_param(h, EQ20_PARAM_BAND_LEVELS, back, sizeof(back)) > 0 && back[5] == -450, "single band value");
        m.v[0] = 20;
        rs = 4;
        CHECK(cmd(h, EFFECT_CMD_SET_PARAM, sizeof(m), &m, &rs, &st) == 0 && st != 0, "band index range");
    }

    bi.frameCount = bo.frameCount = 64;
    bi.s16 = in;
    bo.s16 = out;
    for (i = 0; i < 128; i++) in[i] = out[i] = 100;
    CHECK((*h)->process(h, &bi, &bo) == -EQ20_ENODATA, "disabled process returns -ENODATA");
    rs = 4;
    CHECK(cmd(h, EFFECT_CMD_ENABLE, 0, NULL, &rs, &st) == 0 && st == 0, "enable");
    for (i = 0; i < EQ20_BANDS; i++) lv[i] = 0;
    set_levels(h, lv);
    /* let the ramp to flat finish, then accumulate mode must add input to existing output */
    for (i = 0; i < 64; i++) (*h)->process(h, &bi, &bo);
    for (i = 0; i < 128; i++) out[i] = 100;
    CHECK((*h)->process(h, &bi, &bo) == 0, "enabled process");
    for (i = 0; i < 128; i++)
        if (out[i] != 200) break;
    CHECK(i == 128, "accumulate adds (sample %d = %d)", i, i < 128 ? out[i] : 0);
    rs = 4;
    CHECK(cmd(h, EFFECT_CMD_DISABLE, 0, NULL, &rs, &st) == 0 && st == 0, "disable");
    CHECK((*h)->process(h, &bi, &bo) == -EQ20_ENODATA, "process after disable");

    for (made = 0; made < 8; made++)
        if (AELI.create_effect(&impl_uuid, 0, 0, &extra[made]) != 0) break;
    CHECK(made == 7, "pool has 8 instances (7 extra created, got %d)", made);
    CHECK(AELI.release_effect(h) == 0 && AELI.release_effect(h) != 0, "release once");
    for (i = 0; i < made; i++) AELI.release_effect(extra[i]);
    printf("PASS effect interface: AELI, descriptor, INIT/SET_CONFIG/GET_CONFIG, params, ENABLE/DISABLE, accumulate, pool\n");
}

static void bench(void) {
    static eq20_dsp_t d;
    enum { N = 44100 };
    static int16_t in[2 * N], out[2 * N];
    int16_t lv[EQ20_BANDS];
    int i;
    clock_t t;
    eq20_dsp_init(&d, 44100);
    for (i = 0; i < EQ20_BANDS; i++) lv[i] = -300;
    eq20_dsp_set_levels(&d, lv, 1);
    for (i = 0; i < 2 * N; i++) in[i] = (int16_t)(i * 37);
    t = clock();
    for (i = 0; i < 10; i++) eq20_dsp_process(&d, in, out, N, 0);
    printf("INFO host speed: 10 s of 20-band stereo audio in %.0f ms\n", 1000.0 * (clock() - t) / CLOCKS_PER_SEC);
}

int main(void) {
    test_math();
    test_clamp();
    test_flat_bitexact();
    test_response(44100);
    test_response(48000);
    test_headroom();
    test_ramp();
    test_interface();
    bench();
    if (failures) {
        printf("FAILED %d\n", failures);
        return 1;
    }
    printf("eq20 host tests OK\n");
    return 0;
}
