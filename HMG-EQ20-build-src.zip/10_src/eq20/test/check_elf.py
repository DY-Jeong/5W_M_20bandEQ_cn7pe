"""Checks that libeq20.so can be loaded by the Android 4.4 (API 19) bionic linker as an effect library."""
import struct
import sys

from elftools.elf.dynamic import DynamicSection
from elftools.elf.elffile import ELFFile
from elftools.elf.sections import SymbolTableSection

failures = []


def check(cond, msg):
    print(("PASS " if cond else "FAIL ") + msg)
    if not cond:
        failures.append(msg)


with open(sys.argv[1], "rb") as f:
    elf = ELFFile(f)
    check(elf.elfclass == 32 and elf["e_machine"] == "EM_ARM" and elf["e_type"] == "ET_DYN", "32-bit ARM shared object")
    dyn = next(s for s in elf.iter_sections() if isinstance(s, DynamicSection))
    tags = [t.entry.d_tag for t in dyn.iter_tags()]
    needed = [t.needed for t in dyn.iter_tags() if t.entry.d_tag == "DT_NEEDED"]
    check(not needed, "no DT_NEEDED (no libc/libm/liblog dependency): %s" % needed)
    check("DT_HASH" in tags, "SysV DT_HASH present (API 19 linker has no GNU hash support)")
    check("DT_TEXTREL" not in tags, "no text relocations")
    flags = [t.entry.d_val for t in dyn.iter_tags() if t.entry.d_tag == "DT_FLAGS"]
    check(not flags or not (flags[0] & 0x4), "DT_FLAGS without TEXTREL")
    check(not any(t.startswith("DT_ANDROID") or t == "DT_RELR" for t in tags), "no packed relocations")
    dynsym = elf.get_section_by_name(".dynsym")
    assert isinstance(dynsym, SymbolTableSection)
    named = [s for s in dynsym.iter_symbols() if s.name]
    check(len(named) == 1, "dynamic symbol table holds only AELI (no bundled runtime): %d names" % len(named))
    check(elf.get_section_by_name(".rel.plt") is None, "no PLT relocations (every call is internal)")
    undefined = [s.name for s in dynsym.iter_symbols() if s.name and s["st_shndx"] == "SHN_UNDEF"]
    check(not undefined, "no undefined symbols: %s" % undefined)
    exported = sorted(s.name for s in dynsym.iter_symbols()
                      if s.name and s["st_shndx"] != "SHN_UNDEF" and s["st_info"]["bind"] == "STB_GLOBAL")
    check(exported == ["AELI"], "only AELI exported: %s" % exported)
    aeli = next(s for s in dynsym.iter_symbols() if s.name == "AELI")
    # the head unit's EffectsFactory takes the 3.0 layout: tag, version, name, implementor, create, release,
    # get_descriptor (every stock soundfx library is 28 bytes, version 0x00030000)
    check(aeli["st_info"]["type"] == "STT_OBJECT" and aeli["st_size"] == 28, "AELI is a 28-byte object (7 x 32-bit, API 3.0)")
    aeli_off = next(seg["p_offset"] + aeli["st_value"] - seg["p_vaddr"] for seg in elf.iter_segments()
                    if seg["p_type"] == "PT_LOAD" and seg["p_vaddr"] <= aeli["st_value"] < seg["p_vaddr"] + seg["p_filesz"])
    f.seek(aeli_off)
    tag, version = struct.unpack("<II", f.read(8))
    check(tag == 0x41454C54 and version == 0x00030000, "AELI tag 'AELT', library API version 3.0: %08x" % version)
    rels = [s for s in elf.iter_sections() if s["sh_type"] in ("SHT_REL", "SHT_RELA")]
    kinds = set()
    for s in rels:
        for r in s.iter_relocations():
            kinds.add(r["r_info_type"])
    # 23 R_ARM_RELATIVE, 2 R_ARM_ABS32, 21 R_ARM_GLOB_DAT, 22 R_ARM_JUMP_SLOT: all handled by the API 19 linker
    check(kinds <= {23, 2, 21, 22}, "relocation types supported by API 19: %s" % sorted(kinds))
    loads = [seg for seg in elf.iter_segments() if seg["p_type"] == "PT_LOAD"]
    check(all(seg["p_align"] <= 0x10000 for seg in loads), "PT_LOAD alignment <= 64 KiB")
    check(not any(seg["p_type"] == "PT_TLS" for seg in elf.iter_segments()), "no TLS")

if failures:
    sys.exit(1)
print("libeq20.so ELF checks OK")
