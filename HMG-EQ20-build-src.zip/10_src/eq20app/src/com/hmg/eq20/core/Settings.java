package com.hmg.eq20.core;

/**
 * EQ settings shared by the app (writer) and the root daemon (reader). Text format, one key per line:
 * version=1, enabled=0|1, bt=20 comma-separated millibels, aa=20 comma-separated millibels.
 */
public final class Settings {
    public static final String FILE_NAME = "eq20.conf";

    public final boolean enabled;
    public final short[] bt;
    public final short[] aa;

    public Settings(boolean enabled, short[] bt, short[] aa) {
        this.enabled = enabled;
        this.bt = Bands.clampAll(bt);
        this.aa = Bands.clampAll(aa);
    }

    public static Settings defaults() {
        return new Settings(true, new short[Bands.COUNT], new short[Bands.COUNT]);
    }

    public Settings withEnabled(boolean on) {
        return new Settings(on, bt, aa);
    }

    public Settings withLevels(Source source, short[] levels) {
        return source == Source.AA ? new Settings(enabled, bt, levels) : new Settings(enabled, levels, aa);
    }

    public short[] levels(Source source) {
        return source == Source.AA ? aa.clone() : bt.clone();
    }

    public String serialize() {
        return "version=1\nenabled=" + (enabled ? 1 : 0) + "\nbt=" + join(bt) + "\naa=" + join(aa) + "\n";
    }

    /** Strict parser: returns null for anything malformed, so the daemon keeps its previous settings. */
    public static Settings parse(String text) {
        if (text == null || text.length() > 4096) {
            return null;
        }
        String version = null, enabled = null, bt = null, aa = null;
        for (String raw : text.split("\n")) {
            String line = raw.trim();
            if (line.length() == 0) {
                continue;
            }
            int eq = line.indexOf('=');
            if (eq <= 0) {
                return null;
            }
            String key = line.substring(0, eq), value = line.substring(eq + 1);
            if ("version".equals(key) && version == null) {
                version = value;
            } else if ("enabled".equals(key) && enabled == null) {
                enabled = value;
            } else if ("bt".equals(key) && bt == null) {
                bt = value;
            } else if ("aa".equals(key) && aa == null) {
                aa = value;
            } else {
                return null;
            }
        }
        if (!"1".equals(version) || !("0".equals(enabled) || "1".equals(enabled))) {
            return null;
        }
        short[] b = levels(bt), a = levels(aa);
        if (b == null || a == null) {
            return null;
        }
        return new Settings("1".equals(enabled), b, a);
    }

    private static short[] levels(String csv) {
        if (csv == null) {
            return null;
        }
        String[] parts = csv.split(",", -1);
        if (parts.length != Bands.COUNT) {
            return null;
        }
        short[] out = new short[Bands.COUNT];
        for (int i = 0; i < Bands.COUNT; i++) {
            if (!parts[i].matches("-?\\d{1,5}")) {
                return null;
            }
            int v = Integer.parseInt(parts[i]);
            if (v < Bands.MIN_MB || v > Bands.maxMb(i)) {
                return null;
            }
            out[i] = (short) v;
        }
        return out;
    }

    private static String join(short[] v) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < v.length; i++) {
            sb.append(i == 0 ? "" : ",").append(v[i]);
        }
        return sb.toString();
    }
}
