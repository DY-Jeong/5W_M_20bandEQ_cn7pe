package com.hmg.eq20.core;

import java.util.Random;

/**
 * Room-correction result code and the head-unit test signal. Must match roomcorr-core.js:
 * 25 Crockford base32 characters = version 4 bits, target 3, phone profile 6, 20 x 5 bits (dB + 12), CRC-8
 * (poly 0x07) over the first 113 bits, 4 zero padding bits.
 */
public final class RoomCode {
    public static final int VERSION = 1;
    public static final int CUSTOM_PROFILE = 63;
    private static final String ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
    public static final String[] TARGET_NAMES = {"플랫", "차량 기본(하우스 커브)", "저음 강조"};
    /** Phone profile names by id (roomcorr-mics.js); 63 = user-measured profile. */
    public static final String[] PROFILE_NAMES = {
        "마이크 보정 없음", "Galaxy Z Flip5", "Galaxy Z Flip6", "Galaxy Z Fold5", "Galaxy Z Fold6", "Galaxy S23",
        "Galaxy S23 Ultra", "Galaxy S24", "Galaxy S24 Ultra", "Galaxy S25", "Galaxy S25 Ultra", "Galaxy A54",
        "Galaxy A55", "iPhone 13/14", "iPhone 15/16", "Pixel 7/8", "Pixel 9"};

    public final int target;
    public final int profile;
    /** Correction in dB per band, within the AMP limits. */
    public final int[] correctionDb;

    private RoomCode(int target, int profile, int[] correctionDb) {
        this.target = target;
        this.profile = profile;
        this.correctionDb = correctionDb;
    }

    public static boolean isCodeChar(char c) {
        return ALPHABET.indexOf(Character.toUpperCase(c)) >= 0;
    }

    /** Keypad characters (the code alphabet). */
    public static final String KEYS = ALPHABET;

    /** Typed characters shown in the 5-5-5-5-5 layout with '_' for the missing ones. */
    public static String display(String typed) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 25; i++) {
            if (i > 0 && i % 5 == 0) {
                sb.append('-');
            }
            sb.append(i < typed.length() ? typed.charAt(i) : '_');
        }
        return sb.toString();
    }

    /** Short description of the correction, e.g. "최대 -6 dB(125Hz) / +3 dB(4k)". */
    public static String summary(int[] db) {
        int lo = 0, hi = 0;
        for (int i = 1; i < db.length; i++) {
            lo = db[i] < db[lo] ? i : lo;
            hi = db[i] > db[hi] ? i : hi;
        }
        StringBuilder sb = new StringBuilder("보정 ");
        sb.append(db[lo] < 0 ? db[lo] + " dB(" + Bands.label(lo) + ")" : "감쇠 없음");
        sb.append(" / ");
        sb.append(db[hi] > 0 ? "+" + db[hi] + " dB(" + Bands.label(hi) + ")" : "증폭 없음");
        return sb.toString();
    }

    public static String normalize(String code) {
        StringBuilder sb = new StringBuilder();
        for (char c : code.toUpperCase(java.util.Locale.US).toCharArray()) {
            if (c == '-' || Character.isWhitespace(c)) {
                continue;
            }
            sb.append(c == 'O' ? '0' : c == 'I' || c == 'L' ? '1' : c);
        }
        return sb.toString();
    }

    /** Throws IllegalArgumentException with a user-facing Korean message on any error. */
    public static RoomCode decode(String code) {
        String s = normalize(code);
        if (s.length() != 25) {
            throw new IllegalArgumentException("코드는 25자입니다 (지금 " + s.length() + "자)");
        }
        int[] bits = new int[125];
        for (int i = 0; i < 25; i++) {
            int v = ALPHABET.indexOf(s.charAt(i));
            if (v < 0) {
                throw new IllegalArgumentException("잘못된 문자: " + s.charAt(i));
            }
            for (int k = 0; k < 5; k++) {
                bits[i * 5 + k] = (v >> (4 - k)) & 1;
            }
        }
        int[] pos = {0};
        int version = get(bits, pos, 4), target = get(bits, pos, 3), profile = get(bits, pos, 6);
        int[] corr = new int[Bands.COUNT];
        for (int i = 0; i < Bands.COUNT; i++) {
            corr[i] = get(bits, pos, 5) - 12;
        }
        int crc = get(bits, pos, 8);
        if (get(bits, pos, 4) != 0 || crc != crc8(bits, 113)) {
            throw new IllegalArgumentException("코드가 맞지 않습니다. 오타를 확인하세요");
        }
        if (version != VERSION) {
            throw new IllegalArgumentException("지원하지 않는 코드 버전 " + version);
        }
        for (int i = 0; i < Bands.COUNT; i++) {
            if (corr[i] * 100 > Bands.maxMb(i)) {
                throw new IllegalArgumentException("한도를 넘는 보정값");
            }
        }
        return new RoomCode(target, profile, corr);
    }

    public static String encode(int[] correctionDb, int target, int profile) {
        int[] bits = new int[125];
        int[] pos = {0};
        put(bits, pos, VERSION, 4);
        put(bits, pos, target, 3);
        put(bits, pos, profile, 6);
        for (int i = 0; i < Bands.COUNT; i++) {
            if (correctionDb[i] < -12 || correctionDb[i] * 100 > Bands.maxMb(i)) {
                throw new IllegalArgumentException("band " + i);
            }
            put(bits, pos, correctionDb[i] + 12, 5);
        }
        put(bits, pos, crc8(bits, 113), 8);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 25; i++) {
            int v = 0;
            for (int k = 0; k < 5; k++) {
                v = (v << 1) | bits[i * 5 + k];
            }
            if (i > 0 && i % 5 == 0) {
                sb.append('-');
            }
            sb.append(ALPHABET.charAt(v));
        }
        return sb.toString();
    }

    public short[] levelsMb() {
        short[] mb = new short[Bands.COUNT];
        for (int i = 0; i < Bands.COUNT; i++) {
            mb[i] = (short) (correctionDb[i] * 100);
        }
        return mb;
    }

    public String targetName() {
        return target < TARGET_NAMES.length ? TARGET_NAMES[target] : "목표 " + target;
    }

    public String profileName() {
        if (profile == CUSTOM_PROFILE) {
            return "사용자 정의 프로필";
        }
        return profile < PROFILE_NAMES.length ? PROFILE_NAMES[profile] : "프로필 " + profile;
    }

    private static int get(int[] bits, int[] pos, int width) {
        int v = 0;
        for (int i = 0; i < width; i++) {
            v = (v << 1) | bits[pos[0]++];
        }
        return v;
    }

    private static void put(int[] bits, int[] pos, int v, int width) {
        for (int i = width - 1; i >= 0; i--) {
            bits[pos[0]++] = (v >> i) & 1;
        }
    }

    /** CRC-8 (poly 0x07, init 0) over the first n bits packed MSB-first into bytes (zero-padded). */
    static int crc8(int[] bits, int n) {
        int c = 0;
        for (int i = 0; i < n; i += 8) {
            int b = 0;
            for (int k = 0; k < 8; k++) {
                b = (b << 1) | (i + k < n ? bits[i + k] : 0);
            }
            c ^= b;
            for (int k = 0; k < 8; k++) {
                c = (c & 0x80) != 0 ? ((c << 1) ^ 0x07) & 0xff : (c << 1) & 0xff;
            }
        }
        return c;
    }

    /**
     * Periodic pink noise (16-bit stereo-interleaved, identical channels) for the measurement: random-phase
     * spectrum shaped 1/sqrt(f) between 18 Hz and 20 kHz, so every proportional band has equal power;
     * RMS at rmsDb dBFS. frames must be a power of two; it loops seamlessly.
     */
    public static short[] pinkNoise(int frames, int rate, long seed, double rmsDb) {
        double[] re = new double[frames], im = new double[frames];
        Random r = new Random(seed);
        for (int i = 1; i < frames / 2; i++) {
            double f = (double) i * rate / frames;
            if (f < 18 || f > 20000) {
                continue;
            }
            double mag = 1 / Math.sqrt(f), ph = 2 * Math.PI * r.nextDouble();
            re[i] = mag * Math.cos(ph);
            im[i] = mag * Math.sin(ph);
            re[frames - i] = re[i];
            im[frames - i] = -im[i];
        }
        fft(re, im, true);
        double sum = 0;
        for (double v : re) {
            sum += v * v;
        }
        double gain = Math.pow(10, rmsDb / 20) / Math.sqrt(sum / frames) * 32767;
        short[] out = new short[frames * 2];
        for (int i = 0; i < frames; i++) {
            long v = Math.round(re[i] * gain);
            short s = (short) Math.max(-32768, Math.min(32767, v));
            out[2 * i] = s;
            out[2 * i + 1] = s;
        }
        return out;
    }

    public static void fft(double[] re, double[] im, boolean inverse) {
        int n = re.length;
        for (int i = 1, j = 0; i < n; i++) {
            int bit = n >> 1;
            for (; (j & bit) != 0; bit >>= 1) {
                j ^= bit;
            }
            j ^= bit;
            if (i < j) {
                double t = re[i];
                re[i] = re[j];
                re[j] = t;
                t = im[i];
                im[i] = im[j];
                im[j] = t;
            }
        }
        for (int len = 2; len <= n; len <<= 1) {
            double ang = (inverse ? 2 : -2) * Math.PI / len, wr = Math.cos(ang), wi = Math.sin(ang);
            for (int i = 0; i < n; i += len) {
                double cr = 1, ci = 0;
                for (int k = 0; k < len / 2; k++) {
                    int a = i + k, b = a + len / 2;
                    double tr = re[b] * cr - im[b] * ci, ti = re[b] * ci + im[b] * cr;
                    re[b] = re[a] - tr;
                    im[b] = im[a] - ti;
                    re[a] += tr;
                    im[a] += ti;
                    double nr = cr * wr - ci * wi;
                    ci = cr * wi + ci * wr;
                    cr = nr;
                }
            }
        }
        if (inverse) {
            for (int i = 0; i < n; i++) {
                re[i] /= n;
                im[i] /= n;
            }
        }
    }
}
