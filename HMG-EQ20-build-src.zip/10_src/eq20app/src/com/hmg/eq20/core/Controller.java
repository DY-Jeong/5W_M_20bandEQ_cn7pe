package com.hmg.eq20.core;

import java.util.EnumMap;
import java.util.Map;
import java.util.Set;

/**
 * Daemon logic, free of Android classes so it can be host tested. Each tick: reload settings if they
 * changed, find the BT and AA music sessions, keep exactly one eq20 effect per live session with the
 * source's curve, and drop effects that died (mediaserver restart) or are no longer wanted.
 * An effect stays attached while its session exists even if playback pauses, so resume has no gap.
 */
public final class Controller {
    public interface Effect {
        /** Returns false if the effect is dead (e.g. mediaserver restarted). */
        boolean setLevels(short[] mb);

        boolean alive();

        int limiterHits();

        void release();
    }

    public interface Platform {
        String dumpFlinger();

        Set<Integer> pidsOf(String cmdline);

        /** Creates and enables an eq20 effect on the session; throws if that is not possible. */
        Effect attach(int session) throws Exception;

        /** Current settings text, or null if there is no settings file yet. */
        String readSettings();

        void log(String msg);
    }

    private static final class Attached {
        final int session;
        final Effect effect;
        short[] applied;

        Attached(int session, Effect effect) {
            this.session = session;
            this.effect = effect;
        }
    }

    private final Platform platform;
    private final Map<Source, Attached> attached = new EnumMap<Source, Attached>(Source.class);
    private final Map<Source, String> lastError = new EnumMap<Source, String>(Source.class);
    private Settings settings = Settings.defaults();
    private String settingsText;
    private boolean settingsValid = true;

    public Controller(Platform platform) {
        this.platform = platform;
    }

    public void tick() {
        reloadSettings();
        java.util.List<FlingerTracks.Track> tracks = FlingerTracks.active(platform.dumpFlinger());
        for (Source s : Source.values()) {
            int session = settings.enabled ? FlingerTracks.sessionFor(tracks, platform.pidsOf(s.cmdline), s) : -1;
            Attached cur = attached.get(s);
            if (cur != null) {
                boolean dead = !cur.effect.alive();
                boolean replaced = session >= 0 && session != cur.session;
                if (!settings.enabled || dead || replaced) {
                    cur.effect.release();
                    attached.remove(s);
                    platform.log(s + " released session=" + cur.session
                            + (dead ? " (effect died)" : replaced ? " (new session " + session + ")" : " (disabled)"));
                    cur = null;
                }
            }
            if (cur == null && session >= 0) {
                try {
                    cur = new Attached(session, platform.attach(session));
                    attached.put(s, cur);
                    lastError.remove(s);
                    platform.log(s + " attached session=" + session);
                } catch (Exception e) {
                    String msg = String.valueOf(e);
                    if (!msg.equals(lastError.get(s))) {
                        platform.log(s + " attach session=" + session + " failed: " + msg);
                    }
                    lastError.put(s, msg);
                    continue;
                }
            }
            if (cur != null) {
                short[] want = settings.levels(s);
                if (cur.applied == null || !java.util.Arrays.equals(cur.applied, want)) {
                    if (cur.effect.setLevels(want)) {
                        cur.applied = want;
                    } else {
                        cur.effect.release();
                        attached.remove(s);
                        platform.log(s + " setLevels failed, will re-attach");
                    }
                }
            }
        }
    }

    private void reloadSettings() {
        String text = platform.readSettings();
        if (text == null || text.equals(settingsText)) {
            return;
        }
        settingsText = text;
        Settings parsed = Settings.parse(text);
        settingsValid = parsed != null;
        if (parsed != null) {
            settings = parsed;
        } else {
            platform.log("settings rejected, keeping previous");
        }
    }

    public void releaseAll() {
        for (Attached a : attached.values()) {
            a.effect.release();
        }
        attached.clear();
    }

    /** Status file text read by the app. */
    public String status() {
        StringBuilder sb = new StringBuilder();
        sb.append("enabled=").append(settings.enabled ? 1 : 0).append('\n');
        sb.append("settings_valid=").append(settingsValid ? 1 : 0).append('\n');
        for (Source s : Source.values()) {
            String key = s.name().toLowerCase(java.util.Locale.US);
            Attached a = attached.get(s);
            sb.append(key).append(".session=").append(a == null ? -1 : a.session).append('\n');
            sb.append(key).append(".limiter_hits=").append(a == null ? 0 : a.effect.limiterHits()).append('\n');
            if (lastError.containsKey(s)) {
                sb.append(key).append(".error=").append(lastError.get(s).replace('\n', ' ')).append('\n');
            }
        }
        return sb.toString();
    }

    public int attachedSession(Source s) {
        Attached a = attached.get(s);
        return a == null ? -1 : a.session;
    }
}
