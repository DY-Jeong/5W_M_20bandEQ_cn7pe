package com.hmg.eq20.core;

/** Band layout, AMP limits and built-in presets. Must match libeq20 (eq20.h / eq20_dsp.h). */
public final class Bands {
    public static final int COUNT = 20;
    public static final int[] CENTER_HZ = {
        22, 31, 44, 63, 88, 125, 177, 250, 355, 500, 710, 1000, 1400, 2000, 2800, 4000, 5600, 8000, 11000, 16000};
    public static final int MIN_MB = -1200;
    public static final int MAX_MB = 600;
    public static final int LOW_MAX_MB = 300;
    public static final int LOW_EDGE_HZ = 63;
    public static final int STEP_MB = 50;

    /** Preset names (Korean UI labels) and levels in millibels. */
    public static final String[] PRESET_NAMES = {"플랫", "저음 강조", "보컬", "라우드니스", "고음 강조", "부드럽게"};
    private static final int[][] PRESETS = {
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {300, 300, 300, 300, 400, 300, 200, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, -100, -100, -150, -200, -150, -100, 0, 100, 200, 300, 300, 250, 200, 100, 0, 0, 0},
        {300, 300, 300, 300, 400, 300, 150, 0, -100, -200, -200, -200, -150, -100, 0, 150, 250, 300, 300, 300},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 150, 250, 300, 400, 400, 400},
        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -100, -200, -300, -400, -500, -600},
    };

    private Bands() {
    }

    public static int maxMb(int band) {
        return CENTER_HZ[band] <= LOW_EDGE_HZ ? LOW_MAX_MB : MAX_MB;
    }

    /** Same rule as eq20_clamp_level: clamp to the band limits, round half away from zero to 0.5 dB. */
    public static short clamp(int band, int mb) {
        int v = Math.max(MIN_MB, Math.min(maxMb(band), mb));
        int q = v >= 0 ? (v + STEP_MB / 2) / STEP_MB : -((-v + STEP_MB / 2) / STEP_MB);
        return (short) (q * STEP_MB);
    }

    public static short[] clampAll(short[] mb) {
        short[] out = new short[COUNT];
        for (int i = 0; i < COUNT; i++) {
            out[i] = clamp(i, mb[i]);
        }
        return out;
    }

    public static short[] preset(int index) {
        short[] out = new short[COUNT];
        for (int i = 0; i < COUNT; i++) {
            out[i] = (short) PRESETS[index][i];
        }
        return out;
    }

    public static String label(int band) {
        int hz = CENTER_HZ[band];
        if (hz < 1000) {
            return String.valueOf(hz);
        }
        if (hz % 1000 == 0) {
            return (hz / 1000) + "k";
        }
        return (hz / 1000) + "." + (hz % 1000) / 100 + "k";
    }
}
