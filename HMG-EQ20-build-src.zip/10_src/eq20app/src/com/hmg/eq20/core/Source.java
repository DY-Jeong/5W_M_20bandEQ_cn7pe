package com.hmg.eq20.core;

/** Audio sources that get their own EQ curve, and how the daemon recognizes their playback track. */
public enum Source {
    /** BT A2DP music: mediaserver's RoutingThread track, stream MUSIC (car-verified 2026-11-18). */
    BT("BT 음악", "/system/bin/mediaserver", false),
    /** Android Auto media: projection sink stereo MUSIC track (not yet verified on the car). */
    AA("Android Auto", "com.google.android.projection.sink", true);

    public static final int STREAM_MUSIC = 3;

    public final String label;
    public final String cmdline;
    public final boolean stereoOnly;

    Source(String label, String cmdline, boolean stereoOnly) {
        this.label = label;
        this.cmdline = cmdline;
        this.stereoOnly = stereoOnly;
    }
}
