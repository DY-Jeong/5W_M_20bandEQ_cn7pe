package com.hmg.eq20.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Active playback tracks from `dumpsys media.audio_flinger` (Android 4.4 layout). */
public final class FlingerTracks {
    private static final Pattern IO = Pattern.compile("^io handle: (\\d+)");
    private static final Pattern ACTIVE = Pattern.compile("^Output thread 0x[0-9a-fA-F]+ active tracks");
    // Name Client Type Fmt ChnMask Session fCount S F SRate ...
    private static final Pattern ROW = Pattern.compile(
            "^\\s+\\d+\\s+(\\d+)\\s+(\\d+)\\s+[0-9a-fA-F]{8}\\s+([0-9a-fA-F]{8})\\s+(\\d+)\\s+\\d+\\s+\\S+\\s+\\d+\\s+(\\d+)\\s");

    public static final class Track {
        public final int io, client, stream, channelMask, session, rate;

        Track(int io, int client, int stream, int channelMask, int session, int rate) {
            this.io = io;
            this.client = client;
            this.stream = stream;
            this.channelMask = channelMask;
            this.session = session;
            this.rate = rate;
        }

        /** Two-channel mask in either the output (0x3) or the input (0xC, used by the BT route) encoding. */
        public boolean stereo() {
            return channelMask == 0x3 || channelMask == 0xC;
        }
    }

    private FlingerTracks() {
    }

    public static List<Track> active(String dump) {
        List<Track> out = new ArrayList<Track>();
        int io = -1;
        boolean active = false;
        for (String line : dump.split("\r?\n")) {
            if (ACTIVE.matcher(line).find()) {
                active = true;
                continue;
            }
            if (active) {
                if (line.trim().startsWith("Name ")) {
                    continue;
                }
                Matcher m = ROW.matcher(line);
                if (m.find()) {
                    out.add(new Track(io, Integer.parseInt(m.group(1)), Integer.parseInt(m.group(2)),
                            (int) Long.parseLong(m.group(3), 16), Integer.parseInt(m.group(4)),
                            Integer.parseInt(m.group(5))));
                    continue;
                }
                active = false;
            }
            Matcher m = IO.matcher(line);
            if (m.find()) {
                io = Integer.parseInt(m.group(1));
            }
        }
        return out;
    }

    /** Session of the first active MUSIC track of the source's processes, or -1. */
    public static int sessionFor(List<Track> tracks, Set<Integer> pids, Source source) {
        for (Track t : tracks) {
            if (t.stream == Source.STREAM_MUSIC && pids.contains(t.client) && (!source.stereoOnly || t.stereo())) {
                return t.session;
            }
        }
        return -1;
    }

    private static final Pattern THREAD_LIST = Pattern.compile("^Output thread (0x[0-9a-fA-F]+) (active )?tracks");
    // Name Client Type Fmt ChnMask Session fCount S F SRate L-dB R-dB ...
    private static final Pattern ROW_FULL = Pattern.compile(
            "^\\s+\\d+\\s+\\d+\\s+(\\d+)\\s+[0-9a-fA-F]{8}\\s+[0-9a-fA-F]{8}\\s+(\\d+)\\s+\\d+\\s+(\\S+)\\s+\\d+\\s+\\d+\\s+(\\S+)\\s+(\\S+)\\s");

    /**
     * One-line description of a session's track for diagnostics, e.g. "active thread=0xb5af5008 stream=3 state=A
     * vol=0/0dB", or null if AudioFlinger has no track with that session.
     */
    public static String describe(String dump, int session) {
        String thread = null, found = null;
        boolean activeList = false, active = false;
        for (String line : dump.split("\r?\n")) {
            Matcher t = THREAD_LIST.matcher(line);
            if (t.find()) {
                thread = t.group(1);
                activeList = t.group(2) != null;
                continue;
            }
            Matcher m = ROW_FULL.matcher(line);
            if (thread != null && m.find() && Integer.parseInt(m.group(2)) == session) {
                if (activeList) {
                    active = true;
                } else if (found == null) {
                    found = "thread=" + thread + " stream=" + m.group(1) + " state=" + m.group(3) + " vol=" + m.group(4)
                            + "/" + m.group(5) + "dB";
                }
            }
        }
        return found == null ? null : (active ? "active " : "inactive ") + found;
    }
}
