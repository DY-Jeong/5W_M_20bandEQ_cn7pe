package com.hmg.eq20.core;

/**
 * Band slider layout in px, shared by the app's EqBandsView and the host preview renderer so both
 * draw the same geometry. Values are dp-based and scaled by the display density.
 */
public final class BandsGeometry {
    public static final int TOP_DB = 6, BOTTOM_DB = -12;
    public static final int FILL_ON = 0xFF0070F3, FILL_OFF = 0xFF3A3A3A, TRACK = 0xFF2A2A2A;
    public static final int KNOB_ON = 0xFFF5F5F5, KNOB_OFF = 0xFF6A6A6A, ZERO = 0xFF5A5A5A, GRID = 0xFF343434;
    public static final int TEXT = 0xFFF5F5F5, MUTED = 0xFF9A9A9A;
    /** Applied to every text size in the app and the preview renderer. */
    public static final float TEXT_SCALE = 0.9f;

    public final float density, width, height, axis, column, top, bottom, half, knob, valueBaseline, labelBaseline;

    public BandsGeometry(float density, float width, float height) {
        this.density = density;
        this.width = width;
        this.height = height;
        axis = 56 * density;
        column = (width - axis) / Bands.COUNT;
        top = 60 * density;
        bottom = height - 56 * density;
        half = 7 * density;
        knob = 15 * density;
        valueBaseline = 30 * density;
        labelBaseline = height - 14 * density;
    }

    public float centerX(int band) {
        return axis + column * band + column / 2;
    }

    public float yFor(float db) {
        return top + (TOP_DB - db) / (float) (TOP_DB - BOTTOM_DB) * (bottom - top);
    }

    public float pxPerDb() {
        return (bottom - top) / (TOP_DB - BOTTOM_DB);
    }

    public int bandAt(float x) {
        return Math.max(0, Math.min(Bands.COUNT - 1, (int) ((x - axis) / column)));
    }

    /** Level after dragging dy px from a start level: 0.5 dB steps, clamped to the band limits. */
    public short dragLevel(int band, short startMb, float dy) {
        return Bands.clamp(band, startMb + Math.round(-dy / pxPerDb() * 2f) * 50);
    }

    public static String format(short mb) {
        if (mb == 0) {
            return "0";
        }
        String s = (mb > 0 ? "+" : "-") + Math.abs(mb) / 100;
        return Math.abs(mb) % 100 == 0 ? s : s + ".5";
    }
}
