package com.hmg.eq20.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

import com.hmg.eq20.core.Bands;
import com.hmg.eq20.core.BandsGeometry;

/**
 * 20 vertical band sliders. Dragging a column moves its level relative to where the finger started
 * (0.5 dB steps), so a stray touch never jumps a band; a double tap resets the band to 0 dB.
 * Low bands draw their track only up to their +3 dB limit. Layout: {@link BandsGeometry}.
 */
public final class EqBandsView extends View {
    public interface Listener {
        /** Called while dragging (done=false) and once when the finger lifts (done=true). */
        void onLevelsChanged(short[] levels, boolean done);
    }

    private static final long DOUBLE_TAP_MS = 300;

    private final float density;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint value = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint label = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint axisText = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private short[] levels = new short[Bands.COUNT];
    private Listener listener;
    private boolean enabledLook = true;
    private int dragBand = -1;
    private float startY;
    private short startMb;
    private boolean moved;
    private int lastTapBand = -1;
    private long lastTapTime;

    public EqBandsView(Context context) {
        super(context);
        density = context.getResources().getDisplayMetrics().density;
        float sp = context.getResources().getDisplayMetrics().scaledDensity * BandsGeometry.TEXT_SCALE;
        value.setTextAlign(Paint.Align.CENTER);
        value.setTextSize(17 * sp);
        value.setTypeface(Typeface.MONOSPACE);
        label.setColor(BandsGeometry.MUTED);
        label.setTextAlign(Paint.Align.CENTER);
        label.setTextSize(17 * sp);
        label.setTypeface(Typeface.SANS_SERIF);
        axisText.setColor(BandsGeometry.MUTED);
        axisText.setTextAlign(Paint.Align.RIGHT);
        axisText.setTextSize(15 * sp);
        axisText.setTypeface(Typeface.MONOSPACE);
    }

    public void setListener(Listener l) {
        listener = l;
    }

    public void setLevels(short[] mb) {
        levels = Bands.clampAll(mb);
        invalidate();
    }

    public short[] getLevels() {
        return levels.clone();
    }

    public void setEnabledLook(boolean on) {
        enabledLook = on;
        invalidate();
    }

    private BandsGeometry geometry() {
        return new BandsGeometry(density, getWidth(), getHeight());
    }

    @Override
    protected void onDraw(Canvas c) {
        BandsGeometry g = geometry();
        paint.setStrokeWidth(density);
        for (int db = BandsGeometry.TOP_DB; db >= BandsGeometry.BOTTOM_DB; db -= 6) {
            float y = g.yFor(db);
            paint.setColor(db == 0 ? BandsGeometry.ZERO : BandsGeometry.GRID);
            c.drawLine(g.axis, y, g.width, y, paint);
            c.drawText(BandsGeometry.format((short) (db * 100)), g.axis - 10 * density, y + 5 * density, axisText);
        }
        float zeroY = g.yFor(0);
        value.setColor(enabledLook ? BandsGeometry.TEXT : BandsGeometry.MUTED);
        for (int i = 0; i < Bands.COUNT; i++) {
            float cx = g.centerX(i);
            float trackTop = g.yFor(Bands.maxMb(i) / 100f);
            paint.setColor(BandsGeometry.TRACK);
            rect.set(cx - g.half, trackTop - g.half, cx + g.half, g.bottom + g.half);
            c.drawRoundRect(rect, g.half, g.half, paint);
            float y = g.yFor(levels[i] / 100f);
            paint.setColor(enabledLook ? BandsGeometry.FILL_ON : BandsGeometry.FILL_OFF);
            rect.set(cx - g.half, Math.min(y, zeroY), cx + g.half, Math.max(y, zeroY));
            c.drawRect(rect, paint);
            paint.setColor(enabledLook ? BandsGeometry.KNOB_ON : BandsGeometry.KNOB_OFF);
            c.drawCircle(cx, y, g.knob, paint);
            c.drawText(BandsGeometry.format(levels[i]), cx, g.valueBaseline, value);
            c.drawText(Bands.label(i), cx, g.labelBaseline, label);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        BandsGeometry g = geometry();
        switch (e.getActionMasked()) {
        case MotionEvent.ACTION_DOWN:
            getParent().requestDisallowInterceptTouchEvent(true);
            dragBand = g.bandAt(e.getX());
            startY = e.getY();
            startMb = levels[dragBand];
            moved = false;
            return true;
        case MotionEvent.ACTION_MOVE:
            if (dragBand >= 0) {
                float dy = e.getY() - startY;
                if (!moved && Math.abs(dy) < 8 * density) {
                    return true;
                }
                moved = true;
                short mb = g.dragLevel(dragBand, startMb, dy);
                if (mb != levels[dragBand]) {
                    levels[dragBand] = mb;
                    invalidate();
                    notifyListener(false);
                }
            }
            return true;
        case MotionEvent.ACTION_UP:
            if (dragBand >= 0) {
                if (moved) {
                    notifyListener(true);
                    lastTapBand = -1;
                } else if (dragBand == lastTapBand && e.getEventTime() - lastTapTime < DOUBLE_TAP_MS) {
                    lastTapBand = -1;
                    if (levels[dragBand] != 0) {
                        levels[dragBand] = 0;
                        invalidate();
                        notifyListener(true);
                    }
                } else {
                    lastTapBand = dragBand;
                    lastTapTime = e.getEventTime();
                }
                dragBand = -1;
            }
            return true;
        case MotionEvent.ACTION_CANCEL:
            if (dragBand >= 0 && moved) {
                notifyListener(true);
            }
            dragBand = -1;
            return true;
        default:
            return true;
        }
    }

    private void notifyListener(boolean done) {
        if (listener != null) {
            listener.onLevelsChanged(levels.clone(), done);
        }
    }
}
