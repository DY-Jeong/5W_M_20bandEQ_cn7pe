package com.hmg.eq20.ui;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.hmg.eq20.core.Bands;
import com.hmg.eq20.core.BandsGeometry;
import com.hmg.eq20.core.RoomCode;
import com.hmg.eq20.core.Settings;
import com.hmg.eq20.core.Source;
import com.hmg.eq20.daemon.Eq20Daemon;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

/**
 * EQ screen. Writes Settings to files/eq20.conf; the root daemon (NEMESIS service hmg-eq20/eq20d) applies it
 * within about 250 ms and reports back in the package status file shown on the status line.
 */
public final class EqActivity extends Activity {
    static final String STATUS_PATH = "/data/nemesis/apps/hmg-eq20/state/status";
    private static final String STALE = "stale";
    private static final long STATUS_STALE_MS = 30000;
    private static final int BG = 0xFF111111, SURFACE = 0xFF171717, LINE = 0xFF343434, BLUE = 0xFF0070F3;
    private static final int SELECTED = 0xFF0D2A4D;
    private static final int TEXT = 0xFFF5F5F5, MUTED = 0xFF9A9A9A;
    private static final long LIVE_WRITE_MS = 150;
    static final int HEADER_GAP = 12;

    private final Handler handler = new Handler();
    private static final int NOISE_RATE = 44100, NOISE_FRAMES = 65536;
    private static final double NOISE_RMS_DB = -18;
    private static final long NOISE_MAX_MS = 120000;
    private LinearLayout eqPanel, roomPanel;
    private TextView roomToggle, noiseButton, codeView, roomMessage, applyBt, applyAa, undo, noiseInfo;
    static final String ROOM_HELP = "휴대폰에서 측정 페이지를 열고 신호를 재생한 뒤, 측정 결과 코드를 입력하세요";
    private final AudioManager.OnAudioFocusChangeListener focusListener = new AudioManager.OnAudioFocusChangeListener() {
        @Override
        public void onAudioFocusChange(int change) {
            // the signal keeps playing; focus is only requested so the head unit pauses music and opens the media path
        }
    };
    private int lastHead = -1;
    private long lastInfo;
    private final StringBuilder code = new StringBuilder();
    private short[] pink;
    private AudioTrack noise;
    private long noiseStarted;
    private Settings settings;
    private Source source = Source.BT;
    private EqBandsView bands;
    private TextView power, status, btTab, aaTab;
    private final java.util.List<TextView> presetButtons = new java.util.ArrayList<TextView>();
    private long lastLiveWrite;

    private final Runnable statusPoll = new Runnable() {
        @Override
        public void run() {
            showStatus();
            handler.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        settings = load();
        setContentView(build());
        refresh();
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(statusPoll);
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(statusPoll);
        stopNoise();
        super.onPause();
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private View build() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        LinearLayout header = row(60);
        header.setBackgroundColor(SURFACE);
        header.setPadding(0, 0, dp(HEADER_GAP), 0);
        TextView title = text("20밴드 EQ", 28, TEXT, true);
        title.setPadding(dp(24), 0, dp(24), 0);
        header.addView(title, new LinearLayout.LayoutParams(0, -1, 1));
        roomToggle = button("룸 보정", 21);
        roomToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showRoom(roomPanel.getVisibility() != View.VISIBLE);
            }
        });
        header.addView(roomToggle, headerButton(160));
        power = button("", 21);
        power.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                save(settings.withEnabled(!settings.enabled));
                refresh();
            }
        });
        header.addView(power, headerButton(160));
        TextView close = button("닫기", 21);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // this firmware's finishActivity demands GET_TASKS (car log 2026-11-19); fall back to leaving the app
                try {
                    finish();
                } catch (SecurityException e) {
                    moveTaskToBack(true);
                }
            }
        });
        header.addView(close, headerButton(132));
        root.addView(header, new LinearLayout.LayoutParams(-1, dp(60)));
        root.addView(hairline());
        eqPanel = new LinearLayout(this);
        eqPanel.setOrientation(LinearLayout.VERTICAL);
        root.addView(eqPanel, new LinearLayout.LayoutParams(-1, 0, 1));
        roomPanel = buildRoom();
        roomPanel.setVisibility(View.GONE);
        root.addView(roomPanel, new LinearLayout.LayoutParams(-1, 0, 1));
        buildEq(eqPanel);
        return root;
    }

    private void buildEq(LinearLayout root) {
        LinearLayout tabs = row(64);
        tabs.setPadding(dp(16), dp(8), dp(16), dp(8));
        btTab = tab(Source.BT);
        aaTab = tab(Source.AA);
        tabs.addView(btTab, new LinearLayout.LayoutParams(dp(200), -1));
        tabs.addView(spacer(12));
        tabs.addView(aaTab, new LinearLayout.LayoutParams(dp(200), -1));
        status = text("", 19, MUTED, false);
        status.setEllipsize(android.text.TextUtils.TruncateAt.END);
        status.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = readStatus();
                String error = text == null || STALE.equals(text) ? null
                        : value(text, source.name().toLowerCase(java.util.Locale.US) + ".error");
                new android.app.AlertDialog.Builder(EqActivity.this)
                        .setTitle(source.label + " 상태")
                        .setMessage(status.getText() + (error == null ? "" : "\n\n" + error))
                        .setPositiveButton("닫기", null)
                        .show();
            }
        });
        status.setPadding(dp(24), 0, dp(16), 0);
        tabs.addView(status, new LinearLayout.LayoutParams(0, -1, 1));
        root.addView(tabs, new LinearLayout.LayoutParams(-1, dp(64)));

        bands = new EqBandsView(this);
        bands.setPadding(dp(16), 0, dp(16), 0);
        bands.setListener(new EqBandsView.Listener() {
            @Override
            public void onLevelsChanged(short[] levels, boolean done) {
                long now = System.currentTimeMillis();
                if (done || now - lastLiveWrite >= LIVE_WRITE_MS) {
                    lastLiveWrite = now;
                    save(settings.withLevels(source, levels));
                }
                if (done) {
                    highlightPreset();
                }
            }
        });
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, 0, 1);
        bp.setMargins(dp(16), dp(8), dp(16), dp(8));
        root.addView(bands, bp);
        root.addView(hairline());

        LinearLayout presets = row(76);
        presets.setPadding(dp(16), dp(8), dp(16), dp(8));
        for (int i = 0; i < Bands.PRESET_NAMES.length; i++) {
            final int index = i;
            TextView b = button(Bands.PRESET_NAMES[i], 21);
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    apply(Bands.preset(index));
                }
            });
            presets.addView(b, new LinearLayout.LayoutParams(0, -1, 1));
            presetButtons.add(b);
            presets.addView(spacer(8));
        }
        for (int i = 1; i <= 3; i++) {
            final String key = "user" + i;
            TextView b = button("사용자 " + i, 21);
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    short[] lv = parseCsv(prefs().getString(key, null));
                    if (lv == null) {
                        toast("저장된 값이 없습니다. 길게 눌러 현재 설정을 저장하세요");
                    } else {
                        apply(lv);
                    }
                }
            });
            b.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    prefs().edit().putString(key, csv(bands.getLevels())).commit();
                    toast("현재 설정을 " + ((TextView) v).getText() + "에 저장했습니다");
                    highlightPreset();
                    return true;
                }
            });
            presets.addView(b, new LinearLayout.LayoutParams(0, -1, 1));
            presetButtons.add(b);
            if (i < 3) {
                presets.addView(spacer(8));
            }
        }
        root.addView(presets, new LinearLayout.LayoutParams(-1, dp(76)));
    }

    /**
     * Room correction: the head unit plays the test signal, the phone page (roomcorr.html) records and computes the
     * correction and shows it as a 25-character code, which is typed in here.
     */
    private LinearLayout buildRoom() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(8), dp(16), dp(8));

        LinearLayout top = row(56);
        noiseButton = button("", 21);
        noiseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (noise == null) {
                    startNoise();
                } else {
                    stopNoise();
                }
            }
        });
        top.addView(noiseButton, new LinearLayout.LayoutParams(dp(260), -1));
        TextView help = text(ROOM_HELP, 19, MUTED, false);
        noiseInfo = help;
        help.setEllipsize(android.text.TextUtils.TruncateAt.END);
        help.setPadding(dp(24), 0, 0, 0);
        top.addView(help, new LinearLayout.LayoutParams(0, -1, 1));
        root.addView(top, new LinearLayout.LayoutParams(-1, dp(56)));

        codeView = text("", 30, TEXT, false);
        codeView.setTypeface(Typeface.MONOSPACE);
        codeView.setGravity(Gravity.CENTER);
        background(codeView, SURFACE, LINE);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, dp(60));
        cp.setMargins(0, dp(8), 0, 0);
        root.addView(codeView, cp);
        roomMessage = text("", 19, MUTED, false);
        roomMessage.setGravity(Gravity.CENTER);
        roomMessage.setEllipsize(android.text.TextUtils.TruncateAt.END);
        root.addView(roomMessage, new LinearLayout.LayoutParams(-1, dp(36)));

        String keys = RoomCode.KEYS;
        int k = 0;
        for (int r = 0; r < 3; r++) {
            LinearLayout line = row(52);
            for (int col = 0; col < 12; ) {
                TextView b;
                int span = 1;
                if (k < keys.length()) {
                    final char c = keys.charAt(k++);
                    b = button(String.valueOf(c), 22);
                    b.setTypeface(Typeface.MONOSPACE);
                    b.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            typeCode(c);
                        }
                    });
                } else if (col == 8) {
                    span = 2;
                    b = button("한 글자 지움", 19);
                    b.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (code.length() > 0) {
                                code.setLength(code.length() - 1);
                            }
                            showCode();
                        }
                    });
                } else {
                    span = 2;
                    b = button("모두 지움", 19);
                    b.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            code.setLength(0);
                            showCode();
                        }
                    });
                }
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -1, span);
                lp.setMargins(col == 0 ? 0 : dp(6), 0, 0, 0);
                line.addView(b, lp);
                col += span;
            }
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, dp(52));
            rp.setMargins(0, r == 0 ? 0 : dp(6), 0, 0);
            root.addView(line, rp);
        }

        LinearLayout actions = row(60);
        applyBt = button("BT 음악에 적용", 21);
        applyAa = button("Android Auto에 적용", 21);
        undo = button("되돌리기", 21);
        TextView back = button("EQ 화면으로", 21);
        applyBt.setOnClickListener(applyListener(Source.BT));
        applyAa.setOnClickListener(applyListener(Source.AA));
        undo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                undoRoom();
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showRoom(false);
            }
        });
        TextView[] all = {applyBt, applyAa, undo, back};
        for (int i = 0; i < all.length; i++) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -1, 1);
            lp.setMargins(i == 0 ? 0 : dp(8), 0, 0, 0);
            actions.addView(all[i], lp);
        }
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, dp(60));
        ap.setMargins(0, dp(12), 0, 0);
        root.addView(actions, ap);
        return root;
    }

    private View.OnClickListener applyListener(final Source target) {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RoomCode rc = decodedCode();
                if (rc == null) {
                    toast("먼저 휴대폰에 표시된 25자리 코드를 입력하세요");
                    return;
                }
                undoPrefs().edit().putString(target.name(), csv(settings.levels(target))).commit();
                source = target;
                save(settings.withLevels(target, rc.levelsMb()).withEnabled(true));
                stopNoise();
                showRoom(false);
                toast(target.label + "에 룸 보정을 적용했습니다. 룸 보정 화면의 '되돌리기'로 이전 설정을 복원할 수 있습니다");
            }
        };
    }

    private void undoRoom() {
        short[] prev = parseCsv(undoPrefs().getString(source.name(), null));
        if (prev == null) {
            toast(source.label + ": 되돌릴 이전 설정이 없습니다");
            return;
        }
        save(settings.withLevels(source, prev));
        undoPrefs().edit().remove(source.name()).commit();
        showRoom(false);
        toast(source.label + ": 룸 보정 전 설정으로 되돌렸습니다");
    }

    private SharedPreferences undoPrefs() {
        return getSharedPreferences("room_undo", MODE_PRIVATE);
    }

    private void showRoom(boolean show) {
        if (!show) {
            stopNoise();
        }
        roomPanel.setVisibility(show ? View.VISIBLE : View.GONE);
        eqPanel.setVisibility(show ? View.GONE : View.VISIBLE);
        background(roomToggle, show ? BLUE : SURFACE, show ? BLUE : LINE);
        if (show) {
            showCode();
        } else {
            refresh();
        }
    }

    private void typeCode(char c) {
        if (code.length() < 25) {
            code.append(c);
        }
        showCode();
    }

    private RoomCode decodedCode() {
        if (code.length() != 25) {
            return null;
        }
        try {
            return RoomCode.decode(code.toString());
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    private void showCode() {
        codeView.setText(RoomCode.display(code.toString()));
        String msg;
        int color = MUTED;
        if (code.length() < 25) {
            msg = code.length() == 0 ? "코드를 입력하세요 (25자리, 휴대폰 화면과 같게)" : (25 - code.length()) + "자 남음";
        } else {
            try {
                RoomCode rc = RoomCode.decode(code.toString());
                msg = "확인됨 · " + rc.profileName() + " · 목표 " + rc.targetName() + " · " + RoomCode.summary(rc.correctionDb);
                color = TEXT;
            } catch (IllegalArgumentException e) {
                msg = e.getMessage();
                color = 0xFFFF6B6B;
            }
        }
        roomMessage.setText(msg);
        roomMessage.setTextColor(color);
        boolean ok = decodedCode() != null;
        applyBt.setEnabled(ok);
        applyAa.setEnabled(ok);
        applyBt.setAlpha(ok ? 1f : 0.4f);
        applyAa.setAlpha(ok ? 1f : 0.4f);
        noiseButton.setText(noise == null ? "측정 신호 재생" : "측정 신호 정지");
        background(noiseButton, noise == null ? SURFACE : BLUE, noise == null ? LINE : BLUE);
    }

    /** Looping pink noise on STREAM_MUSIC (app session, so the EQ is not applied), fades in, stops itself. */
    private void startNoise() {
        if (pink == null) {
            pink = RoomCode.pinkNoise(NOISE_FRAMES, NOISE_RATE, 20261118L, NOISE_RMS_DB);
        }
        try {
            AudioTrack t = new AudioTrack(AudioManager.STREAM_MUSIC, NOISE_RATE, AudioFormat.CHANNEL_OUT_STEREO,
                    AudioFormat.ENCODING_PCM_16BIT, pink.length * 2, AudioTrack.MODE_STATIC);
            if (t.write(pink, 0, pink.length) != pink.length || t.setLoopPoints(0, NOISE_FRAMES, -1) != AudioTrack.SUCCESS) {
                t.release();
                toast("측정 신호를 준비하지 못했습니다");
                return;
            }
            t.setStereoVolume(0f, 0f);
            AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
            int focus = am.requestAudioFocus(focusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT);
            t.play();
            noise = t;
            noiseStarted = System.currentTimeMillis();
            lastHead = -1;
            writeNoiseSession(t.getAudioSessionId());
            noiseInfo.setText("재생 시작 · 오디오 포커스 " + (focus == AudioManager.AUDIOFOCUS_REQUEST_GRANTED ? "받음" : "거부됨")
                    + " · 세션 " + t.getAudioSessionId());
            handler.post(noiseTick);
        } catch (Exception e) {
            toast("측정 신호를 재생하지 못했습니다: " + e.getMessage());
        }
        showCode();
    }

    private void stopNoise() {
        handler.removeCallbacks(noiseTick);
        if (noise != null) {
            try {
                noise.stop();
            } catch (IllegalStateException ignored) {
                // already stopped
            }
            noise.release();
            noise = null;
            ((AudioManager) getSystemService(AUDIO_SERVICE)).abandonAudioFocus(focusListener);
            new File(getFilesDir(), Eq20Daemon.NOISE_SESSION_FILE).delete();
            if (noiseInfo != null) {
                noiseInfo.setText(ROOM_HELP);
            }
        }
        if (noiseButton != null) {
            showCode();
        }
    }

    private final Runnable noiseTick = new Runnable() {
        @Override
        public void run() {
            if (noise == null) {
                return;
            }
            long t = System.currentTimeMillis() - noiseStarted;
            if (t > NOISE_MAX_MS) {
                stopNoise();
                toast("측정 신호를 자동으로 멈췄습니다");
                return;
            }
            float v = Math.min(1f, t / 1500f);
            noise.setStereoVolume(v, v);
            long now = System.currentTimeMillis();
            if (now - lastInfo >= 1000) {
                lastInfo = now;
                showNoiseInfo();
            }
            handler.postDelayed(this, 50);
        }
    };

    /**
     * What is known about the test signal: does the track's play position advance (the mixer pulls data), and
     * what the root daemon sees in AudioFlinger (active or not, output thread, track volume).
     */
    private void showNoiseInfo() {
        int head = noise.getPlaybackHeadPosition();
        String pos = lastHead < 0 ? "재생 위치 확인 중" : head != lastHead ? "재생 위치 진행 중" : "재생 위치 멈춤(출력 안 됨)";
        lastHead = head;
        String flinger = null;
        String text = readStatus();
        if (text != null && !STALE.equals(text)) {
            flinger = value(text, "noise");
        }
        if (flinger == null) {
            flinger = "엔진 보고 없음";
        } else if (flinger.startsWith("active ")) {
            flinger = "믹서 활성 · " + flinger.substring(7);
        } else if (flinger.startsWith("inactive ")) {
            flinger = "믹서 비활성 · " + flinger.substring(9);
        }
        noiseInfo.setText("재생 중 " + (System.currentTimeMillis() - noiseStarted) / 1000 + "초 · " + pos + " · " + flinger);
    }

    private void writeNoiseSession(int session) {
        try {
            FileOutputStream out = new FileOutputStream(new File(getFilesDir(), Eq20Daemon.NOISE_SESSION_FILE));
            try {
                out.write(String.valueOf(session).getBytes("UTF-8"));
            } finally {
                out.close();
            }
        } catch (Exception ignored) {
            // diagnostics only
        }
    }

    private void apply(short[] levels) {
        save(settings.withLevels(source, levels));
        bands.setLevels(levels);
        highlightPreset();
    }

    /** Blue border on the preset (built-in first, then user slots) equal to the current curve. */
    private void highlightPreset() {
        short[] cur = bands.getLevels();
        int match = -1;
        for (int i = 0; i < presetButtons.size() && match < 0; i++) {
            short[] p = i < Bands.PRESET_NAMES.length ? Bands.preset(i)
                    : parseCsv(prefs().getString("user" + (i - Bands.PRESET_NAMES.length + 1), null));
            if (p != null && java.util.Arrays.equals(p, cur)) {
                match = i;
            }
        }
        for (int i = 0; i < presetButtons.size(); i++) {
            background(presetButtons.get(i), i == match ? SELECTED : SURFACE, i == match ? BLUE : LINE);
        }
    }

    private void refresh() {
        power.setText(settings.enabled ? "EQ 켜짐" : "EQ 꺼짐");
        background(power, settings.enabled ? BLUE : SURFACE, settings.enabled ? BLUE : LINE);
        background(btTab, source == Source.BT ? BLUE : SURFACE, source == Source.BT ? BLUE : LINE);
        background(aaTab, source == Source.AA ? BLUE : SURFACE, source == Source.AA ? BLUE : LINE);
        bands.setLevels(settings.levels(source));
        bands.setEnabledLook(settings.enabled);
        highlightPreset();
        showStatus();
    }

    private void showStatus() {
        String text = readStatus();
        if (text == null) {
            status.setText("엔진 상태를 읽을 수 없습니다 (NEMESIS 서비스 hmg-eq20/eq20d 확인)");
            return;
        }
        if (STALE.equals(text)) {
            status.setText("엔진 응답 없음 (NEMESIS 서비스 hmg-eq20/eq20d 확인)");
            return;
        }
        String key = source.name().toLowerCase(java.util.Locale.US);
        String session = value(text, key + ".session");
        String error = value(text, key + ".error");
        if ("0".equals(value(text, "engine"))) {
            status.setText("EQ 엔진이 설치되지 않았습니다 (설치 실패로 순정 복원됨). USB로 hmg-eq20을 다시 설치하세요");
        } else if ("0".equals(value(text, "enabled"))) {
            status.setText("EQ 꺼짐: 원음 그대로 출력합니다");
        } else if (error != null) {
            status.setText(source.label + ": 적용 실패 (" + shortError(error) + ") · 눌러서 전체 보기");
        } else if (session != null && !"-1".equals(session)) {
            String hits = value(text, key + ".limiter_hits");
            status.setText(source.label + ": 적용 중" + ("0".equals(hits) || hits == null ? "" : " · 클리핑 방지 동작 " + hits + "회"));
        } else {
            status.setText(source.label + ": 재생을 기다리는 중 (재생하면 자동 적용)");
        }
    }

    /** Daemon error without class names and the session preamble, so the code/value fits on the status line. */
    static String shortError(String error) {
        return error.replaceAll("[a-z]+(\\.[a-z]+)+\\.", "").replaceAll("eq20 did not answer on session \\d+: ", "응답 없음 ");
    }

    static String value(String text, String key) {
        for (String line : text.split("\n")) {
            if (line.startsWith(key + "=")) {
                return line.substring(key.length() + 1);
            }
        }
        return null;
    }

    private String readStatus() {
        File f = new File(STATUS_PATH);
        if (!f.isFile()) {
            return null;
        }
        // the daemon rewrites the file at least every 10 s while it runs
        if (Math.abs(System.currentTimeMillis() - f.lastModified()) > STATUS_STALE_MS) {
            return STALE;
        }
        return read(f);
    }

    private Settings load() {
        Settings s = Settings.parse(read(new File(getFilesDir(), Settings.FILE_NAME)));
        return s == null ? Settings.defaults() : s;
    }

    /** Atomic write so the daemon never reads half a file. */
    private void save(Settings s) {
        settings = s;
        File dir = getFilesDir();
        File tmp = new File(dir, Settings.FILE_NAME + ".tmp");
        try {
            FileOutputStream out = new FileOutputStream(tmp);
            try {
                out.write(s.serialize().getBytes("UTF-8"));
            } finally {
                out.close();
            }
            if (!tmp.renameTo(new File(dir, Settings.FILE_NAME))) {
                toast("설정을 저장하지 못했습니다");
            }
        } catch (Exception e) {
            toast("설정을 저장하지 못했습니다: " + e.getMessage());
        }
    }

    private static String read(File f) {
        try {
            FileInputStream in = new FileInputStream(f);
            try {
                byte[] b = new byte[(int) Math.min(f.length(), 8192)];
                int n = in.read(b);
                return n <= 0 ? null : new String(b, 0, n, "UTF-8");
            } finally {
                in.close();
            }
        } catch (Exception e) {
            return null;
        }
    }

    private SharedPreferences prefs() {
        return getSharedPreferences("presets_" + source.name(), MODE_PRIVATE);
    }

    static String csv(short[] v) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < v.length; i++) {
            sb.append(i == 0 ? "" : ",").append(v[i]);
        }
        return sb.toString();
    }

    static short[] parseCsv(String s) {
        if (s == null) {
            return null;
        }
        String[] p = s.split(",");
        if (p.length != Bands.COUNT) {
            return null;
        }
        short[] out = new short[Bands.COUNT];
        try {
            for (int i = 0; i < out.length; i++) {
                out[i] = Bands.clamp(i, Integer.parseInt(p[i]));
            }
        } catch (NumberFormatException e) {
            return null;
        }
        return out;
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    /** Header buttons: gap between them and inset from the header edges. */
    private LinearLayout.LayoutParams headerButton(int widthDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(widthDp), -1);
        lp.setMargins(dp(HEADER_GAP), dp(8), 0, dp(8));
        return lp;
    }

    private LinearLayout row(int heightDp) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        l.setMinimumHeight(dp(heightDp));
        return l;
    }

    private TextView text(String s, int sp, int color, boolean medium) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp * BandsGeometry.TEXT_SCALE);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setSingleLine(true);
        t.setTypeface(Typeface.create(medium ? "sans-serif-medium" : "sans-serif", Typeface.NORMAL));
        return t;
    }

    private TextView button(String s, int sp) {
        TextView b = text(s, sp, TEXT, true);
        b.setGravity(Gravity.CENTER);
        b.setClickable(true);
        background(b, SURFACE, LINE);
        return b;
    }

    private TextView tab(final Source s) {
        TextView t = button(s.label, 21);
        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                source = s;
                refresh();
            }
        });
        return t;
    }

    private void background(View v, int fill, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(6));
        d.setStroke(dp(1), stroke);
        v.setBackgroundDrawable(d);
    }

    private View hairline() {
        View v = new View(this);
        v.setBackgroundColor(LINE);
        v.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(1)));
        return v;
    }

    private View spacer(int widthDp) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(widthDp), 1));
        return v;
    }
}
