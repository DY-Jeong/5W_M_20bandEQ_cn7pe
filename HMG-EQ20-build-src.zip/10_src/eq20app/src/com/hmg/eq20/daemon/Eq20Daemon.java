package com.hmg.eq20.daemon;

import android.media.audiofx.AudioEffect;
import android.util.Log;

import com.hmg.eq20.core.Controller;
import com.hmg.eq20.core.FlingerTracks;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

/**
 * Root daemon run by the NEMESIS service via app_process.
 * run SETTINGS STATUS : keep eq20 attached to the BT / AA music sessions with the app's settings.
 * query              : exit 0 if the eq20 effect is registered in mediaserver (used by postinstall).
 */
public final class Eq20Daemon {
    private static final String TAG = "HMGEQ20";
    static final UUID TYPE = UUID.fromString("e09686bc-ec86-47da-9b86-4b1ee499e6f3");
    static final UUID IMPL = UUID.fromString("f3bc120f-2838-4417-bec2-8b98750945bf");
    private static final int PARAM_NUM_BANDS = 0;
    private static final int PARAM_BAND_LEVELS = 2;
    private static final int PARAM_LIMITER_HITS = 5;
    /** eq20.h EQ20_CMD_DEBUG / EQ20_DEBUG_WORDS. */
    private static final int CMD_DEBUG = 0x10E20, DEBUG_WORDS = 32;
    /** The GET_PARAM diagnosis is logged once per daemon run. */
    private static boolean diagnosed;
    /** Written by the app (files dir, next to the settings) while the room-correction signal plays. */
    public static final String NOISE_SESSION_FILE = "noise.session";

    private Eq20Daemon() {
    }

    public static void main(String[] args) throws Exception {
        if (args.length == 1 && "query".equals(args[0])) {
            boolean found = engineRegistered();
            log("eq20_registered=" + found);
            System.exit(found ? 0 : 5);
        }
        if (args.length != 3 || !"run".equals(args[0])) {
            log("usage: run SETTINGS STATUS | query");
            System.exit(2);
        }
        run(new File(args[1]), new File(args[2]));
    }

    private static void run(final File settingsFile, File statusFile) throws Exception {
        final AndroidPlatform platform = new AndroidPlatform(settingsFile);
        final Controller controller = new Controller(platform);
        File noiseFile = new File(settingsFile.getParentFile(), NOISE_SESSION_FILE);
        prepareDebugFile(statusFile.getParentFile());
        Runtime.getRuntime().addShutdownHook(new Thread() {
            @Override
            public void run() {
                controller.releaseAll();
            }
        });
        log("eq20d start settings=" + settingsFile + " status=" + statusFile);
        long lastStamp = -1, lastTick = 0, lastWrite = 0;
        String lastStatus = null;
        while (true) {
            long stamp = settingsFile.lastModified() ^ settingsFile.length();
            long now = System.currentTimeMillis();
            // settings changes apply within 250 ms; track discovery runs every 2 s
            if (stamp != lastStamp || now - lastTick >= 2000) {
                lastStamp = stamp;
                lastTick = now;
                try {
                    controller.tick();
                } catch (Throwable t) {
                    log("tick failed: " + t);
                }
                String status = controller.status() + "engine=" + (engineRegistered() ? 1 : 0) + "\n"
                        + noiseStatus(noiseFile, platform.lastDump);
                // rewrite at least every 10 s: the app treats an older file as a dead daemon
                if (!status.equals(lastStatus) || now - lastWrite >= 10000) {
                    writeStatus(statusFile, "time=" + stampNow() + "\n" + status);
                    lastStatus = status;
                    lastWrite = now;
                }
            }
            Thread.sleep(250);
        }
    }

    /** True if mediaserver lists the eq20 effect (false after a failed or rolled-back install). */
    static boolean engineRegistered() {
        try {
            for (AudioEffect.Descriptor d : AudioEffect.queryEffects()) {
                if (IMPL.equals(d.uuid)) {
                    return true;
                }
            }
        } catch (Exception e) {
            log("queryEffects failed: " + e);
        }
        return false;
    }

    /**
     * While the app plays the room-correction test signal it writes its session id to files/noise.session; the
     * status then reports what AudioFlinger does with that track (active or not, output thread, volume).
     */
    private static String noiseStatus(File noiseFile, String dump) {
        if (!noiseFile.isFile()) {
            return "";
        }
        try {
            int session = Integer.parseInt(readAll(new FileInputStream(noiseFile)).trim());
            String d = FlingerTracks.describe(dump == null ? "" : dump, session);
            return "noise=" + (d == null ? "session " + session + " not in AudioFlinger" : d) + "\n";
        } catch (Exception e) {
            return "noise=unreadable\n";
        }
    }

    /** eq20.h EQ20_DEBUG_FILE: written by the effect inside mediaserver after every command. */
    private static File fxDebugFile;

    /** Empty, world-writable file so mediaserver (uid media) can write the effect's debug words. */
    private static void prepareDebugFile(File stateDir) {
        fxDebugFile = new File(stateDir, "fxdebug.bin");
        try {
            new FileOutputStream(fxDebugFile).close();
            fxDebugFile.setReadable(true, false);
            fxDebugFile.setWritable(true, false);
        } catch (Exception e) {
            log("fxdebug.bin not prepared: " + e);
        }
    }

    static void logDebugFile() {
        if (fxDebugFile == null || fxDebugFile.length() < 4 * DEBUG_WORDS) {
            log("diagnose: fxdebug.bin empty (" + (fxDebugFile == null ? "-" : fxDebugFile.length() + " bytes")
                    + "): the effect wrote nothing");
            return;
        }
        try {
            byte[] b = new byte[4 * DEBUG_WORDS];
            FileInputStream in = new FileInputStream(fxDebugFile);
            try {
                int n = in.read(b);
                log("diagnose: fxdebug.bin (" + n + " bytes) " + describeDebug(b));
            } finally {
                in.close();
            }
        } catch (Exception e) {
            log("diagnose: fxdebug.bin unreadable " + e);
        }
    }

    /** Decodes the effect's debug words (layout in eq20.h). */
    static String describeDebug(byte[] words) {
        ByteBuffer r = ByteBuffer.wrap(words).order(ByteOrder.LITTLE_ENDIAN);
        StringBuilder counts = new StringBuilder();
        for (int i = 0; i < 16; i++) {
            int n = r.getInt(4 * (2 + i));
            if (n != 0) {
                counts.append(counts.length() == 0 ? "" : ",").append(i).append(':').append(n);
            }
        }
        return "magic=" + Integer.toHexString(r.getInt(0)) + " commands=" + r.getInt(4) + " byCode={" + counts + "} other="
                + r.getInt(4 * 18) + " lastGet cmdSize=" + r.getInt(4 * 19) + " psize=" + r.getInt(4 * 20) + " vsize="
                + r.getInt(4 * 21) + " replySize=" + r.getInt(4 * 22) + " result=" + r.getInt(4 * 23)
                + " lastSetConfig cmdSize=" + r.getInt(4 * 24) + " rate=" + r.getInt(4 * 25) + " inCh=0x"
                + Integer.toHexString(r.getInt(4 * 26)) + " outCh=0x" + Integer.toHexString(r.getInt(4 * 27))
                + " fmtAccess=0x" + Integer.toHexString(r.getInt(4 * 28)) + " errno=" + r.getInt(4 * 29)
                + " lastCmd=" + r.getInt(4 * 30) + " ret=" + r.getInt(4 * 31);
    }

    private static void writeStatus(File status, String text) {        File tmp = new File(status.getPath() + ".tmp");
        try {
            FileOutputStream out = new FileOutputStream(tmp);
            try {
                out.write(text.getBytes("UTF-8"));
            } finally {
                out.close();
            }
            tmp.setReadable(true, false);
            if (!tmp.renameTo(status)) {
                log("status rename failed");
            }
        } catch (Exception e) {
            log("status write failed: " + e);
        }
    }

    static void log(String msg) {
        System.out.println(stampNow() + " " + msg);
        System.out.flush();
        Log.i(TAG, msg);
    }

    private static String stampNow() {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date());
    }

    static String readAll(InputStream in) throws Exception {
        try {
            ByteArrayOutputStream buf = new ByteArrayOutputStream();
            byte[] b = new byte[8192];
            int n;
            while ((n = in.read(b)) > 0) {
                buf.write(b, 0, n);
            }
            return buf.toString("UTF-8");
        } finally {
            in.close();
        }
    }

    private static final class AndroidPlatform implements Controller.Platform {
        private final File settingsFile;
        volatile String lastDump;
        private boolean logcatSaved;

        private static void logcatEffects() {
            try {
                Process p = Runtime.getRuntime().exec(new String[] {"/system/bin/logcat", "-d", "-v", "time", "-t", "2000"});
                String text = readAll(p.getInputStream());
                p.waitFor();
                int n = 0;
                for (String line : text.split("\r?\n")) {
                    if (line.matches("(?i).*(effect|eq20|soundfx|AudioFlinger).*") && !line.contains("HMGEQ20")) {
                        Eq20Daemon.log("logcat: " + line);
                        n++;
                    }
                }
                Eq20Daemon.log("logcat: " + n + " effect-related lines");
            } catch (Exception e) {
                Eq20Daemon.log("logcat failed: " + e);
            }
        }

        AndroidPlatform(File settingsFile) {
            this.settingsFile = settingsFile;
        }

        @Override
        public String dumpFlinger() {
            try {
                Process p = Runtime.getRuntime().exec(new String[] {"/system/bin/dumpsys", "media.audio_flinger"});
                String text = readAll(p.getInputStream());
                p.waitFor();
                lastDump = text;
                return text;
            } catch (Exception e) {
                return "";
            }
        }

        @Override
        public Set<Integer> pidsOf(String cmdline) {
            Set<Integer> pids = new HashSet<Integer>();
            File[] entries = new File("/proc").listFiles();
            if (entries == null) {
                return pids;
            }
            for (File p : entries) {
                if (!p.getName().matches("\\d+")) {
                    continue;
                }
                try {
                    String raw = readAll(new FileInputStream(new File(p, "cmdline")));
                    int nul = raw.indexOf('\0');
                    if (cmdline.equals(nul >= 0 ? raw.substring(0, nul) : raw)) {
                        pids.add(Integer.valueOf(p.getName()));
                    }
                } catch (Exception ignored) {
                    // process exited
                }
            }
            return pids;
        }

        @Override
        public Controller.Effect attach(int session) throws Exception {
            try {
                return new ReflectEffect(session);
            } catch (Exception e) {
                if (!logcatSaved) {
                    // once per daemon run: what mediaserver said about the effect, for the NEMESIS log
                    logcatSaved = true;
                    logcatEffects();
                }
                throw e;
            }
        }

        @Override
        public String readSettings() {
            if (!settingsFile.isFile()) {
                return null;
            }
            try {
                return readAll(new FileInputStream(settingsFile));
            } catch (Exception e) {
                return null;
            }
        }

        @Override
        public void log(String msg) {
            Eq20Daemon.log(msg);
        }
    }

    /** eq20 effect through the hidden AudioEffect(UUID, UUID, int, int) constructor. */
    private static final class ReflectEffect implements Controller.Effect {
        private final Object fx;
        private final Method setParam, getParam, release;
        private boolean released;

        ReflectEffect(int session) throws Exception {
            Class<?> ae = Class.forName("android.media.audiofx.AudioEffect");
            try {
                fx = ae.getConstructor(UUID.class, UUID.class, int.class, int.class).newInstance(TYPE, IMPL, 1000, session);
            } catch (InvocationTargetException e) {
                // the constructor's own exception (e.g. "Cannot initialize effect engine") is the useful one
                Throwable cause = e.getCause();
                throw cause instanceof Exception ? (Exception) cause : e;
            }
            setParam = ae.getMethod("setParameter", int.class, byte[].class);
            getParam = ae.getMethod("getParameter", int.class, byte[].class);
            release = ae.getMethod("release");
            String problem = probe();
            if (problem != null) {
                diagnose(ae, problem);
                release();
                throw new IllegalStateException("eq20 did not answer on session " + session + ": " + problem);
            }
            int rc = (Integer) ae.getMethod("setEnabled", boolean.class).invoke(fx, true);
            if (rc != 0) {
                release();
                throw new IllegalStateException("setEnabled rc=" + rc);
            }
        }

        @Override
        public boolean setLevels(short[] mb) {
            ByteBuffer b = ByteBuffer.allocate(2 * mb.length).order(ByteOrder.LITTLE_ENDIAN);
            for (short v : mb) {
                b.putShort(v);
            }
            try {
                return (Integer) setParam.invoke(fx, PARAM_BAND_LEVELS, b.array()) == 0;
            } catch (Exception e) {
                return false;
            }
        }

        /**
         * Logs why GET_PARAM fails: control flag, the effect's own record of the last GET_PARAM (EQ20_CMD_DEBUG:
         * cmdSize, psize, vsize, replySize as mediaserver delivered them, and its result), and a raw GET_PARAM sent
         * through command() so the sizes computed by AudioEffect::getParameter are bypassed.
         */
        private void diagnose(Class<?> ae, String problem) {
            if (diagnosed) {
                return;
            }
            diagnosed = true;
            Eq20Daemon.log("diagnose: " + problem);
            try {
                Eq20Daemon.log("diagnose: hasControl=" + ae.getMethod("hasControl").invoke(fx));
            } catch (Exception e) {
                Eq20Daemon.log("diagnose: hasControl failed " + e);
            }
            try {
                Method command = ae.getMethod("command", int.class, byte[].class, byte[].class);
                logDebugWords(command, "after getParameter");
                ByteBuffer cmd = ByteBuffer.allocate(16).order(ByteOrder.LITTLE_ENDIAN);
                cmd.putInt(0).putInt(4).putInt(4).putInt(PARAM_NUM_BANDS);
                byte[] reply = new byte[64];
                int rc = (Integer) command.invoke(fx, 8, cmd.array(), reply);
                ByteBuffer r = ByteBuffer.wrap(reply).order(ByteOrder.LITTLE_ENDIAN);
                Eq20Daemon.log("diagnose: raw GET_PARAM rc=" + rc + " status=" + r.getInt(0) + " psize=" + r.getInt(4)
                        + " vsize=" + r.getInt(8) + " param=" + r.getInt(12) + " value=" + r.getInt(16));
                logDebugWords(command, "after raw GET_PARAM");
                logDebugFile();
            } catch (InvocationTargetException e) {
                Eq20Daemon.log("diagnose: command threw " + e.getCause());
            } catch (Exception e) {
                Eq20Daemon.log("diagnose: command failed " + e);
            }
        }

        private void logDebugWords(Method command, String when) throws Exception {
            byte[] reply = new byte[4 * DEBUG_WORDS];
            int rc = (Integer) command.invoke(fx, CMD_DEBUG, new byte[4], reply);
            Eq20Daemon.log("diagnose " + when + ": debug command rc=" + rc
                    + (rc >= 0 ? " " + describeDebug(reply) : " (blocked before the effect; reply ignored)"));
        }
        @Override
        public boolean alive() {
            return probe() == null;
        }

        /**
         * null if the effect answers PARAM_NUM_BANDS with 20, else what went wrong. getParameter returns the value
         * size on AOSP 4.4 and 0 on some vendor builds, so any non-negative return with the right value counts.
         */
        String probe() {
            byte[] v = new byte[4];
            int n;
            try {
                n = (Integer) getParam.invoke(fx, PARAM_NUM_BANDS, v);
            } catch (InvocationTargetException e) {
                return "getParameter threw " + e.getCause();
            } catch (Exception e) {
                return "getParameter failed " + e;
            }
            int bands = ByteBuffer.wrap(v).order(ByteOrder.LITTLE_ENDIAN).getInt();
            if (n >= 0 && bands == 20) {
                return null;
            }
            String[] names = {"ERROR", "ALREADY_EXISTS", "NO_INIT", "BAD_VALUE", "INVALID_OPERATION", "NO_MEMORY", "DEAD_OBJECT"};
            String meaning = n < 0 && -n <= names.length ? "(" + names[-n - 1] + ")" : "";
            return "getParameter rc=" + n + meaning + " value=" + bands;
        }

        @Override
        public int limiterHits() {
            byte[] v = new byte[4];
            try {
                int n = (Integer) getParam.invoke(fx, PARAM_LIMITER_HITS, v);
                return n == 4 ? ByteBuffer.wrap(v).order(ByteOrder.LITTLE_ENDIAN).getInt() : -1;
            } catch (Exception e) {
                return -1;
            }
        }

        @Override
        public synchronized void release() {
            if (released) {
                return;
            }
            released = true;
            try {
                release.invoke(fx);
            } catch (Exception ignored) {
                // already gone
            }
        }
    }
}
