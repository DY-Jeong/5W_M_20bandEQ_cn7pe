import com.hmg.eq20.core.Bands;
import com.hmg.eq20.core.Controller;
import com.hmg.eq20.core.FlingerTracks;
import com.hmg.eq20.core.Settings;
import com.hmg.eq20.core.Source;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Host tests for the eq20 app core. Usage: CoreTest <dir with on-car audio_flinger dumps> */
public final class CoreTest {
    private static int failures;

    public static void main(String[] args) throws Exception {
        String dir = args[0];
        testBands();
        testSettings();
        testTracks(dir);
        testController(dir);
        if (args.length > 1) {
            testRoom(args[1]);
        }
        if (failures > 0) {
            System.out.println("FAILED " + failures);
            System.exit(1);
        }
        System.out.println("eq20app CoreTest OK");
    }

    static void check(String name, boolean ok) {
        if (!ok) {
            System.out.println("FAIL " + name);
            failures++;
        }
    }

    static void testBands() {
        check("22 Hz max +3 dB", Bands.clamp(0, 1200) == 300);
        check("88 Hz max +6 dB", Bands.clamp(4, 1200) == 600);
        check("min -12 dB", Bands.clamp(10, -5000) == -1200);
        check("round half away", Bands.clamp(10, 75) == 100 && Bands.clamp(10, -75) == -100 && Bands.clamp(10, 74) == 50);
        for (int p = 0; p < Bands.PRESET_NAMES.length; p++) {
            short[] lv = Bands.preset(p);
            check("preset " + Bands.PRESET_NAMES[p] + " already within limits", Arrays.equals(lv, Bands.clampAll(lv)));
        }
        check("labels", "22".equals(Bands.label(0)) && "1k".equals(Bands.label(11)) && "1.4k".equals(Bands.label(12))
                && "16k".equals(Bands.label(19)));
        com.hmg.eq20.core.BandsGeometry g = new com.hmg.eq20.core.BandsGeometry(1.5f, 1888, 393);
        float perDb = g.pxPerDb();
        check("drag up 1 dB", g.dragLevel(10, (short) 0, -perDb) == 100);
        check("drag down 0.5 dB", g.dragLevel(10, (short) 0, perDb / 2f) == -50);
        check("small drag snaps to 0", g.dragLevel(10, (short) 0, -perDb * 0.2f) == 0);
        check("drag clamps low band at +3", g.dragLevel(0, (short) 0, -perDb * 10) == 300);
        check("drag clamps at -12", g.dragLevel(10, (short) 0, perDb * 30) == -1200);
        check("relative to start", g.dragLevel(10, (short) -600, -perDb * 2) == -400);
        check("band hit test", g.bandAt(0) == 0 && g.bandAt(g.centerX(7)) == 7 && g.bandAt(1888) == 19);
        check("knob at +6 clears the value text", g.yFor(6) - g.knob > g.valueBaseline);
        check("knob at -12 clears the band label", g.yFor(-12) + g.knob < g.labelBaseline - 17 * 1.5f);
        check("format", "+5.5".equals(com.hmg.eq20.core.BandsGeometry.format((short) 550))
                && "-12".equals(com.hmg.eq20.core.BandsGeometry.format((short) -1200)));
        System.out.println("PASS bands: limits, rounding, presets inside AMP limits, labels, slider geometry and relative drag");
    }

    static void testSettings() {
        Settings s = Settings.defaults().withLevels(Source.BT, Bands.preset(3)).withLevels(Source.AA, Bands.preset(1));
        Settings back = Settings.parse(s.serialize());
        check("round trip", back != null && back.enabled && Arrays.equals(back.bt, Bands.preset(3))
                && Arrays.equals(back.aa, Bands.preset(1)));
        check("disabled round trip", !Settings.parse(s.withEnabled(false).serialize()).enabled);
        String ok = s.serialize();
        check("CRLF tolerated", Settings.parse(ok.replace("\n", "\r\n")) != null);
        check("missing key", Settings.parse("version=1\nenabled=1\nbt=" + zeros() + "\n") == null);
        check("unknown key", Settings.parse(ok + "x=1\n") == null);
        check("duplicate key", Settings.parse(ok + "enabled=0\n") == null);
        check("bad version", Settings.parse(ok.replace("version=1", "version=2")) == null);
        check("19 values", Settings.parse(ok.replace("bt=" + csv(Bands.preset(3)), "bt=" + zeros().substring(2))) == null);
        check("above band max", Settings.parse(ok.replace("aa=300,", "aa=400,")) == null);
        check("not a number", Settings.parse(ok.replace("aa=300,", "aa=3e2,")) == null);
        check("oversized", Settings.parse(ok + new String(new char[5000]).replace('\0', ' ')) == null);
        check("withLevels clamps", Settings.defaults().withLevels(Source.BT, filled(2000)).bt[0] == 300);
        System.out.println("PASS settings: round trip, strict rejection of malformed files, clamping");
    }

    static void testTracks(String dir) throws Exception {
        List<FlingerTracks.Track> during = FlingerTracks.active(read(dir + "/20261118-134023-audio_flinger.txt"));
        check("one active track during EQ: " + during.size(), during.size() == 1);
        FlingerTracks.Track t = during.get(0);
        check("BT routing track fields", t.io == 101 && t.client == 183 && t.stream == 3 && t.session == 13
                && t.rate == 44100 && t.channelMask == 0xC && t.stereo());
        Set<Integer> ms = Collections.singleton(183);
        check("BT session", FlingerTracks.sessionFor(during, ms, Source.BT) == 13);
        check("other pid", FlingerTracks.sessionFor(during, Collections.singleton(1350), Source.BT) == -1);
        check("idle snapshot", FlingerTracks.active(read(dir + "/20261118-133522-audio_flinger.txt")).isEmpty());
        String dump = read(dir + "/20261118-134023-audio_flinger.txt");
        check("describe active BT track: " + FlingerTracks.describe(dump, 13),
                "active thread=0xb5ab9008 stream=3 state=A vol=0/0dB".equals(FlingerTracks.describe(dump, 13)));
        check("describe idle track: " + FlingerTracks.describe(dump, 106),
                "inactive thread=0xb5ab9008 stream=0 state=I vol=-10/-10dB".equals(FlingerTracks.describe(dump, 106)));
        check("describe unknown session", FlingerTracks.describe(dump, 999) == null);
        String aa = "Output thread 0xb5ad8008 active tracks\n"
                + "   Name Client Type      Fmt Chn mask Session fCount S F SRate  L dB  R dB    Server Main buf  Aux Buf Flags UndFrmCnt\n"
                + "      0   2400    3 00000001 00000001      51   4096 A 3 16000     0     0  00000000 B8E8AAE0 00000000 0x000         0 \n"
                + "      1   2400    3 00000001 00000003      52   8192 A 3 48000     0     0  00000000 B8E8AAE0 00000000 0x000         0 \n";
        check("AA picks the stereo media track, not mono guidance",
                FlingerTracks.sessionFor(FlingerTracks.active(aa), Collections.singleton(2400), Source.AA) == 52);
        System.out.println("PASS track parser on on-car dumps (BT route 0xC mask, idle) and AA stereo selection");
    }

    /** Cross-check with codes made by roomcorr-core.js, typo detection, and the head-unit pink noise. */
    static void testRoom(String vectorsPath) throws Exception {
        String json = read(vectorsPath);
        java.util.regex.Matcher m = java.util.regex.Pattern.compile(
                "\"code\":\\s*\"([^\"]+)\",\\s*\"target\":\\s*(\\d+),\\s*\"profile\":\\s*(\\d+),\\s*\"correction\":\\s*\\[([^\\]]+)\\]")
                .matcher(json);
        int n = 0;
        while (m.find()) {
            com.hmg.eq20.core.RoomCode rc = com.hmg.eq20.core.RoomCode.decode(m.group(1));
            String[] parts = m.group(4).replaceAll("\\s", "").split(",");
            int[] want = new int[parts.length];
            for (int i = 0; i < parts.length; i++) {
                want[i] = Integer.parseInt(parts[i]);
            }
            check("JS code " + m.group(1) + " decodes identically", Arrays.equals(rc.correctionDb, want)
                    && rc.target == Integer.parseInt(m.group(2)) && rc.profile == Integer.parseInt(m.group(3)));
            check("Java encode equals JS encode", com.hmg.eq20.core.RoomCode.encode(want, rc.target, rc.profile).equals(m.group(1)));
            String plain = m.group(1).replace("-", "");
            for (int p = 0; p < 25; p++) {
                char c = plain.charAt(p);
                char alt = c == 'Z' ? 'Y' : (char) ("0123456789ABCDEFGHJKMNPQRSTVWXYZ".charAt(
                        ("0123456789ABCDEFGHJKMNPQRSTVWXYZ".indexOf(c) + 1) % 32));
                boolean thrown = false;
                try {
                    com.hmg.eq20.core.RoomCode.decode(plain.substring(0, p) + alt + plain.substring(p + 1));
                } catch (IllegalArgumentException e) {
                    thrown = true;
                }
                check("typo at " + p + " in " + plain + " detected", thrown);
            }
            n++;
        }
        check("vectors found: " + n, n >= 40);
        int frames = 65536, rate = 44100;
        short[] pink = com.hmg.eq20.core.RoomCode.pinkNoise(frames, rate, 20261118L, -18);
        double[] re = new double[frames], im = new double[frames];
        double sum = 0;
        int peak = 0;
        for (int i = 0; i < frames; i++) {
            re[i] = pink[2 * i] / 32768.0;
            sum += re[i] * re[i];
            peak = Math.max(peak, Math.abs(pink[2 * i]));
            check("pink stereo identical", pink[2 * i] == pink[2 * i + 1]);
        }
        double rmsDb = 10 * Math.log10(sum / frames);
        check("pink rms -18 dBFS (" + rmsDb + ")", Math.abs(rmsDb + 18) < 0.1);
        check("pink no clipping (peak " + peak + ")", peak < 32767);
        com.hmg.eq20.core.RoomCode.fft(re, im, false);
        double ref = Double.NaN, worst = 0;
        for (double fc = 63; fc <= 8000; fc *= 2) {
            double p = 0;
            for (int k = (int) Math.ceil(fc / Math.sqrt(2) * frames / rate); k <= (int) (fc * Math.sqrt(2) * frames / rate); k++) {
                p += re[k] * re[k] + im[k] * im[k];
            }
            double db = 10 * Math.log10(p);
            ref = Double.isNaN(ref) ? db : ref;
            worst = Math.max(worst, Math.abs(db - ref));
        }
        check("pink equal power per octave 63 Hz..8 kHz (worst " + worst + " dB)", worst < 0.5);
        System.out.println("PASS room code: " + n + " JS vectors decode and re-encode identically, all single-character typos rejected");
    }
    static final class Fake implements Controller.Platform {
        String dump = "";
        String settings;
        Map<String, Set<Integer>> pids = new HashMap<String, Set<Integer>>();
        List<FakeEffect> effects = new ArrayList<FakeEffect>();
        boolean failAttach;
        List<String> logs = new ArrayList<String>();

        public String dumpFlinger() {
            return dump;
        }

        public Set<Integer> pidsOf(String cmdline) {
            Set<Integer> p = pids.get(cmdline);
            return p == null ? new HashSet<Integer>() : p;
        }

        public Controller.Effect attach(int session) throws Exception {
            if (failAttach) {
                throw new IllegalStateException("no eq20");
            }
            FakeEffect e = new FakeEffect(session);
            effects.add(e);
            return e;
        }

        public String readSettings() {
            return settings;
        }

        public void log(String msg) {
            logs.add(msg);
        }
    }

    static final class FakeEffect implements Controller.Effect {
        final int session;
        boolean alive = true, released;
        short[] levels;
        int sets;

        FakeEffect(int session) {
            this.session = session;
        }

        public boolean setLevels(short[] mb) {
            if (!alive) {
                return false;
            }
            levels = mb.clone();
            sets++;
            return true;
        }

        public boolean alive() {
            return alive && !released;
        }

        public int limiterHits() {
            return 7;
        }

        public void release() {
            released = true;
        }
    }

    static void testController(String dir) throws Exception {
        String playing = read(dir + "/20261118-134023-audio_flinger.txt");
        String idle = read(dir + "/20261118-133522-audio_flinger.txt");
        Fake f = new Fake();
        f.pids.put("/system/bin/mediaserver", Collections.singleton(183));
        Controller c = new Controller(f);

        f.dump = idle;
        c.tick();
        check("nothing to attach while idle", f.effects.isEmpty());

        f.dump = playing;
        c.tick();
        check("attached to BT session 13 with defaults (flat)", f.effects.size() == 1 && f.effects.get(0).session == 13
                && Arrays.equals(f.effects.get(0).levels, new short[20]));
        c.tick();
        check("no redundant setLevels", f.effects.get(0).sets == 1);

        f.settings = Settings.defaults().withLevels(Source.BT, Bands.preset(1)).serialize();
        c.tick();
        check("settings change applied to the live effect", f.effects.size() == 1
                && Arrays.equals(f.effects.get(0).levels, Bands.preset(1)) && f.effects.get(0).sets == 2);

        f.dump = idle;
        c.tick();
        check("pause keeps the effect", !f.effects.get(0).released && c.attachedSession(Source.BT) == 13);

        f.settings = "garbage";
        c.tick();
        check("bad settings keep the previous curve", !f.effects.get(0).released
                && c.status().contains("settings_valid=0"));

        f.effects.get(0).alive = false; // mediaserver restarted
        f.dump = playing;
        c.tick();
        check("dead effect replaced", f.effects.size() == 2 && f.effects.get(0).released
                && Arrays.equals(f.effects.get(1).levels, Bands.preset(1)));

        f.dump = playing.replace("      13   8192 A", "      14   8192 A");
        c.tick();
        check("new session gets a new effect", f.effects.size() == 3 && f.effects.get(1).released
                && f.effects.get(2).session == 14);

        f.settings = Settings.defaults().withLevels(Source.BT, Bands.preset(1)).withEnabled(false).serialize();
        c.tick();
        check("disable releases", f.effects.get(2).released && c.attachedSession(Source.BT) == -1
                && c.status().contains("enabled=0"));
        int before = f.effects.size();
        c.tick();
        check("stays off while disabled", f.effects.size() == before);

        f.settings = Settings.defaults().serialize();
        f.failAttach = true;
        c.tick();
        c.tick();
        check("attach failure reported once and in status", c.status().contains("bt.error=") &&
                countContaining(f.logs, "failed: java.lang.IllegalStateException: no eq20") == 1);
        f.failAttach = false;
        c.tick();
        check("recovers after failure", c.attachedSession(Source.BT) == 14 && !c.status().contains("bt.error="));
        check("status lists both sources", c.status().contains("bt.session=14") && c.status().contains("aa.session=-1")
                && c.status().contains("bt.limiter_hits=7"));
        c.releaseAll();
        check("releaseAll", f.effects.get(f.effects.size() - 1).released);
        System.out.println("PASS controller: attach, live update, pause, bad settings, effect death, new session, "
                + "disable, attach failure and recovery, status");
    }

    static int countContaining(List<String> l, String s) {
        int n = 0;
        for (String x : l) {
            if (x.contains(s)) {
                n++;
            }
        }
        return n;
    }

    static short[] filled(int v) {
        short[] a = new short[20];
        Arrays.fill(a, (short) v);
        return a;
    }

    static String zeros() {
        return csv(new short[20]);
    }

    static String csv(short[] v) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < v.length; i++) {
            sb.append(i == 0 ? "" : ",").append(v[i]);
        }
        return sb.toString();
    }

    static String read(String p) throws Exception {
        return new String(Files.readAllBytes(Paths.get(p)), StandardCharsets.UTF_8);
    }
}
