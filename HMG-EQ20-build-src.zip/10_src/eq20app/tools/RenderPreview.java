import com.hmg.eq20.core.Bands;
import com.hmg.eq20.core.BandsGeometry;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;

/**
 * Host preview of EqActivity / EqBandsView at the head-unit panel (1920x720 px, density 1.5).
 * Mirrors the layout numbers and drawing code of the app; Windows fonts stand in for the car's fonts,
 * so text width is approximate. Usage: RenderPreview OUTDIR
 */
public final class RenderPreview {
    static final float D = 1.5f;
    static final int W = 1920, H = 720;
    static final Color BG = c(0xFF111111), SURFACE = c(0xFF171717), LINE = c(0xFF343434), BLUE = c(0xFF0070F3);
    static final Color TEXT = c(0xFFF5F5F5), MUTED = c(0xFF9A9A9A);
    static final String SANS = "Malgun Gothic", MONO = "Consolas";

    static Color c(int argb) {
        return new Color(argb, true);
    }

    static float dp(float v) {
        return v * D;
    }

    public static void main(String[] args) throws Exception {
        File dir = new File(args[0]);
        dir.mkdirs();
        render(new File(dir, "1-bt-loudness.png"), true, "BT", Bands.preset(3), "BT 음악: 적용 중");
        render(new File(dir, "2-aa-waiting.png"), true, "AA", Bands.preset(1), "Android Auto: 재생을 기다리는 중 (재생하면 자동 적용)");
        render(new File(dir, "3-eq-off.png"), false, "BT", Bands.preset(2), "EQ 꺼짐: 원음 그대로 출력합니다");
        short[] extremes = new short[20];
        for (int i = 0; i < 20; i++) {
            extremes[i] = (short) (i % 2 == 0 ? Bands.maxMb(i) : -1200);
        }
        render(new File(dir, "4-extremes-stale.png"), true, "BT", extremes,
                "엔진 응답 없음 (NEMESIS 서비스 hmg-eq20/eq20d 확인)");
        renderRoom(new File(dir, "5-room-typing.png"), "201HH90WX5DDDD", false);
        renderRoom(new File(dir, "6-room-ok.png"), "201HH90WX5DDDDHNNNHDDHMGG", true);
        renderRoom(new File(dir, "7-room-typo.png"), "201HH90WX5DDDDHNNNHDDHMGH", false);
    }

    /** Same layout as EqActivity.buildRoom. */
    static void renderRoom(File out, String typed, boolean playing) throws Exception {
        BufferedImage img = new BufferedImage(W, H, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g.setColor(BG);
        g.fillRect(0, 0, W, H);
        float hh = header(g, true, true);
        g.setColor(LINE);
        g.fill(new Rectangle2D.Float(0, hh, W, dp(1)));

        float left = dp(16), inner = W - dp(32), y = hh + dp(1) + dp(8);
        button(g, left, y, dp(260), dp(56), playing ? "측정 신호 정지" : "측정 신호 재생", 21, playing ? BLUE : SURFACE, playing ? BLUE : LINE);
        text(g, playing ? "재생 중 12초 · 재생 위치 진행 중 · 믹서 활성 · thread=0xb5ab9008 stream=3 state=A vol=0/0dB"
                : "휴대폰에서 측정 페이지를 열고 신호를 재생한 뒤, 측정 결과 코드를 입력하세요",
                left + dp(260) + dp(24), y, dp(56), 19, MUTED, false);
        y += dp(56) + dp(8);
        RoundRectangle2D box = new RoundRectangle2D.Float(left, y, inner, dp(60), dp(12), dp(12));
        g.setColor(SURFACE);
        g.fill(box);
        g.setColor(LINE);
        g.draw(box);
        centered(g, com.hmg.eq20.core.RoomCode.display(typed), W / 2f, y + dp(42), 30, TEXT, true);
        y += dp(60);
        String msg;
        Color mc = MUTED;
        if (typed.length() < 25) {
            msg = (25 - typed.length()) + "자 남음";
        } else {
            try {
                com.hmg.eq20.core.RoomCode rc = com.hmg.eq20.core.RoomCode.decode(typed);
                msg = "확인됨 · " + rc.profileName() + " · 목표 " + rc.targetName() + " · "
                        + com.hmg.eq20.core.RoomCode.summary(rc.correctionDb);
                mc = TEXT;
            } catch (IllegalArgumentException e) {
                msg = e.getMessage();
                mc = c(0xFFFF6B6B);
            }
        }
        centered(g, msg, W / 2f, y + dp(25), 19, mc, false);
        y += dp(36);
        String keys = com.hmg.eq20.core.RoomCode.KEYS;
        float unit = (inner - dp(6) * 11) / 12;
        int k = 0;
        for (int r = 0; r < 3; r++) {
            float bx = left;
            for (int col = 0; col < 12; ) {
                int span = 1;
                String label;
                if (k < keys.length()) {
                    label = String.valueOf(keys.charAt(k++));
                } else {
                    span = 2;
                    label = col == 8 ? "한 글자 지움" : "모두 지움";
                }
                float w = unit * span + dp(6) * (span - 1);
                button(g, bx, y, w, dp(52), label, span == 1 ? 22 : 19, SURFACE, LINE);
                bx += w + dp(6);
                col += span;
            }
            y += dp(52) + dp(6);
        }
        y += dp(12) - dp(6);
        boolean ok = typed.length() == 25 && mc == TEXT;
        String[] act = {"BT 음악에 적용", "Android Auto에 적용", "되돌리기", "EQ 화면으로"};
        float aw = (inner - dp(8) * 3) / 4, ax = left;
        for (int i = 0; i < 4; i++) {
            boolean dim = i < 2 && !ok;
            button(g, ax, y, aw, dp(60), act[i], 21, dim ? c(0xFF0E0E0E) : SURFACE, dim ? c(0xFF242424) : LINE);
            ax += aw + dp(8);
        }
        y += dp(60);
        g.dispose();
        ImageIO.write(img, "png", out);
        System.out.println("wrote " + out + " (bottom " + Math.round(y) + " of " + H + ")");
    }

    static void render(File out, boolean enabled, String source, short[] levels, String status) throws Exception {
        int match = -1;
        for (int i = 0; i < Bands.PRESET_NAMES.length && match < 0; i++) {
            if (java.util.Arrays.equals(Bands.preset(i), levels)) {
                match = i;
            }
        }
        BufferedImage img = new BufferedImage(W, H, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g.setColor(BG);
        g.fillRect(0, 0, W, H);

        // header 60dp
        float y = 0, hh = header(g, false, enabled);
        y += hh;
        g.setColor(LINE);
        g.fill(new Rectangle2D.Float(0, y, W, dp(1)));
        y += dp(1);

        // tabs row 64dp, padding 16/8
        float th = dp(64);
        float tx = dp(16), ty = y + dp(8), tabH = th - dp(16);
        button(g, tx, ty, dp(200), tabH, "BT 음악", 21, "BT".equals(source) ? BLUE : SURFACE, "BT".equals(source) ? BLUE : LINE);
        tx += dp(200) + dp(12);
        button(g, tx, ty, dp(200), tabH, "Android Auto", 21, "AA".equals(source) ? BLUE : SURFACE, "AA".equals(source) ? BLUE : LINE);
        tx += dp(200);
        text(g, status, tx + dp(24), ty, tabH, 19, MUTED, false);
        y += th;

        // presets row 76dp at the bottom, hairline above
        float ph = dp(76);
        float py = H - ph;
        float bandsTop = y + dp(8), bandsBottom = py - dp(1) - dp(8);
        bands(g, dp(16), bandsTop, W - dp(32), bandsBottom - bandsTop, levels, enabled);
        g.setColor(LINE);
        g.fill(new Rectangle2D.Float(0, py - dp(1), W, dp(1)));
        String[] names = new String[Bands.PRESET_NAMES.length + 3];
        System.arraycopy(Bands.PRESET_NAMES, 0, names, 0, Bands.PRESET_NAMES.length);
        for (int i = 1; i <= 3; i++) {
            names[Bands.PRESET_NAMES.length + i - 1] = "사용자 " + i;
        }
        int n = names.length;
        float inner = W - dp(32), gaps = dp(8) * (n - 1);
        float bw = (inner - gaps) / n;
        float bx = dp(16);
        for (int i = 0; i < n; i++) {
            button(g, bx, py + dp(8), bw, ph - dp(16), names[i], 21, i == match ? c(0xFF0D2A4D) : SURFACE, i == match ? BLUE : LINE);
            bx += bw + dp(8);
        }
        g.dispose();
        ImageIO.write(img, "png", out);
        System.out.println("wrote " + out);
    }

    /** Same drawing as EqBandsView.onDraw, on the shared BandsGeometry. */
    static void bands(Graphics2D g2, float x0, float y0, float w, float h, short[] levels, boolean enabled) {
        BandsGeometry g = new BandsGeometry(D, w, h);
        java.awt.geom.AffineTransform saved = g2.getTransform();
        g2.translate(x0, y0);
        g2.setStroke(new BasicStroke(D));
        for (int db = BandsGeometry.TOP_DB; db >= BandsGeometry.BOTTOM_DB; db -= 6) {
            float y = g.yFor(db);
            g2.setColor(c(db == 0 ? BandsGeometry.ZERO : BandsGeometry.GRID));
            g2.draw(new Line2D.Float(g.axis, y, g.width, y));
            String s = BandsGeometry.format((short) (db * 100));
            g2.setFont(font(15, true));
            g2.setColor(c(BandsGeometry.MUTED));
            g2.drawString(s, g.axis - 10 * D - g2.getFontMetrics().stringWidth(s), y + 5 * D);
        }
        float zeroY = g.yFor(0);
        for (int i = 0; i < Bands.COUNT; i++) {
            float cx = g.centerX(i);
            float trackTop = g.yFor(Bands.maxMb(i) / 100f);
            g2.setColor(c(BandsGeometry.TRACK));
            g2.fill(new RoundRectangle2D.Float(cx - g.half, trackTop - g.half, 2 * g.half, g.bottom - trackTop + 2 * g.half,
                    2 * g.half, 2 * g.half));
            float y = g.yFor(levels[i] / 100f);
            g2.setColor(c(enabled ? BandsGeometry.FILL_ON : BandsGeometry.FILL_OFF));
            g2.fill(new Rectangle2D.Float(cx - g.half, Math.min(y, zeroY), 2 * g.half, Math.abs(y - zeroY)));
            g2.setColor(c(enabled ? BandsGeometry.KNOB_ON : BandsGeometry.KNOB_OFF));
            g2.fill(new Ellipse2D.Float(cx - g.knob, y - g.knob, 2 * g.knob, 2 * g.knob));
            centered(g2, BandsGeometry.format(levels[i]), cx, g.valueBaseline, 17,
                    c(enabled ? BandsGeometry.TEXT : BandsGeometry.MUTED), true);
            centered(g2, Bands.label(i), cx, g.labelBaseline, 17, c(BandsGeometry.MUTED), false);
        }
        g2.setTransform(saved);
    }
    /** Same as EqActivity's header: buttons inset 8dp vertically, HEADER_GAP between them and at the right edge. */
    static float header(Graphics2D g, boolean roomOpen, boolean enabled) {
        float hh = dp(60), gap = dp(12), bh = hh - dp(16);
        g.setColor(SURFACE);
        g.fill(new Rectangle2D.Float(0, 0, W, hh));
        text(g, "20밴드 EQ", dp(24), 0, hh, 28, TEXT, false);
        float x = W - gap - dp(132);
        button(g, x, dp(8), dp(132), bh, "닫기", 21, SURFACE, LINE);
        x -= gap + dp(160);
        button(g, x, dp(8), dp(160), bh, enabled ? "EQ 켜짐" : "EQ 꺼짐", 21, enabled ? BLUE : SURFACE, enabled ? BLUE : LINE);
        x -= gap + dp(160);
        button(g, x, dp(8), dp(160), bh, "룸 보정", 21, roomOpen ? BLUE : SURFACE, roomOpen ? BLUE : LINE);
        return hh;
    }

    static Font font(int sp, boolean mono) {
        return new Font(mono ? MONO : SANS, Font.PLAIN, Math.round(sp * D * BandsGeometry.TEXT_SCALE));
    }

    static void text(Graphics2D g, String s, float x, float y, float h, int sp, Color color, boolean mono) {
        g.setFont(font(sp, mono));
        FontMetrics fm = g.getFontMetrics();
        g.setColor(color);
        g.drawString(s, x, y + (h - fm.getHeight()) / 2 + fm.getAscent());
    }

    static void centered(Graphics2D g, String s, float cx, float baseline, int sp, Color color, boolean mono) {
        g.setFont(font(sp, mono));
        g.setColor(color);
        g.drawString(s, cx - g.getFontMetrics().stringWidth(s) / 2f, baseline);
    }

    static void button(Graphics2D g, float x, float y, float w, float h, String label, int sp, Color fill, Color stroke) {
        RoundRectangle2D r = new RoundRectangle2D.Float(x, y, w, h, dp(12), dp(12));
        g.setColor(fill);
        g.fill(r);
        g.setColor(stroke);
        g.setStroke(new BasicStroke(dp(1)));
        g.draw(r);
        g.setFont(font(sp, false));
        FontMetrics fm = g.getFontMetrics();
        int tw = fm.stringWidth(label);
        g.setColor(TEXT);
        if (tw > w - dp(8)) {
            g.setColor(new Color(0xFF, 0x60, 0x60));
        }
        g.drawString(label, x + (w - tw) / 2, y + (h - fm.getHeight()) / 2 + fm.getAscent());
    }
}
