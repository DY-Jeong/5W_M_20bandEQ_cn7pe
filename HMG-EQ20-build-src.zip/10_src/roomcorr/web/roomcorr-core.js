/*
 * Room correction core (browser + Node). Pure functions, no DOM.
 * - pinkNoise: periodic pink noise with exactly equal power per proportional band (same algorithm as the
 *   head-unit generator in eq20app RoomNoise.java).
 * - bandLevels: Welch PSD (Hann, 50% overlap) summed into the 20 half-octave eq20 bands, in dB.
 * - correction: measured (noise minus background, minus mic profile) -> 20 band corrections in 1 dB steps.
 * - encode/decode: 25-character Crockford base32 result code typed into the EQ app.
 */
(function (root, factory) {
    if (typeof module === 'object' && module.exports) {
        module.exports = factory();
    } else {
        root.RoomCorr = factory();
    }
})(typeof self !== 'undefined' ? self : this, function () {
    'use strict';

    var CENTERS = [22, 31, 44, 63, 88, 125, 177, 250, 355, 500, 710, 1000, 1400, 2000, 2800, 4000, 5600, 8000, 11000, 16000];
    var MIN_DB = -12, MAX_DB = 6, LOW_MAX_DB = 3, LOW_EDGE_HZ = 63;
    var CODE_VERSION = 1;

    /** Target curves (dB at the band centers) relative to the 250 Hz-4 kHz average. */
    var TARGETS = [
        { id: 0, name: '플랫', db: CENTERS.map(function () { return 0; }) },
        // gentle in-car house curve: some low-end lift, slight top roll-off
        { id: 1, name: '차량 기본(하우스 커브)', db: CENTERS.map(function (f) {
            if (f <= 63) return 3;
            if (f < 250) return 3 * Math.log(250 / f) / Math.log(250 / 63);
            if (f <= 4000) return 0;
            return -2 * Math.log(f / 4000) / Math.log(16000 / 4000);
        }) },
        { id: 2, name: '저음 강조', db: CENTERS.map(function (f) {
            if (f <= 63) return 3;
            if (f < 355) return 5 * Math.log(355 / f) / Math.log(355 / 63);
            return 0;
        }) }
    ];

    function maxDb(band) {
        return CENTERS[band] <= LOW_EDGE_HZ ? LOW_MAX_DB : MAX_DB;
    }

    // ---------- FFT (in-place iterative radix-2, complex) ----------
    function fft(re, im, inverse) {
        var n = re.length, i, j, k, len, half, ang, wr, wi, cr, ci, tr, ti, ur, ui;
        for (i = 1, j = 0; i < n; i++) {
            var bit = n >> 1;
            for (; j & bit; bit >>= 1) j ^= bit;
            j ^= bit;
            if (i < j) {
                tr = re[i]; re[i] = re[j]; re[j] = tr;
                ti = im[i]; im[i] = im[j]; im[j] = ti;
            }
        }
        for (len = 2; len <= n; len <<= 1) {
            half = len >> 1;
            ang = (inverse ? 2 : -2) * Math.PI / len;
            wr = Math.cos(ang); wi = Math.sin(ang);
            for (i = 0; i < n; i += len) {
                cr = 1; ci = 0;
                for (k = 0; k < half; k++) {
                    ur = re[i + k]; ui = im[i + k];
                    tr = re[i + k + half] * cr - im[i + k + half] * ci;
                    ti = re[i + k + half] * ci + im[i + k + half] * cr;
                    re[i + k] = ur + tr; im[i + k] = ui + ti;
                    re[i + k + half] = ur - tr; im[i + k + half] = ui - ti;
                    var nr = cr * wr - ci * wi;
                    ci = cr * wi + ci * wr;
                    cr = nr;
                }
            }
        }
        if (inverse) {
            for (i = 0; i < n; i++) { re[i] /= n; im[i] /= n; }
        }
    }

    /** Deterministic PRNG (mulberry32) so browser and tests generate identical noise. */
    function rng(seed) {
        var a = seed >>> 0;
        return function () {
            a = (a + 0x6D2B79F5) >>> 0;
            var t = a;
            t = Math.imul(t ^ (t >>> 15), t | 1);
            t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
            return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
        };
    }

    /**
     * Periodic pink noise of n samples (power of two): flat-magnitude random-phase spectrum shaped 1/sqrt(f)
     * between loHz and hiHz, so each proportional band carries equal power. Normalized to rmsDb dBFS.
     */
    function pinkNoise(n, rate, seed, rmsDb, loHz, hiHz) {
        var re = new Float64Array(n), im = new Float64Array(n), r = rng(seed || 1), i;
        loHz = loHz || 18; hiHz = hiHz || 20000;
        for (i = 1; i < n / 2; i++) {
            var f = i * rate / n;
            if (f < loHz || f > hiHz) continue;
            var mag = 1 / Math.sqrt(f), ph = 2 * Math.PI * r();
            re[i] = mag * Math.cos(ph); im[i] = mag * Math.sin(ph);
            re[n - i] = re[i]; im[n - i] = -im[i];
        }
        fft(re, im, true);
        var sum = 0;
        for (i = 0; i < n; i++) sum += re[i] * re[i];
        var gain = Math.pow(10, (rmsDb === undefined ? -18 : rmsDb) / 20) / Math.sqrt(sum / n);
        var out = new Float32Array(n);
        for (i = 0; i < n; i++) out[i] = re[i] * gain;
        return out;
    }

    function bandEdges(fc) {
        return [fc * Math.pow(2, -0.25), fc * Math.pow(2, 0.25)];
    }

    /** Band power (dB re full scale) of mono samples, Welch averaging with a Hann window of fftSize. */
    function bandLevels(samples, rate, fftSize) {
        var n = fftSize || 32768;
        while (n > samples.length && n > 1024) n >>= 1;
        var hop = n >> 1, win = new Float64Array(n), wsum = 0, i, s;
        for (i = 0; i < n; i++) { win[i] = 0.5 - 0.5 * Math.cos(2 * Math.PI * i / n); wsum += win[i] * win[i]; }
        var psd = new Float64Array(n / 2 + 1), segs = 0;
        var re = new Float64Array(n), im = new Float64Array(n);
        for (s = 0; s + n <= samples.length; s += hop) {
            for (i = 0; i < n; i++) { re[i] = samples[s + i] * win[i]; im[i] = 0; }
            fft(re, im, false);
            for (i = 0; i <= n / 2; i++) psd[i] += re[i] * re[i] + im[i] * im[i];
            segs++;
        }
        if (!segs) throw new Error('recording too short');
        var levels = [];
        for (var b = 0; b < CENTERS.length; b++) {
            var e = bandEdges(CENTERS[b]), p = 0;
            var lo = Math.max(1, Math.ceil(e[0] * n / rate)), hi = Math.min(n / 2, Math.floor(e[1] * n / rate));
            for (i = lo; i <= hi; i++) p += psd[i] * (i === n / 2 ? 1 : 2);
            // mean-square power of the band; nothing in the band (above Nyquist) -> -Infinity
            levels.push(hi >= lo ? 10 * Math.log10(p / (segs * wsum * n) + 1e-30) : -Infinity);
        }
        return levels;
    }

    function peakDb(samples) {
        var m = 0;
        for (var i = 0; i < samples.length; i++) { var a = Math.abs(samples[i]); if (a > m) m = a; }
        return 20 * Math.log10(m + 1e-12);
    }

    /** Mic profile value (dB, positive = mic reads high) at f by log-frequency interpolation of points. */
    function micDb(profile, f) {
        var pts = profile && profile.points;
        if (!pts || !pts.length) return 0;
        if (f <= pts[0][0]) return pts[0][1];
        if (f >= pts[pts.length - 1][0]) return pts[pts.length - 1][1];
        for (var i = 1; i < pts.length; i++) {
            if (f <= pts[i][0]) {
                var t = Math.log(f / pts[i - 1][0]) / Math.log(pts[i][0] / pts[i - 1][0]);
                return pts[i - 1][1] + t * (pts[i][1] - pts[i - 1][1]);
            }
        }
        return 0;
    }

    function powSub(totalDb, noiseDb) {
        var d = Math.pow(10, totalDb / 10) - Math.pow(10, noiseDb / 10);
        return d > 0 ? 10 * Math.log10(d) : -Infinity;
    }

    /**
     * runs: [{signal: levels[20], background: levels[20]}] (several mic positions are averaged in power).
     * Returns per band: corrected response, correction dB (1 dB steps, AMP limits), and why a band was skipped.
     */
    function correction(runs, profile, targetId, opts) {
        opts = opts || {};
        var minSnr = opts.minSnr || 10, boostShare = opts.boostShare === undefined ? 0.5 : opts.boostShare;
        var target = TARGETS[targetId] || TARGETS[0];
        var lo = (profile && profile.low) || 40, hi = (profile && profile.high) || 16000;
        var bands = [], b, r;
        for (b = 0; b < CENTERS.length; b++) {
            var sumP = 0, snrMin = Infinity;
            for (r = 0; r < runs.length; r++) {
                var snr = runs[r].signal[b] - runs[r].background[b];
                snrMin = Math.min(snrMin, snr);
                sumP += Math.pow(10, powSub(runs[r].signal[b], runs[r].background[b]) / 10);
            }
            var level = 10 * Math.log10(sumP / runs.length + 1e-30) - micDb(profile, CENTERS[b]);
            var reason = null;
            if (CENTERS[b] < lo || CENTERS[b] > hi) reason = 'mic-range';
            else if (!(snrMin >= minSnr)) reason = 'low-snr';
            bands.push({ hz: CENTERS[b], level: level, snr: snrMin, reason: reason });
        }
        var ref = 0, n = 0;
        for (b = 0; b < bands.length; b++) {
            if (bands[b].hz >= 250 && bands[b].hz <= 4000 && !bands[b].reason) { ref += bands[b].level; n++; }
        }
        if (n < 4) throw new Error('not enough valid mid bands (check level / background noise)');
        ref /= n;
        var raw = bands.map(function (x, i) {
            x.deviation = x.reason ? null : x.level - ref;
            return x.reason ? null : target.db[i] - x.deviation;
        });
        // light 3-band smoothing over valid neighbours: do not chase narrow peaks and nulls
        var smooth = raw.map(function (v, i) {
            if (v === null) return null;
            var acc = 0.5 * v, w = 0.5;
            [i - 1, i + 1].forEach(function (j) {
                if (j >= 0 && j < raw.length && raw[j] !== null) { acc += 0.25 * raw[j]; w += 0.25; }
            });
            return acc / w;
        });
        bands.forEach(function (x, i) {
            var v = smooth[i];
            if (v === null) { x.correction = 0; return; }
            if (v > 0) v *= boostShare; // fill dips only partly: boosting into a null wastes amplifier headroom
            v = Math.max(MIN_DB, Math.min(maxDb(i), Math.round(v)));
            x.correction = v === 0 ? 0 : v;
        });
        return { bands: bands, reference: ref, correction: bands.map(function (x) { return x.correction; }) };
    }

    // ---------- result code ----------
    var ALPHABET = '0123456789ABCDEFGHJKMNPQRSTVWXYZ'; // Crockford base32

    function crc8(bytes) {
        var c = 0;
        for (var i = 0; i < bytes.length; i++) {
            c ^= bytes[i];
            for (var k = 0; k < 8; k++) c = c & 0x80 ? ((c << 1) ^ 0x07) & 0xff : (c << 1) & 0xff;
        }
        return c;
    }

    /** bits: version 4, target 3, profile 6, 20 x 5 (dB + 12, 0..18), crc8 over the preceding 113 bits -> 121 bits, 25 chars. */
    function encode(correctionDb, targetId, profileId) {
        var bits = [];
        function put(v, w) { for (var i = w - 1; i >= 0; i--) bits.push((v >> i) & 1); }
        put(CODE_VERSION, 4); put(targetId, 3); put(profileId, 6);
        correctionDb.forEach(function (v, i) {
            if (v < MIN_DB || v > maxDb(i) || v !== Math.round(v)) throw new Error('band ' + i + ' out of range: ' + v);
            put(v - MIN_DB, 5);
        });
        put(crc8(toBytes(bits)), 8);
        while (bits.length % 5) bits.push(0);
        var s = '';
        for (var i = 0; i < bits.length; i += 5) {
            var v = 0;
            for (var k = 0; k < 5; k++) v = (v << 1) | bits[i + k];
            s += ALPHABET[v];
        }
        return s.replace(/(.{5})(?=.)/g, '$1-');
    }

    function toBytes(bits) {
        var out = [];
        for (var i = 0; i < bits.length; i += 8) {
            var v = 0;
            for (var k = 0; k < 8; k++) v = (v << 1) | (bits[i + k] || 0);
            out.push(v);
        }
        return out;
    }

    function normalizeCode(code) {
        return String(code).toUpperCase().replace(/[\s-]/g, '').replace(/O/g, '0').replace(/[IL]/g, '1');
    }

    /** Returns {version, target, profile, correction[20]} or throws on a typo (bad character, length or CRC). */
    function decode(code) {
        var s = normalizeCode(code), bits = [], i, k;
        if (s.length !== 25) throw new Error('code must have 25 characters');
        for (i = 0; i < s.length; i++) {
            var v = ALPHABET.indexOf(s[i]);
            if (v < 0) throw new Error('bad character ' + s[i]);
            for (k = 4; k >= 0; k--) bits.push((v >> k) & 1);
        }
        var pos = 0;
        function get(w) { var v = 0; for (var j = 0; j < w; j++) v = (v << 1) | bits[pos++]; return v; }
        var version = get(4), target = get(3), profile = get(6), corr = [];
        for (i = 0; i < 20; i++) corr.push(get(5) + MIN_DB);
        var crc = get(8);
        if (get(4) !== 0) throw new Error('checksum mismatch (typo in the last character?)');
        if (crc !== crc8(toBytes(bits.slice(0, 113)))) throw new Error('checksum mismatch (typo?)');
        if (version !== CODE_VERSION) throw new Error('unsupported code version ' + version);
        for (i = 0; i < 20; i++) if (corr[i] > maxDb(i)) throw new Error('band ' + i + ' above limit');
        return { version: version, target: target, profile: profile, correction: corr };
    }

    return {
        CENTERS: CENTERS, TARGETS: TARGETS, MIN_DB: MIN_DB, MAX_DB: MAX_DB, LOW_MAX_DB: LOW_MAX_DB,
        maxDb: maxDb, fft: fft, pinkNoise: pinkNoise, bandLevels: bandLevels, peakDb: peakDb, micDb: micDb,
        correction: correction, encode: encode, decode: decode, normalizeCode: normalizeCode, crc8: crc8
    };
});
