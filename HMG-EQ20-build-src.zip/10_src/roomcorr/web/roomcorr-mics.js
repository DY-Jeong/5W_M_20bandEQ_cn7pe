/*
 * Phone microphone profiles for room correction. Values are dB at frequency points, positive = the mic reads
 * high; the analyzer subtracts them. 'low'/'high' bound the bands that are corrected at all.
 *
 * Honesty note (research 2026-11-18): no published per-model frequency response was found for any listed phone,
 * including the Galaxy Z Flip5. The only verified requirement is Android CDD 5.4.2 (voice recognition capture:
 * SHOULD be flat +-3 dB 100 Hz-4 kHz). Each phone therefore uses its maker's family ESTIMATE:
 *  - Samsung: default capture path high-pass modelled as 2nd-order Butterworth at 80 Hz, slight lift 5.6-8 kHz;
 *    11 and 16 kHz too uncertain -> not corrected (high = 8 kHz); 63 Hz and below not corrected (low = 88 Hz).
 *  - iPhone: high-pass ~50 Hz, flat mid band; corrected 63 Hz-8 kHz.
 *  - Pixel: high-pass ~65 Hz, slight lift at 8 kHz; corrected 88 Hz-8 kHz.
 * Replace a family estimate with a measured profile (calibrated reference mic, e.g. UMIK-1) through the
 * custom profile (id 63) as soon as one exists. Profile ids are part of the result code: never renumber.
 */
(function (root, factory) {
    if (typeof module === 'object' && module.exports) {
        module.exports = factory();
    } else {
        root.RoomMics = factory();
    }
})(typeof self !== 'undefined' ? self : this, function () {
    'use strict';

    var FREQS = [22, 31, 44, 63, 88, 125, 177, 250, 355, 500, 710, 1000, 1400, 2000, 2800, 4000, 5600, 8000, 11000, 16000];

    function hpf(fc, f) {
        return -10 * Math.log10(1 + Math.pow(fc / f, 4));
    }

    function family(fc, hf) {
        return FREQS.map(function (f) {
            var v = hpf(fc, f) + (hf[f] || 0);
            return [f, Math.round(v * 10) / 10];
        });
    }

    var FAMILIES = {
        samsung: { points: family(80, { 5600: 1, 8000: 1 }), low: 88, high: 8000 },
        iphone: { points: family(50, {}), low: 63, high: 8000 },
        pixel: { points: family(65, { 8000: 1 }), low: 88, high: 8000 },
        flat: { points: [], low: 40, high: 16000 }
    };

    // id, name, family, model regex for UA Client Hints (Android) or null
    var PHONES = [
        [0, '보정 없음 (마이크 평탄 가정)', 'flat', null],
        [1, 'Galaxy Z Flip5', 'samsung', /^SM-F731/],
        [2, 'Galaxy Z Flip6', 'samsung', /^SM-F741/],
        [3, 'Galaxy Z Fold5', 'samsung', /^SM-F946/],
        [4, 'Galaxy Z Fold6', 'samsung', /^SM-F956/],
        [5, 'Galaxy S23', 'samsung', /^SM-S911/],
        [6, 'Galaxy S23 Ultra', 'samsung', /^SM-S918/],
        [7, 'Galaxy S24', 'samsung', /^SM-S921/],
        [8, 'Galaxy S24 Ultra', 'samsung', /^SM-S928/],
        [9, 'Galaxy S25', 'samsung', /^SM-S931/],
        [10, 'Galaxy S25 Ultra', 'samsung', /^SM-S938/],
        [11, 'Galaxy A54', 'samsung', /^SM-A546/],
        [12, 'Galaxy A55', 'samsung', /^SM-A556/],
        [13, 'iPhone 13 / 14 (Pro 포함)', 'iphone', null],
        [14, 'iPhone 15 / 16 (Pro 포함)', 'iphone', null],
        [15, 'Pixel 7 / 8 (Pro 포함)', 'pixel', /^Pixel [78]/],
        [16, 'Pixel 9 (Pro 포함)', 'pixel', /^Pixel 9/]
    ];
    var CUSTOM_ID = 63;

    var profiles = PHONES.map(function (p) {
        var f = FAMILIES[p[2]];
        return {
            id: p[0], name: p[1], family: p[2], model: p[3], points: f.points, low: f.low, high: f.high,
            confidence: p[2] === 'flat' ? '없음' : '추정(제조사 계열 공통, 기종별 실측 아님)'
        };
    });

    function byId(id) {
        for (var i = 0; i < profiles.length; i++) if (profiles[i].id === id) return profiles[i];
        return null;
    }

    /** Profile for an Android model string from navigator.userAgentData, or null. */
    function detect(model) {
        if (!model) return null;
        for (var i = 0; i < profiles.length; i++) {
            if (profiles[i].model && profiles[i].model.test(model)) return profiles[i];
        }
        return null;
    }

    /**
     * Custom measured profile: JSON {"name":..., "points":[[hz,dB],...], "low":hz, "high":hz}, points ascending,
     * |dB| <= 30, 20 Hz-20 kHz. Returns the profile (id 63) or throws.
     */
    function custom(json) {
        var o = typeof json === 'string' ? JSON.parse(json) : json;
        if (!o || !Array.isArray(o.points) || o.points.length < 2 || o.points.length > 200) throw new Error('points: 2..200 entries');
        var last = 0;
        o.points.forEach(function (p) {
            if (!Array.isArray(p) || p.length !== 2 || !(p[0] >= 20 && p[0] <= 20000) || !(Math.abs(p[1]) <= 30) || p[0] <= last) {
                throw new Error('each point [hz, dB]: 20-20000 Hz ascending, |dB| <= 30');
            }
            last = p[0];
        });
        var low = o.low || o.points[0][0], high = o.high || o.points[o.points.length - 1][0];
        if (!(low >= 20 && high <= 20000 && low < high)) throw new Error('low/high out of range');
        return { id: CUSTOM_ID, name: '사용자 정의: ' + String(o.name || '측정 프로필').slice(0, 40), family: 'custom',
            points: o.points, low: low, high: high, confidence: '사용자 측정' };
    }

    return { profiles: profiles, byId: byId, detect: detect, custom: custom, CUSTOM_ID: CUSTOM_ID, hpf: hpf };
});
