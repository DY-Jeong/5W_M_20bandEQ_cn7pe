// Builds dist/roomcorr.html: index.html with roomcorr-core.js and roomcorr-mics.js inlined, so the phone needs a
// single file (USB copy, messenger, or any HTTPS host). Also compiles every script block to catch syntax errors.
// Usage: node build-html.js [outFile]
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const web = path.join(__dirname, 'web');
const out = process.argv[2] || path.join(__dirname, 'dist', 'roomcorr.html');
let html = fs.readFileSync(path.join(web, 'index.html'), 'utf8');
html = html.replace(/<script src="([^"]+)"><\/script>/g, (m, src) => {
    const js = fs.readFileSync(path.join(web, src), 'utf8');
    if (js.includes('</script')) throw new Error(src + ' contains </script');
    return '<script>\n' + js + '\n</script>';
});
if (/<script src=/.test(html)) throw new Error('external script left');
const blocks = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map((m) => m[1]);
blocks.forEach((js, i) => new vm.Script(js, { filename: 'block' + i + '.js' }));
fs.mkdirSync(path.dirname(out), { recursive: true });
fs.writeFileSync(out, html);
console.log('wrote ' + out + ' (' + html.length + ' chars, ' + blocks.length + ' script blocks compiled)');
