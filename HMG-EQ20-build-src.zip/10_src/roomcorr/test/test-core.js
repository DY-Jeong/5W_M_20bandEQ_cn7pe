// Node tests for roomcorr-core.js / roomcorr-mics.js. Usage: node test-core.js [vectors-out.json]
'use strict';
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const RC = require('../web/roomcorr-core.js');
const Mics = require('../web/roomcorr-mics.js');

let passed = 0;
function test(name, fn) { fn(); passed++; console.log('PASS ' + name); }

const RATE = 48000, N = 1 << 19;

/** Smooth "car cabin" response in dB: cabin gain, a 125 Hz bump, a 2 kHz dip, 8 kHz lift, top roll-off. */
function room(f) {
    const g = (fc, db, oct) => db * Math.exp(-Math.pow(Math.log2(f / fc) / oct, 2));
    return 8 / (1 + Math.pow(f / 50, 2)) + g(125, 4, 0.4) + g(2000, -6, 0.35) + g(8000, 3, 0.4) - 4 / (1 + Math.pow(14000 / f, 4));
}

/** Filter samples by a magnitude response given in dB (zero phase, circular). */
function shape(x, dbAt) {
    const re = Float64Array.from(x), im = new Float64Array(x.length);
    RC.fft(re, im, false);
    for (let i = 1; i < x.length / 2; i++) {
        const g = Math.pow(10, dbAt(i * RATE / x.length) / 20);
        re[i] *= g; im[i] *= g; re[x.length - i] *= g; im[x.length - i] *= g;
    }
    re[0] = 0; im[0] = 0;
    RC.fft(re, im, true);
    return Float32Array.from(re);
}

const samsung = Mics.byId(1), flat = Mics.byId(0);
const micResp = f => RC.micDb(samsung, f);

const source = RC.pinkNoise(N, RATE, 7, -18);
const background = RC.pinkNoise(N, RATE, 99, -62);
const recorded = shape(source, f => room(f) + micResp(f)).map((v, i) => v + background[i]);
const bgRecorded = background;
const run = { signal: RC.bandLevels(recorded, RATE), background: RC.bandLevels(bgRecorded, RATE) };

test('pink noise has equal power per half-octave band (within 0.6 dB from 31 Hz to 16 kHz)', () => {
    const lv = RC.bandLevels(source, RATE);
    const mid = lv.slice(1);
    const mean = mid.reduce((a, b) => a + b) / mid.length;
    mid.forEach((v, i) => assert(Math.abs(v - mean) < 0.6, `band ${RC.CENTERS[i + 1]} ${(v - mean).toFixed(2)} dB`));
    const rms = Math.sqrt(source.reduce((a, v) => a + v * v, 0) / source.length);
    assert(Math.abs(20 * Math.log10(rms) + 18) < 0.01, 'rms -18 dBFS');
});

test('pink noise is deterministic per seed (browser and head unit generate the same signal)', () => {
    const a = RC.pinkNoise(4096, 44100, 3), b = RC.pinkNoise(4096, 44100, 3), c = RC.pinkNoise(4096, 44100, 4);
    assert.deepStrictEqual(Array.from(a), Array.from(b));
    assert.notDeepStrictEqual(Array.from(a), Array.from(c));
});

/** Independent expectation: exact room deviation (vs 250-4k mean), target minus it, same smoothing/limits. */
function expected(valid, targetDb, boostShare) {
    const ref = RC.CENTERS.filter((f, i) => valid[i] && f >= 250 && f <= 4000).map(room);
    const mean = ref.reduce((a, b) => a + b) / ref.length;
    const raw = RC.CENTERS.map((f, i) => valid[i] ? targetDb[i] - (bandRoom(i) - mean) : null);
    return raw.map((v, i) => {
        if (v === null) return 0;
        let acc = 0.5 * v, w = 0.5;
        for (const j of [i - 1, i + 1]) if (j >= 0 && j < 20 && raw[j] !== null) { acc += 0.25 * raw[j]; w += 0.25; }
        let c = acc / w;
        if (c > 0) c *= boostShare;
        return Math.max(-12, Math.min(RC.maxDb(i), c));
    });
}

/** Band-averaged room response in power (what the band analysis sees). */
function bandRoom(i) {
    const fc = RC.CENTERS[i], lo = fc * Math.pow(2, -0.25), hi = fc * Math.pow(2, 0.25);
    let p = 0, w = 0;
    for (let k = 0; k <= 200; k++) {
        const f = lo * Math.pow(hi / lo, k / 200);
        p += Math.pow(10, room(f) / 10) / f; w += 1 / f;
    }
    return 10 * Math.log10(p / w);
}

test('correction with the right mic profile recovers the room response (|error| <= 1 dB, flat target)', () => {
    const res = RC.correction([run], samsung, 0, { boostShare: 1 });
    const valid = RC.CENTERS.map(f => f >= samsung.low && f <= samsung.high);
    const exp = expected(valid, RC.TARGETS[0].db, 1);
    res.bands.forEach((b, i) => {
        if (!valid[i]) assert.strictEqual(b.reason, 'mic-range', `band ${b.hz} outside mic range`);
        assert(Math.abs(b.correction - exp[i]) <= 1, `band ${b.hz}: got ${b.correction}, expected ${exp[i].toFixed(2)}`);
    });
    assert(res.correction[13] >= 2, '2 kHz dip produces a boost (narrow dip, smoothed)');
    assert(res.correction[5] <= -2, '125 Hz bump produces a cut');
});

test('mic compensation matters: ignoring the Samsung high-pass over-boosts 88 Hz', () => {
    const withMic = RC.correction([run], samsung, 0, { boostShare: 1 });
    const noMic = RC.correction([run], Object.assign({}, flat, { low: 88, high: 8000 }), 0, { boostShare: 1 });
    const d = noMic.bands[4].correction - withMic.bands[4].correction;
    assert(d >= 1, `88 Hz difference ${d} (mic reads ${RC.micDb(samsung, 88).toFixed(1)} dB)`);
});

test('default policy fills dips only half and respects AMP limits', () => {
    const res = RC.correction([run], samsung, 1);
    const full = RC.correction([run], samsung, 1, { boostShare: 1 });
    res.correction.forEach((v, i) => {
        assert(v >= -12 && v <= RC.maxDb(i) && Number.isInteger(v), `band ${i}: ${v}`);
        if (full.bands[i].correction > 1) assert(v < full.bands[i].correction, `band ${i} boost halved`);
    });
});

test('several positions are averaged; low SNR bands are skipped', () => {
    const loud = RC.pinkNoise(N, RATE, 5, -20);
    const noisyBg = shape(loud, f => (f > 9000 ? 0 : -60));
    const run2 = { signal: RC.bandLevels(recorded.map((v, i) => v + noisyBg[i]), RATE), background: RC.bandLevels(noisyBg, RATE) };
    const res = RC.correction([run, run2], Object.assign({}, samsung, { high: 16000 }), 0);
    assert.strictEqual(res.bands[19].reason, 'low-snr', '16 kHz drowned by background');
    assert.strictEqual(res.bands[19].correction, 0);
    assert.strictEqual(res.bands[10].reason, null);
});

test('too little signal is refused', () => {
    const quiet = { signal: run.background, background: run.background };
    assert.throws(() => RC.correction([quiet], samsung, 0), /not enough valid mid bands/);
});

test('mic profiles: 16 phones + none, ids stable, detection, custom profile validation', () => {
    assert.strictEqual(Mics.profiles.length, 17);
    assert.deepStrictEqual(Mics.profiles.map(p => p.id), Array.from({ length: 17 }, (_, i) => i));
    assert.strictEqual(Mics.byId(1).name, 'Galaxy Z Flip5');
    assert.strictEqual(Mics.detect('SM-F731N').id, 1);
    assert.strictEqual(Mics.detect('SM-S928N').id, 8);
    assert.strictEqual(Mics.detect('Pixel 8 Pro').id, 15);
    assert.strictEqual(Mics.detect('SM-X999'), null);
    assert(Math.abs(RC.micDb(samsung, 63) - Mics.hpf(80, 63)) < 0.1, 'family curve is the 80 Hz high-pass');
    const c = Mics.custom('{"name":"UMIK cal","points":[[20,-10],[100,0],[10000,2]],"low":50,"high":10000}');
    assert.strictEqual(c.id, 63);
    assert.throws(() => Mics.custom('{"points":[[100,0],[50,1]]}'), /ascending/);
    assert.throws(() => Mics.custom('{"points":[[100,40],[200,1]]}'), /dB/);
});

const vectors = [];
test('result code: round trip, 25 characters, every single-character typo detected', () => {
    let seed = 11;
    const rnd = () => (seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff;
    for (let t = 0; t < 200; t++) {
        const corr = RC.CENTERS.map((f, i) => Math.round(-12 + rnd() * (RC.maxDb(i) + 12)) + 0);
        const target = t % 3, profile = t % 18 === 17 ? 63 : t % 17;
        const code = RC.encode(corr, target, profile);
        assert.match(code, /^([0-9A-Z]{5}-){4}[0-9A-Z]{5}$/);
        const d = RC.decode(code);
        assert.deepStrictEqual(d.correction, corr);
        assert.strictEqual(d.target, target);
        assert.strictEqual(d.profile, profile);
        assert.deepStrictEqual(RC.decode(code.toLowerCase().replace(/-/g, ' ')).correction, corr);
        if (t < 40) vectors.push({ code, target, profile, correction: corr });
        const s = code.replace(/-/g, '');
        for (let p = 0; p < 25; p++) {
            const alt = '0123456789ABCDEFGHJKMNPQRSTVWXYZ'.replace(s[p], '');
            const bad = s.slice(0, p) + alt[Math.floor(rnd() * alt.length)] + s.slice(p + 1);
            assert.throws(() => RC.decode(bad), /checksum|above limit|version|character/);
        }
    }
    assert.throws(() => RC.decode('ABC'), /25 characters/);
    assert.throws(() => RC.encode(RC.CENTERS.map(() => 0).map((v, i) => (i === 0 ? 6 : 0)), 0, 1), /out of range/);
});

test('flat correction encodes to a stable known code', () => {
    const code = RC.encode(new Array(20).fill(0), 0, 1);
    assert.deepStrictEqual(RC.decode(code).correction, new Array(20).fill(0));
    vectors.push({ code, target: 0, profile: 1, correction: new Array(20).fill(0) });
});

if (process.argv[2]) {
    fs.writeFileSync(process.argv[2], JSON.stringify(vectors, null, 1) + '\n');
    console.log('wrote ' + vectors.length + ' vectors to ' + path.basename(process.argv[2]));
}
console.log(`roomcorr core tests OK (${passed})`);
