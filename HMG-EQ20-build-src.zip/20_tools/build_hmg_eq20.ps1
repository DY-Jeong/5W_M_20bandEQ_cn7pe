# Builds the hmg-eq20 NEMESIS package:
#   libeq20.so (10_src\eq20\build.ps1), eq20d.jar (root daemon), HmgEq20.apk (EQ app), audio_effects.conf
#   -> 30_usb\pkg_hmg_eq20\  -> 30_usb\hmg_eq20\packages\hmg-eq20.zip -> 40_dist\HMG-EQ20-usb.zip
# Tools live in 10_src\eq_probe\.build-tools: r8.jar (D8), bt28 (aapt, zipalign, apksigner), p19 (android-19 android.jar).
$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot
$app = Join-Path $root '10_src\eq20app'
$tools = Join-Path $root '10_src\eq_probe\.build-tools'
$bt = Join-Path $tools 'bt28\android-9'
$androidJar = Join-Path $tools 'p19\android-4.4.2\android.jar'
$r8 = Join-Path $tools 'r8.jar'
$out = Join-Path $app 'out'
$pkg = Join-Path $root '30_usb\pkg_hmg_eq20'
$usb = Join-Path $root '30_usb\hmg_eq20'
$lf = New-Object Text.UTF8Encoding $false
$stockConf = Join-Path $root '50_captures\261118\hmg-collect-20261118-090538\audio\config\system\etc\audio_effects.conf'
$stockMd5 = '4d98c1b38bd1d9eaf929d9b616c0d118'
foreach ($p in $bt, $androidJar, $r8) { if (-not (Test-Path $p)) { throw "missing build tool $p (see 10_src\eq_probe\build.ps1 / README)" } }

function Invoke-Native([string]$exe, [string[]]$argv) {
    $saved = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try { & $exe @argv 2>&1 | ForEach-Object { "$_" } } finally { $ErrorActionPreference = $saved }
    if ($LASTEXITCODE -ne 0) { throw "$exe $($argv[0]) failed with exit code $LASTEXITCODE" }
}

$ErrorActionPreference = 'Continue'
$javaHome = (& java -XshowSettings:properties -version 2>&1 | ForEach-Object { "$_" } |
        Where-Object { $_ -match '^\s*java\.home\s*=' }) -replace '^\s*java\.home\s*=\s*', ''
$ErrorActionPreference = 'Stop'
$java8 = Join-Path $javaHome 'bin\java.exe'

& (Join-Path $root '10_src\eq20\build.ps1') | Out-Host

# Room correction: JS core tests (regenerate the vectors the Java test reads), then the single-file phone page.
$roomcorr = Join-Path $root '10_src\roomcorr'
Push-Location (Join-Path $roomcorr 'test')
try { Invoke-Native node @('test-core.js', 'vectors.json') } finally { Pop-Location }
Invoke-Native node @((Join-Path $roomcorr 'build-html.js'))

if (Test-Path $out) { Remove-Item -Recurse -Force $out }
$classes = Join-Path $out 'classes'
$testClasses = Join-Path $out 'test-classes'
New-Item -ItemType Directory -Force $classes, $testClasses | Out-Null

# Host tests of the pure-Java core against on-car dumps.
$core = @(Get-ChildItem (Join-Path $app 'src\com\hmg\eq20\core') -Filter *.java | ForEach-Object FullName)
Invoke-Native javac (@('--release', '8', '-encoding', 'UTF-8', '-d', $testClasses) + $core + @((Join-Path $app 'test\CoreTest.java')))
Invoke-Native java @('-cp', $testClasses, 'CoreTest', (Join-Path $root '50_captures\261118\hmg-eqp0-20261118-133352\snap'),
    (Join-Path $root '10_src\roomcorr\test\vectors.json'))

# Host preview of the app screen (same geometry as EqBandsView) -> 00_docs\plans\eq20_preview\*.png
Invoke-Native javac @('--release', '8', '-encoding', 'UTF-8', '-cp', $testClasses, '-d', $testClasses, (Join-Path $app 'tools\RenderPreview.java'))
Invoke-Native java @('-cp', $testClasses, 'RenderPreview', (Join-Path $root '00_docs\plans\eq20_preview'))

# Launcher icon (generated once): EQ bars on the dark surface.
$icon = Join-Path $app 'res\drawable-hdpi\ic_eq.png'
if (-not (Test-Path $icon)) {
    Add-Type -AssemblyName System.Drawing
    New-Item -ItemType Directory -Force (Split-Path $icon) | Out-Null
    $bmp = New-Object Drawing.Bitmap 72, 72
    $g = [Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = 'AntiAlias'
    $g.Clear([Drawing.Color]::FromArgb(0, 0, 0, 0))
    $g.FillRectangle((New-Object Drawing.SolidBrush ([Drawing.Color]::FromArgb(255, 23, 23, 23))), 4, 4, 64, 64)
    $blue = New-Object Drawing.SolidBrush ([Drawing.Color]::FromArgb(255, 0, 112, 243))
    $white = New-Object Drawing.SolidBrush ([Drawing.Color]::FromArgb(255, 245, 245, 245))
    $heights = 30, 44, 22, 38, 50
    for ($i = 0; $i -lt 5; $i++) {
        $x = 12 + $i * 10
        $g.FillRectangle($blue, $x, 62 - $heights[$i], 6, $heights[$i])
        $g.FillEllipse($white, $x - 2, 58 - $heights[$i], 10, 10)
    }
    $g.Dispose()
    $bmp.Save($icon, [Drawing.Imaging.ImageFormat]::Png)
    $bmp.Dispose()
}

# Android classes: Java 7 bytecode against the API 19 platform.
$all = @(Get-ChildItem (Join-Path $app 'src') -Recurse -Filter *.java | ForEach-Object FullName)
Invoke-Native javac (@('-source', '1.7', '-target', '1.7', '-encoding', 'UTF-8', '-Xlint:-options',
        '-bootclasspath', $androidJar, '-d', $classes) + $all)
$d8 = @('-cp', $r8, 'com.android.tools.r8.D8', '--release', '--min-api', '19', '--lib', $androidJar)

# Daemon jar: core + daemon only.
$daemonJar = Join-Path $out 'eq20d.jar'
$daemonClasses = @(Get-ChildItem (Join-Path $classes 'com\hmg\eq20') -Recurse -Filter *.class |
        Where-Object { $_.FullName -notmatch '\\ui\\' } | ForEach-Object FullName)
Invoke-Native $java8 ($d8 + @('--output', $daemonJar) + $daemonClasses)

# APK: resources, dex, align, sign (v1; the key is kept so updates keep the app data).
$dexDir = Join-Path $out 'dex'
New-Item -ItemType Directory -Force $dexDir | Out-Null
$appClasses = @(Get-ChildItem $classes -Recurse -Filter *.class | ForEach-Object FullName)
Invoke-Native $java8 ($d8 + @('--output', $dexDir) + $appClasses)
$unsigned = Join-Path $out 'unsigned.apk'
Invoke-Native (Join-Path $bt 'aapt.exe') @('package', '-f', '-M', (Join-Path $app 'AndroidManifest.xml'),
    '-S', (Join-Path $app 'res'), '-I', $androidJar, '-F', $unsigned)
Push-Location $dexDir
try { Invoke-Native (Join-Path $bt 'aapt.exe') @('add', $unsigned, 'classes.dex') } finally { Pop-Location }
$aligned = Join-Path $out 'aligned.apk'
Invoke-Native (Join-Path $bt 'zipalign.exe') @('-f', '4', $unsigned, $aligned)
$keystore = Join-Path $app 'signing\hmg-eq20.jks'
if (-not (Test-Path $keystore)) {
    New-Item -ItemType Directory -Force (Split-Path $keystore) | Out-Null
    Invoke-Native keytool @('-genkeypair', '-keystore', $keystore, '-alias', 'hmg-eq20', '-keyalg', 'RSA', '-keysize', '2048',
        '-validity', '10000', '-storepass', 'hmg-eq20', '-keypass', 'hmg-eq20', '-dname', 'CN=HMG EQ20,O=HMG-Seogaemo,C=KR')
}
$apk = Join-Path $out 'HmgEq20.apk'
Invoke-Native $java8 @('-jar', (Join-Path $bt 'lib\apksigner.jar'), 'sign', '--ks', $keystore, '--ks-pass', 'pass:hmg-eq20',
    '--ks-key-alias', 'hmg-eq20', '--v1-signing-enabled', 'true', '--v2-signing-enabled', 'false', '--min-sdk-version', '19',
    '--out', $apk, $aligned)
Invoke-Native $java8 @('-jar', (Join-Path $bt 'lib\apksigner.jar'), 'verify', '--min-sdk-version', '19', $apk)

# Install-time audio_effects.conf: the analyzed stock file plus the eq20 library and effect entries.
if ((Get-FileHash $stockConf -Algorithm MD5).Hash.ToLowerInvariant() -ne $stockMd5) { throw 'stock audio_effects.conf changed' }
$lines = [IO.File]::ReadAllText($stockConf).Split("`n")
function Close-Of([string]$block) {
    $open = [Array]::IndexOf($lines, "$block {")
    if ($open -lt 0) { throw "no top-level '$block {' block" }
    for ($i = $open + 1; $i -lt $lines.Count; $i++) { if ($lines[$i] -eq '}') { return $i } }
    throw "unterminated $block block"
}
$libEnd = Close-Of 'libraries'
$fxEnd = Close-Of 'effects'
$conf = @($lines[0..($libEnd - 1)]) + @('  eq20 {', '    path /system/lib/soundfx/libeq20.so', '  }') +
    @($lines[$libEnd..($fxEnd - 1)]) +
    @('  eq20 {', '    library eq20', '    uuid f3bc120f-2838-4417-bec2-8b98750945bf', '  }') +
    @($lines[$fxEnd..($lines.Count - 1)])

$files = Join-Path $pkg 'files'
New-Item -ItemType Directory -Force $files, (Join-Path $pkg 'app') | Out-Null
[IO.File]::WriteAllText((Join-Path $files 'audio_effects.conf'), ($conf -join "`n"), $lf)
Copy-Item (Join-Path $root '10_src\eq20\out\libeq20.so') $files -Force
Copy-Item $daemonJar $files -Force
Copy-Item $apk (Join-Path $pkg 'app\HmgEq20.apk') -Force
$sums = foreach ($n in 'libeq20.so', 'audio_effects.conf', 'eq20d.jar') {
    "$((Get-FileHash (Join-Path $files $n) -Algorithm MD5).Hash.ToLowerInvariant()) $n"
}
[IO.File]::WriteAllText((Join-Path $files 'MD5SUMS'), (($sums -join "`n") + "`n"), $lf)

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
# Zip with '/' separators: Windows PowerShell's CreateFromDirectory writes '\', which the head unit's
# unzip would take as part of the file name.
function New-ZipFromDir([string]$dir, [string]$zipPath) {
    if (Test-Path $zipPath) { Remove-Item -Force $zipPath }
    $base = (Resolve-Path $dir).Path.TrimEnd('\') + '\'
    $zip = [IO.Compression.ZipFile]::Open($zipPath, 'Create')
    try {
        foreach ($f in Get-ChildItem $dir -Recurse -File | Sort-Object FullName) {
            $name = $f.FullName.Substring($base.Length).Replace('\', '/')
            [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $f.FullName, $name)
        }
    } finally { $zip.Dispose() }
}
New-Item -ItemType Directory -Force (Join-Path $usb 'packages') | Out-Null
$pkgZip = Join-Path $usb 'packages\hmg-eq20.zip'
New-ZipFromDir $pkg $pkgZip
[IO.File]::WriteAllText((Join-Path $usb 'NEMESIS.data'), "[nemesis]`nversion=1.0`ntype=install`npath=packages/hmg-eq20.zip`n", $lf)
# Phone measurement page, copied from the USB stick to the phone (not used by the head unit).
Copy-Item (Join-Path $roomcorr 'dist\roomcorr.html') (Join-Path $usb 'roomcorr.html') -Force
$usbZip = Join-Path $root '40_dist\HMG-EQ20-usb.zip'
New-Item -ItemType Directory -Force (Split-Path $usbZip) | Out-Null
New-ZipFromDir $usb $usbZip
"apk=$apk bytes=$((Get-Item $apk).Length)"
"package=$pkgZip sha256=$((Get-FileHash $pkgZip -Algorithm SHA256).Hash)"
"usb=$usbZip sha256=$((Get-FileHash $usbZip -Algorithm SHA256).Hash)"
