# Downloads the Android build tools used by build_hmg_eq20.ps1 into 10_src\eq_probe\.build-tools (once).
#   r8.jar           D8 dexer (r8 1.6.84)
#   bt28\android-9   Android SDK build-tools 28.0.3 (aapt, zipalign, apksigner)
#   p19\android-4.4.2 Android SDK platform 19 r04 (android.jar)
# Zig 0.13.0 (C toolchain for libeq20.so) is fetched by 10_src\eq20\build.ps1 itself.
$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot
$tools = Join-Path $root '10_src\eq_probe\.build-tools'
New-Item -ItemType Directory -Force $tools | Out-Null
[Net.ServicePointManager]::SecurityProtocol = 'Tls12'
Add-Type -AssemblyName System.IO.Compression.FileSystem

$r8 = Join-Path $tools 'r8.jar'
if (-not (Test-Path $r8)) {
    Invoke-WebRequest 'https://dl.google.com/dl/android/maven2/com/android/tools/r8/1.6.84/r8-1.6.84.jar' -OutFile $r8 -UseBasicParsing
}

# Each SDK zip has a single top-level folder (android-9, android-4.4.2) that the build script expects.
$sdk = @(
    @{ Dir = 'bt28'; Check = 'android-9\aapt.exe'; Url = 'https://dl.google.com/android/repository/build-tools_r28.0.3-windows.zip' },
    @{ Dir = 'p19'; Check = 'android-4.4.2\android.jar'; Url = 'https://dl.google.com/android/repository/android-19_r04.zip' }
)
foreach ($s in $sdk) {
    $dir = Join-Path $tools $s.Dir
    if (Test-Path (Join-Path $dir $s.Check)) { continue }
    $zip = Join-Path $tools "$($s.Dir).zip"
    Invoke-WebRequest $s.Url -OutFile $zip -UseBasicParsing
    if (Test-Path $dir) { Remove-Item -Recurse -Force $dir }
    [IO.Compression.ZipFile]::ExtractToDirectory($zip, $dir)
    Remove-Item $zip
    if (-not (Test-Path (Join-Path $dir $s.Check))) { throw "unexpected layout in $($s.Url): missing $($s.Check)" }
}
"build tools ready in $tools"
