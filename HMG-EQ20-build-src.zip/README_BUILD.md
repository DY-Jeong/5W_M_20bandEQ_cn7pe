# hmg-eq20 빌드 소스 (최소 구성)

CN7N AVANTE N (KOR) 헤드유닛용 20밴드 EQ NEMESIS 패키지(`HMG-EQ20-usb.zip`)를 다시 만드는 데 필요한 파일만 담았다.

## 준비물 (Windows)

| 도구 | 용도 | 확인 |
|---|---|---|
| JDK 11 이상 (`java`, `javac` PATH) | 앱·데몬 컴파일, D8, apksigner | `javac -version` |
| Node.js | 룸 보정 코어 테스트, `roomcorr.html` 생성 | `node -v` |
| Python 3 + `pyelftools` | `libeq20.so` 로딩 검사 | `pip install pyelftools` |
| 인터넷 (최초 1회) | 빌드 도구 다운로드 약 200 MB | |

## 빌드

압축을 푼 폴더(이 파일이 있는 곳)에서:

```powershell
powershell -ExecutionPolicy Bypass -File 20_tools\fetch_build_tools.ps1   # 최초 1회: r8, build-tools 28.0.3, platform 19
powershell -ExecutionPolicy Bypass -File 20_tools\build_hmg_eq20.ps1      # Zig 0.13 은 첫 빌드 때 자동 다운로드
```

결과물:

- `40_dist\HMG-EQ20-usb.zip` — USB 루트에 풀어서 차량에 설치
- `30_usb\hmg_eq20\` — 위 ZIP 의 내용
- `30_usb\pkg_hmg_eq20\` — 패키지 본체 (`app\`, `files\` 는 빌드가 생성)
- `00_docs\plans\eq20_preview\*.png` — 앱 화면 미리보기

## 구성

| 경로 | 내용 |
|---|---|
| `20_tools\build_hmg_eq20.ps1` | 전체 빌드·패키징 |
| `20_tools\fetch_build_tools.ps1` | Android 빌드 도구 다운로드 |
| `10_src\eq20\` | 이펙트 라이브러리 `libeq20.so` (C, Zig 로 ARMv7 빌드) + 호스트 테스트 |
| `10_src\eq20app\` | EQ 앱 `HmgEq20.apk` + root 데몬 `eq20d.jar` (Java, API 19) |
| `10_src\eq20app\signing\hmg-eq20.jks` | APK 서명 키. 같은 키로 서명해야 기존 설치 위에 업데이트된다. 없으면 새 키가 생성되며, 이 경우 차량에서 기존 앱을 먼저 제거해야 한다 |
| `10_src\roomcorr\` | 휴대폰 룸 보정 측정 페이지 소스 (`web\`) 와 테스트 |
| `30_usb\pkg_hmg_eq20\` | 설치/제거 스크립트, 서비스 스크립트, `NEMESIS.data` |
| `50_captures\...\audio_effects.conf` | 차량 순정 `audio_effects.conf` (MD5 `4d98c1b38bd1d9eaf929d9b616c0d118`). 설치용 설정의 원본 |
| `50_captures\...\snap\*.txt` | 호스트 테스트용 `dumpsys media.audio_flinger` 스냅샷 (재생 중 / 대기) |

`.sh`, `NEMESIS.data`, `MD5SUMS` 는 LF 줄바꿈이어야 한다 (`.gitattributes`). Git 으로 옮길 때 CRLF 로 바뀌지 않게 주의한다.

## 대상 제한

- 펌웨어 `ro.build.product=CN7NPE.KOR.0000.V039.001.260902` 와 순정 `audio_effects.conf` MD5 가 정확히 일치할 때만 설치된다 (`scripts\common.sh`).
- 다른 차종·펌웨어에 쓰려면 그 차량의 순정 `audio_effects.conf` 로 `build_hmg_eq20.ps1` 의 `$stockConf`/`$stockMd5` 와 `common.sh` 의 `product`/`stock_conf_md5` 를 바꾸고 다시 빌드한다. Android 4.4 / 32-bit ARM / 16-bit 스테레오 출력 / NEMESIS 설치 환경이 전제다.
